/**
 * پنل مدیریت افزونه: سوییچ تب‌ها + کنترل حلقه‌ی AJAX پردازش دسته‌ای + گزارش کاهش حجم.
 * بدون وابستگی به jQuery؛ فقط Vanilla JS برای سبک ماندن پنل.
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		initTabs();
		initBatchPanel();
		initSeoPanel();
		initWatermarkPanel();
		initMediaLibraryPanel();
	} );

	function initTabs() {
		var links = document.querySelectorAll( '.aiseo-tab-nav a' );
		var panels = document.querySelectorAll( '.aiseo-tab-content' );

		links.forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				var target = link.getAttribute( 'data-tab' );

				links.forEach( function ( l ) {
					l.classList.remove( 'active' );
				} );
				panels.forEach( function ( p ) {
					p.classList.remove( 'active' );
				} );

				link.classList.add( 'active' );
				var panel = document.getElementById( target );
				if ( panel ) {
					panel.classList.add( 'active' );
				}
			} );
		} );
	}

	/**
	 * تبدیل تعداد بایت به رشته‌ی خوانا (KB/MB/GB). فقط برای نمایش، نه محاسبه.
	 */
	function formatBytes( bytes ) {
		bytes = Number( bytes ) || 0;
		if ( bytes <= 0 ) {
			return '0 KB';
		}
		var units = [ 'B', 'KB', 'MB', 'GB' ];
		var i = 0;
		while ( bytes >= 1024 && i < units.length - 1 ) {
			bytes /= 1024;
			i++;
		}
		var decimals = i === 0 ? 0 : 1;
		return bytes.toFixed( decimals ) + ' ' + units[ i ];
	}

	/**
	 * درخواست AJAX مشترک به admin-ajax.php با nonce پنل مدیریت.
	 */
	function postAction( action, extra ) {
		var body = new URLSearchParams( Object.assign( { action: action, nonce: AISEO_ADMIN.nonce }, extra || {} ) );
		return fetch( AISEO_ADMIN.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: body.toString(),
		} ).then( function ( res ) {
			return res.json();
		} );
	}

	function initBatchPanel() {
		var panel = document.getElementById( 'aiseo-batch-panel' );
		if ( ! panel || typeof AISEO_ADMIN === 'undefined' ) {
			return;
		}

		var startBtn = document.getElementById( 'aiseo-batch-start' );
		var stopBtn = document.getElementById( 'aiseo-batch-stop' );
		var retryBtn = document.getElementById( 'aiseo-batch-retry' );
		var refreshBtn = document.getElementById( 'aiseo-batch-refresh' );
		var statusEl = document.getElementById( 'aiseo-batch-status' );
		var progressBar = document.getElementById( 'aiseo-progress-bar' );
		var pendingEl = document.getElementById( 'aiseo-stat-pending' );
		var processingEl = document.getElementById( 'aiseo-stat-processing' );
		var doneEl = document.getElementById( 'aiseo-stat-done' );
		var failedEl = document.getElementById( 'aiseo-stat-failed' );
		var runReportEl = document.getElementById( 'aiseo-run-report' );
		var runReportText = document.getElementById( 'aiseo-run-report-text' );

		var isRunning = false;
		var stopRequested = false;
		var totalAtStart = 0;
		var runConverted = 0;
		var runBytesBefore = 0;
		var runBytesAfter = 0;

		refreshStats();
		loadSizeReport();

		startBtn.addEventListener( 'click', function () {
			if ( isRunning ) {
				return;
			}
			startBatch();
		} );

		stopBtn.addEventListener( 'click', function () {
			if ( ! isRunning ) {
				return;
			}
			stopRequested = true;
			stopBtn.disabled = true;
			statusEl.textContent = AISEO_ADMIN.i18n.stopped;
		} );

		retryBtn.addEventListener( 'click', function () {
			if ( isRunning ) {
				return;
			}
			retryBtn.disabled = true;
			statusEl.textContent = AISEO_ADMIN.i18n.retrying;

			postAction( 'aiseo_batch_retry_failed' ).then( function ( res ) {
				retryBtn.disabled = false;

				if ( ! res || ! res.success ) {
					finishWithError();
					return;
				}

				updateStatNumbers( res.data.stats );

				if ( ! res.data.requeued ) {
					statusEl.textContent = AISEO_ADMIN.i18n.noFailed;
					return;
				}

				totalAtStart = res.data.stats.pending;
				runConverted = 0;
				runBytesBefore = 0;
				runBytesAfter = 0;
				runReportEl.hidden = true;
				stopRequested = false;
				isRunning = true;
				toggleRunningButtons( true );
				runTick();
			} ).catch( finishWithError );
		} );

		refreshBtn.addEventListener( 'click', function () {
			refreshStats();
			loadSizeReport();
		} );

		function refreshStats() {
			postAction( 'aiseo_batch_stats' ).then( function ( res ) {
				if ( res && res.success ) {
					updateStatNumbers( res.data );
				}
			} );
		}

		function updateStatNumbers( stats ) {
			pendingEl.textContent = stats.pending;
			processingEl.textContent = stats.processing || 0;
			doneEl.textContent = stats.done;
			failedEl.textContent = stats.failed;
		}

		function updateProgress( remaining ) {
			if ( totalAtStart > 0 ) {
				var doneCount = totalAtStart - remaining;
				var pct = Math.max( 0, Math.min( 100, Math.round( ( doneCount / totalAtStart ) * 100 ) ) );
				progressBar.style.width = pct + '%';
			}
		}

		function toggleRunningButtons( running ) {
			startBtn.disabled = running;
			retryBtn.disabled = running;
			stopBtn.hidden = ! running;
			stopBtn.disabled = false;
		}

		function updateRunReport() {
			if ( runBytesBefore <= 0 ) {
				return;
			}
			var saved = Math.max( 0, runBytesBefore - runBytesAfter );
			var pct = runBytesBefore > 0 ? Math.round( ( saved / runBytesBefore ) * 1000 ) / 10 : 0;
			runReportEl.hidden = false;
			runReportText.textContent = runConverted + ' تصویر — ' + formatBytes( runBytesBefore ) + ' ← ' + formatBytes( runBytesAfter ) + ' (کاهش ' + pct + '٪)';
		}

		function startBatch() {
			isRunning = true;
			stopRequested = false;
			runConverted = 0;
			runBytesBefore = 0;
			runBytesAfter = 0;
			runReportEl.hidden = true;
			progressBar.style.width = '0%';
			toggleRunningButtons( true );
			statusEl.textContent = AISEO_ADMIN.i18n.starting;

			postAction( 'aiseo_batch_enqueue' ).then( function ( res ) {
				if ( ! res || ! res.success ) {
					finishWithError();
					return;
				}

				updateStatNumbers( res.data.stats );
				totalAtStart = res.data.stats.pending;

				if ( totalAtStart <= 0 ) {
					statusEl.textContent = AISEO_ADMIN.i18n.noNewImages;
					isRunning = false;
					toggleRunningButtons( false );
					return;
				}

				runTick();
			} ).catch( finishWithError );
		}

		function runTick() {
			if ( stopRequested ) {
				finishRun( false );
				return;
			}

			statusEl.textContent = AISEO_ADMIN.i18n.processing;

			postAction( 'aiseo_batch_tick' ).then( function ( res ) {
				if ( ! res || ! res.success ) {
					finishWithError();
					return;
				}

				var data = res.data;

				if ( data.locked ) {
					statusEl.textContent = AISEO_ADMIN.i18n.locked;
					if ( ! stopRequested ) {
						setTimeout( runTick, 3000 );
					} else {
						finishRun( false );
					}
					return;
				}

				runConverted += data.converted;
				runBytesBefore += data.bytes_before;
				runBytesAfter += data.bytes_after;
				updateRunReport();

				pendingEl.textContent = data.remaining;
				processingEl.textContent = 0;
				doneEl.textContent = Number( doneEl.textContent || 0 ) + data.converted + data.skipped;
				failedEl.textContent = Number( failedEl.textContent || 0 ) + data.failed;
				updateProgress( data.remaining );

				if ( data.remaining > 0 && ! stopRequested ) {
					setTimeout( runTick, 400 );
				} else {
					finishRun( data.remaining <= 0 );
				}
			} ).catch( finishWithError );
		}

		function finishRun( completed ) {
			isRunning = false;
			toggleRunningButtons( false );
			refreshStats();

			if ( completed ) {
				statusEl.textContent = AISEO_ADMIN.i18n.done;
				progressBar.style.width = '100%';
			} else {
				statusEl.textContent = AISEO_ADMIN.i18n.stopped;
			}

			if ( runBytesBefore > 0 ) {
				loadSizeReport();
			}
		}

		function finishWithError() {
			statusEl.textContent = AISEO_ADMIN.i18n.error;
			isRunning = false;
			toggleRunningButtons( false );
		}

		// -------------------------------------------------------------
		// گزارش کاهش حجم (کل عمر افزونه)
		// -------------------------------------------------------------

		function loadSizeReport() {
			var loadingEl = document.getElementById( 'aiseo-size-report-loading' );
			var contentEl = document.getElementById( 'aiseo-size-report-content' );

			if ( ! loadingEl || ! contentEl ) {
				return;
			}

			loadingEl.hidden = false;
			loadingEl.textContent = AISEO_ADMIN.i18n.reportLoading;

			postAction( 'aiseo_size_report' ).then( function ( res ) {
				if ( ! res || ! res.success ) {
					loadingEl.textContent = AISEO_ADMIN.i18n.error;
					return;
				}

				var summary = res.data.summary;
				var daily = res.data.daily || [];

				document.getElementById( 'aiseo-report-files' ).textContent = summary.files;
				document.getElementById( 'aiseo-report-saved' ).textContent = formatBytes( summary.bytes_saved );
				document.getElementById( 'aiseo-report-percent' ).textContent = summary.percent_saved + '٪';

				var tbody = document.getElementById( 'aiseo-report-daily-body' );
				tbody.innerHTML = '';

				if ( ! daily.length ) {
					var emptyRow = document.createElement( 'tr' );
					var emptyCell = document.createElement( 'td' );
					emptyCell.colSpan = 5;
					emptyCell.textContent = AISEO_ADMIN.i18n.reportEmpty;
					emptyRow.appendChild( emptyCell );
					tbody.appendChild( emptyRow );
				} else {
					daily.forEach( function ( row ) {
						var tr = document.createElement( 'tr' );
						[
							row.date,
							row.files,
							formatBytes( row.bytes_before ),
							formatBytes( row.bytes_after ),
							row.percent_saved + '٪',
						].forEach( function ( value ) {
							var td = document.createElement( 'td' );
							td.textContent = value;
							tr.appendChild( td );
						} );
						tbody.appendChild( tr );
					} );
				}

				loadingEl.hidden = true;
				contentEl.hidden = false;
			} ).catch( function () {
				loadingEl.textContent = AISEO_ADMIN.i18n.error;
			} );
		}
	}

	/**
	 * پنل ماژول سئو: پردازش دسته‌ای متادیتا (همان الگوی aiseo_batch_* با پیشوند aiseo_seo_batch_*)،
	 * بررسی Alt، امتیاز کتابخانه و ساخت نقشه‌سایت.
	 */
	function initSeoPanel() {
		if ( typeof AISEO_ADMIN === 'undefined' ) {
			return;
		}

		initSeoBatch();
		initSeoAltCheck();
		initSeoScore();
		initSeoSitemap();

		function initSeoBatch() {
			var panel = document.getElementById( 'aiseo-seo-batch-panel' );
			if ( ! panel ) {
				return;
			}

			var startBtn = document.getElementById( 'aiseo-seo-batch-start' );
			var stopBtn = document.getElementById( 'aiseo-seo-batch-stop' );
			var retryBtn = document.getElementById( 'aiseo-seo-batch-retry' );
			var refreshBtn = document.getElementById( 'aiseo-seo-batch-refresh' );
			var statusEl = document.getElementById( 'aiseo-seo-batch-status' );
			var progressBar = document.getElementById( 'aiseo-seo-progress-bar' );
			var pendingEl = document.getElementById( 'aiseo-seo-stat-pending' );
			var processingEl = document.getElementById( 'aiseo-seo-stat-processing' );
			var doneEl = document.getElementById( 'aiseo-seo-stat-done' );
			var failedEl = document.getElementById( 'aiseo-seo-stat-failed' );

			var isRunning = false;
			var stopRequested = false;
			var totalAtStart = 0;

			refreshStats();

			startBtn.addEventListener( 'click', function () {
				if ( isRunning ) {
					return;
				}
				startBatch();
			} );

			stopBtn.addEventListener( 'click', function () {
				if ( ! isRunning ) {
					return;
				}
				stopRequested = true;
				stopBtn.disabled = true;
				statusEl.textContent = AISEO_ADMIN.i18n.stopped;
			} );

			retryBtn.addEventListener( 'click', function () {
				if ( isRunning ) {
					return;
				}
				retryBtn.disabled = true;
				statusEl.textContent = AISEO_ADMIN.i18n.retrying;

				postAction( 'aiseo_seo_batch_retry_failed' ).then( function ( res ) {
					retryBtn.disabled = false;
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}
					updateStatNumbers( res.data.stats );
					if ( ! res.data.requeued ) {
						statusEl.textContent = AISEO_ADMIN.i18n.noFailed;
						return;
					}
					totalAtStart = res.data.stats.pending;
					stopRequested = false;
					isRunning = true;
					toggleRunningButtons( true );
					runTick();
				} ).catch( finishWithError );
			} );

			refreshBtn.addEventListener( 'click', refreshStats );

			function refreshStats() {
				postAction( 'aiseo_seo_batch_stats' ).then( function ( res ) {
					if ( res && res.success ) {
						updateStatNumbers( res.data );
					}
				} );
			}

			function updateStatNumbers( stats ) {
				pendingEl.textContent = stats.pending;
				processingEl.textContent = stats.processing || 0;
				doneEl.textContent = stats.done;
				failedEl.textContent = stats.failed;
			}

			function updateProgress( remaining ) {
				if ( totalAtStart > 0 ) {
					var doneCount = totalAtStart - remaining;
					var pct = Math.max( 0, Math.min( 100, Math.round( ( doneCount / totalAtStart ) * 100 ) ) );
					progressBar.style.width = pct + '%';
				}
			}

			function toggleRunningButtons( running ) {
				startBtn.disabled = running;
				retryBtn.disabled = running;
				stopBtn.hidden = ! running;
				stopBtn.disabled = false;
			}

			function startBatch() {
				isRunning = true;
				stopRequested = false;
				progressBar.style.width = '0%';
				toggleRunningButtons( true );
				statusEl.textContent = AISEO_ADMIN.i18n.starting;

				postAction( 'aiseo_seo_batch_enqueue' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}
					updateStatNumbers( res.data.stats );
					totalAtStart = res.data.stats.pending;

					if ( totalAtStart <= 0 ) {
						statusEl.textContent = AISEO_ADMIN.i18n.seoNoNewImages;
						isRunning = false;
						toggleRunningButtons( false );
						return;
					}
					runTick();
				} ).catch( finishWithError );
			}

			function runTick() {
				if ( stopRequested ) {
					finishRun( false );
					return;
				}

				statusEl.textContent = AISEO_ADMIN.i18n.processing;

				postAction( 'aiseo_seo_batch_tick' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}

					var data = res.data;

					if ( data.locked ) {
						statusEl.textContent = AISEO_ADMIN.i18n.locked;
						if ( ! stopRequested ) {
							setTimeout( runTick, 3000 );
						} else {
							finishRun( false );
						}
						return;
					}

					pendingEl.textContent = data.remaining;
					processingEl.textContent = 0;
					doneEl.textContent = Number( doneEl.textContent || 0 ) + data.generated + data.skipped;
					failedEl.textContent = Number( failedEl.textContent || 0 ) + data.failed;
					updateProgress( data.remaining );

					if ( data.remaining > 0 && ! stopRequested ) {
						setTimeout( runTick, 400 );
					} else {
						finishRun( data.remaining <= 0 );
					}
				} ).catch( finishWithError );
			}

			function finishRun( completed ) {
				isRunning = false;
				toggleRunningButtons( false );
				refreshStats();
				statusEl.textContent = completed ? AISEO_ADMIN.i18n.seoDone : AISEO_ADMIN.i18n.stopped;
				if ( completed ) {
					progressBar.style.width = '100%';
				}
			}

			function finishWithError() {
				statusEl.textContent = AISEO_ADMIN.i18n.error;
				isRunning = false;
				toggleRunningButtons( false );
			}
		}

		function initSeoAltCheck() {
			var btn = document.getElementById( 'aiseo-seo-alt-check' );
			if ( ! btn ) {
				return;
			}

			btn.addEventListener( 'click', function () {
				btn.disabled = true;
				btn.textContent = AISEO_ADMIN.i18n.seoChecking;

				postAction( 'aiseo_seo_alt_check' ).then( function ( res ) {
					btn.disabled = false;
					btn.textContent = btn.getAttribute( 'data-label' ) || btn.textContent;

					if ( ! res || ! res.success ) {
						return;
					}

					var report = document.getElementById( 'aiseo-seo-alt-report' );
					document.getElementById( 'aiseo-alt-total' ).textContent = res.data.total;
					document.getElementById( 'aiseo-alt-missing' ).textContent = res.data.missing;
					document.getElementById( 'aiseo-alt-duplicate' ).textContent = res.data.duplicate;
					report.hidden = false;
				} );
			} );
		}

		function initSeoScore() {
			var loadingEl = document.getElementById( 'aiseo-seo-score-loading' );
			var contentEl = document.getElementById( 'aiseo-seo-score-content' );
			if ( ! loadingEl || ! contentEl ) {
				return;
			}

			loadingEl.hidden = false;
			loadingEl.textContent = AISEO_ADMIN.i18n.seoScoring;

			postAction( 'aiseo_seo_score_summary' ).then( function ( res ) {
				if ( ! res || ! res.success ) {
					loadingEl.textContent = AISEO_ADMIN.i18n.error;
					return;
				}

				document.getElementById( 'aiseo-seo-score-average' ).textContent = res.data.average;
				document.getElementById( 'aiseo-seo-score-good' ).textContent = res.data.good;
				document.getElementById( 'aiseo-seo-score-fair' ).textContent = res.data.fair;
				document.getElementById( 'aiseo-seo-score-poor' ).textContent = res.data.poor;

				loadingEl.hidden = true;
				contentEl.hidden = false;
			} ).catch( function () {
				loadingEl.textContent = AISEO_ADMIN.i18n.error;
			} );
		}

		function initSeoSitemap() {
			var btn = document.getElementById( 'aiseo-seo-sitemap-generate' );
			var statusEl = document.getElementById( 'aiseo-seo-sitemap-status' );
			if ( ! btn || ! statusEl ) {
				return;
			}

			btn.addEventListener( 'click', function () {
				btn.disabled = true;
				statusEl.textContent = AISEO_ADMIN.i18n.sitemapWorking;

				postAction( 'aiseo_seo_sitemap_generate' ).then( function ( res ) {
					btn.disabled = false;

					if ( ! res || ! res.success ) {
						statusEl.textContent = ( res && res.data && res.data.message ) ? res.data.message : AISEO_ADMIN.i18n.error;
						return;
					}

					statusEl.innerHTML = res.data.images + ' تصویر — <a href="' + res.data.url + '" target="_blank" rel="noopener">' + res.data.url + '</a>';
				} ).catch( function () {
					btn.disabled = false;
					statusEl.textContent = AISEO_ADMIN.i18n.error;
				} );
			} );
		}
	}

	/**
	 * پنل ماژول واترمارک (فاز ۵): سوییچ نوع متن/تصویر، انتخاب‌گر لوگو از کتابخانه‌ی رسانه‌ی
	 * وردپرس (wp.media)، و حلقه‌ی پردازش دسته‌ای — دقیقاً هم‌الگوی initSeoBatch بالا.
	 */
	function initWatermarkPanel() {
		if ( typeof AISEO_ADMIN === 'undefined' ) {
			return;
		}

		initWatermarkTypeToggle();
		initWatermarkLogoPicker();
		initWatermarkBatch();

		function initWatermarkTypeToggle() {
			var typeSelect = document.getElementById( 'aiseo_watermark_type' );
			if ( ! typeSelect ) {
				return;
			}

			var textFields = document.querySelectorAll( '.aiseo-watermark-field-text' );
			var imageFields = document.querySelectorAll( '.aiseo-watermark-field-image' );

			function sync() {
				var isImage = 'image' === typeSelect.value;
				textFields.forEach( function ( el ) {
					el.style.display = isImage ? 'none' : '';
				} );
				imageFields.forEach( function ( el ) {
					el.style.display = isImage ? '' : 'none';
				} );
			}

			typeSelect.addEventListener( 'change', sync );
			sync();
		}

		function initWatermarkLogoPicker() {
			var selectBtn = document.getElementById( 'aiseo-watermark-logo-select' );
			var removeBtn = document.getElementById( 'aiseo-watermark-logo-remove' );
			var hiddenInput = document.getElementById( 'aiseo_watermark_image_id' );
			var preview = document.getElementById( 'aiseo-watermark-logo-preview' );

			if ( ! selectBtn || ! hiddenInput || ! preview || typeof wp === 'undefined' || ! wp.media ) {
				return;
			}

			var frame = null;

			selectBtn.addEventListener( 'click', function ( e ) {
				e.preventDefault();

				if ( frame ) {
					frame.open();
					return;
				}

				frame = wp.media( {
					title: AISEO_ADMIN.i18n.wpMediaTitle,
					button: { text: AISEO_ADMIN.i18n.wpMediaButton },
					library: { type: 'image' },
					multiple: false,
				} );

				frame.on( 'select', function () {
					var attachment = frame.state().get( 'selection' ).first().toJSON();
					hiddenInput.value = attachment.id;
					preview.src = ( attachment.sizes && attachment.sizes.thumbnail ) ? attachment.sizes.thumbnail.url : attachment.url;
					preview.style.display = 'block';
					if ( removeBtn ) {
						removeBtn.style.display = '';
					}
				} );

				frame.open();
			} );

			if ( removeBtn ) {
				removeBtn.addEventListener( 'click', function ( e ) {
					e.preventDefault();
					hiddenInput.value = '0';
					preview.src = '';
					preview.style.display = 'none';
					removeBtn.style.display = 'none';
				} );
			}
		}

		function initWatermarkBatch() {
			var panel = document.getElementById( 'aiseo-watermark-batch-panel' );
			if ( ! panel ) {
				return;
			}

			var startBtn = document.getElementById( 'aiseo-watermark-batch-start' );
			var stopBtn = document.getElementById( 'aiseo-watermark-batch-stop' );
			var retryBtn = document.getElementById( 'aiseo-watermark-batch-retry' );
			var refreshBtn = document.getElementById( 'aiseo-watermark-batch-refresh' );
			var statusEl = document.getElementById( 'aiseo-watermark-batch-status' );
			var progressBar = document.getElementById( 'aiseo-watermark-progress-bar' );
			var pendingEl = document.getElementById( 'aiseo-watermark-stat-pending' );
			var processingEl = document.getElementById( 'aiseo-watermark-stat-processing' );
			var doneEl = document.getElementById( 'aiseo-watermark-stat-done' );
			var failedEl = document.getElementById( 'aiseo-watermark-stat-failed' );

			var isRunning = false;
			var stopRequested = false;
			var totalAtStart = 0;

			refreshStats();

			startBtn.addEventListener( 'click', function () {
				if ( isRunning ) {
					return;
				}
				startBatch();
			} );

			stopBtn.addEventListener( 'click', function () {
				if ( ! isRunning ) {
					return;
				}
				stopRequested = true;
				stopBtn.disabled = true;
				statusEl.textContent = AISEO_ADMIN.i18n.stopped;
			} );

			retryBtn.addEventListener( 'click', function () {
				if ( isRunning ) {
					return;
				}
				retryBtn.disabled = true;
				statusEl.textContent = AISEO_ADMIN.i18n.retrying;

				postAction( 'aiseo_watermark_batch_retry_failed' ).then( function ( res ) {
					retryBtn.disabled = false;
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}
					updateStatNumbers( res.data.stats );
					if ( ! res.data.requeued ) {
						statusEl.textContent = AISEO_ADMIN.i18n.noFailed;
						return;
					}
					totalAtStart = res.data.stats.pending;
					stopRequested = false;
					isRunning = true;
					toggleRunningButtons( true );
					runTick();
				} ).catch( finishWithError );
			} );

			refreshBtn.addEventListener( 'click', refreshStats );

			function refreshStats() {
				postAction( 'aiseo_watermark_batch_stats' ).then( function ( res ) {
					if ( res && res.success ) {
						updateStatNumbers( res.data );
					}
				} );
			}

			function updateStatNumbers( stats ) {
				pendingEl.textContent = stats.pending;
				processingEl.textContent = stats.processing || 0;
				doneEl.textContent = stats.done;
				failedEl.textContent = stats.failed;
			}

			function updateProgress( remaining ) {
				if ( totalAtStart > 0 ) {
					var doneCount = totalAtStart - remaining;
					var pct = Math.max( 0, Math.min( 100, Math.round( ( doneCount / totalAtStart ) * 100 ) ) );
					progressBar.style.width = pct + '%';
				}
			}

			function toggleRunningButtons( running ) {
				startBtn.disabled = running;
				retryBtn.disabled = running;
				stopBtn.hidden = ! running;
				stopBtn.disabled = false;
			}

			function startBatch() {
				isRunning = true;
				stopRequested = false;
				progressBar.style.width = '0%';
				toggleRunningButtons( true );
				statusEl.textContent = AISEO_ADMIN.i18n.starting;

				postAction( 'aiseo_watermark_batch_enqueue' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}
					updateStatNumbers( res.data.stats );
					totalAtStart = res.data.stats.pending;

					if ( totalAtStart <= 0 ) {
						statusEl.textContent = AISEO_ADMIN.i18n.watermarkNoNewImages;
						isRunning = false;
						toggleRunningButtons( false );
						return;
					}
					runTick();
				} ).catch( finishWithError );
			}

			function runTick() {
				if ( stopRequested ) {
					finishRun( false );
					return;
				}

				statusEl.textContent = AISEO_ADMIN.i18n.processing;

				postAction( 'aiseo_watermark_batch_tick' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}

					var data = res.data;

					if ( data.locked ) {
						statusEl.textContent = AISEO_ADMIN.i18n.locked;
						if ( ! stopRequested ) {
							setTimeout( runTick, 3000 );
						} else {
							finishRun( false );
						}
						return;
					}

					pendingEl.textContent = data.remaining;
					processingEl.textContent = 0;
					doneEl.textContent = Number( doneEl.textContent || 0 ) + data.applied + data.skipped;
					failedEl.textContent = Number( failedEl.textContent || 0 ) + data.failed;
					updateProgress( data.remaining );

					if ( data.remaining > 0 && ! stopRequested ) {
						setTimeout( runTick, 400 );
					} else {
						finishRun( data.remaining <= 0 );
					}
				} ).catch( finishWithError );
			}

			function finishRun( completed ) {
				isRunning = false;
				toggleRunningButtons( false );
				refreshStats();
				statusEl.textContent = completed ? AISEO_ADMIN.i18n.watermarkDone : AISEO_ADMIN.i18n.stopped;
				if ( completed ) {
					progressBar.style.width = '100%';
				}
			}

			function finishWithError() {
				statusEl.textContent = AISEO_ADMIN.i18n.error;
				isRunning = false;
				toggleRunningButtons( false );
			}
		}
	}

	/**
	 * پنل ماژول مدیریت کتابخانه‌ی رسانه (فاز ۷): داشبورد آماری + تشخیص تکراری (هش محتوا) +
	 * بررسی سلامت فایل/بازسازی thumbnail. دقیقاً هم‌الگوی initWatermarkPanel بالا برای
	 * بخش‌های پردازش دسته‌ای؛ به‌علاوه رندر لیست‌های نتیجه (گروه‌های تکراری، آیتم‌های مشکل‌دار).
	 */
	function initMediaLibraryPanel() {
		if ( typeof AISEO_ADMIN === 'undefined' ) {
			return;
		}

		initMlStats();
		initMlDuplicateBatch();
		initMlCleanupBatch();

		function escapeHtml( str ) {
			var div = document.createElement( 'div' );
			div.textContent = String( str == null ? '' : str );
			return div.innerHTML;
		}

		function mlCard( num, label, warn ) {
			return '<div class="aiseo-ml-card' + ( warn ? ' aiseo-ml-card-warn' : '' ) + '">' +
				'<span class="aiseo-ml-card-num">' + escapeHtml( num ) + '</span>' +
				'<span class="aiseo-ml-card-label">' + escapeHtml( label ) + '</span></div>';
		}

		// -------------------------------------------------------------
		// داشبورد آماری
		// -------------------------------------------------------------

		function initMlStats() {
			var container = document.getElementById( 'aiseo-ml-stats' );
			var formatList = document.getElementById( 'aiseo-ml-format-list' );
			var refreshBtn = document.getElementById( 'aiseo-ml-stats-refresh' );

			if ( ! container ) {
				return;
			}

			load();

			if ( refreshBtn ) {
				refreshBtn.addEventListener( 'click', load );
			}

			function load() {
				container.innerHTML = '<p class="aiseo-batch-status">' + AISEO_ADMIN.i18n.mlStatsLoading + '</p>';

				postAction( 'aiseo_ml_stats_summary' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						container.innerHTML = '<p class="aiseo-batch-status">' + AISEO_ADMIN.i18n.error + '</p>';
						return;
					}

					var d = res.data;
					var html = '';
					html += mlCard( d.total_images, 'تعداد کل تصاویر' );
					html += mlCard( formatBytes( d.health.total_size ), 'حجم بررسی‌شده' );
					html += mlCard( d.duplicates.groups, 'گروه تکراری', d.duplicates.groups > 0 );
					html += mlCard( d.duplicates.files, 'فایل درگیر تکراری', d.duplicates.files > 0 );
					html += mlCard( d.health.missing_file, 'فایل اصلی گم‌شده', d.health.missing_file > 0 );
					html += mlCard( d.health.missing_sizes, 'thumbnail ناقص', d.health.missing_sizes > 0 );
					html += mlCard( formatBytes( d.backup_size ), 'حجم پوشه‌ی بکاپ' );
					container.innerHTML = html;

					if ( formatList ) {
						var badges = [];
						Object.keys( d.format_breakdown || {} ).forEach( function ( key ) {
							badges.push( '<span class="aiseo-badge aiseo-badge-info">' + escapeHtml( key ) + ': ' + d.format_breakdown[ key ] + '</span>' );
						} );
						formatList.innerHTML = badges.join( '' );
						formatList.hidden = badges.length === 0;
					}
				} ).catch( function () {
					container.innerHTML = '<p class="aiseo-batch-status">' + AISEO_ADMIN.i18n.error + '</p>';
				} );
			}
		}

		// -------------------------------------------------------------
		// تشخیص تصاویر تکراری
		// -------------------------------------------------------------

		function initMlDuplicateBatch() {
			var panel = document.getElementById( 'aiseo-ml-duplicate-batch-panel' );
			if ( ! panel ) {
				return;
			}

			var startBtn = document.getElementById( 'aiseo-ml-dup-batch-start' );
			var stopBtn = document.getElementById( 'aiseo-ml-dup-batch-stop' );
			var retryBtn = document.getElementById( 'aiseo-ml-dup-batch-retry' );
			var groupsBtn = document.getElementById( 'aiseo-ml-dup-groups-refresh' );
			var statusEl = document.getElementById( 'aiseo-ml-dup-batch-status' );
			var progressBar = document.getElementById( 'aiseo-ml-dup-progress-bar' );
			var pendingEl = document.getElementById( 'aiseo-ml-dup-stat-pending' );
			var processingEl = document.getElementById( 'aiseo-ml-dup-stat-processing' );
			var doneEl = document.getElementById( 'aiseo-ml-dup-stat-done' );
			var failedEl = document.getElementById( 'aiseo-ml-dup-stat-failed' );
			var groupsContainer = document.getElementById( 'aiseo-ml-duplicate-groups' );

			var isRunning = false;
			var stopRequested = false;
			var totalAtStart = 0;

			refreshStats();

			startBtn.addEventListener( 'click', function () {
				if ( isRunning ) {
					return;
				}
				startBatch();
			} );

			stopBtn.addEventListener( 'click', function () {
				if ( ! isRunning ) {
					return;
				}
				stopRequested = true;
				stopBtn.disabled = true;
				statusEl.textContent = AISEO_ADMIN.i18n.stopped;
			} );

			retryBtn.addEventListener( 'click', function () {
				if ( isRunning ) {
					return;
				}
				retryBtn.disabled = true;
				statusEl.textContent = AISEO_ADMIN.i18n.retrying;

				postAction( 'aiseo_ml_duplicate_batch_retry_failed' ).then( function ( res ) {
					retryBtn.disabled = false;
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}
					updateStatNumbers( res.data.stats );
					if ( ! res.data.requeued ) {
						statusEl.textContent = AISEO_ADMIN.i18n.noFailed;
						return;
					}
					totalAtStart = res.data.stats.pending;
					stopRequested = false;
					isRunning = true;
					toggleRunningButtons( true );
					runTick();
				} ).catch( finishWithError );
			} );

			if ( groupsBtn ) {
				groupsBtn.addEventListener( 'click', loadGroups );
			}

			function refreshStats() {
				postAction( 'aiseo_ml_duplicate_batch_stats' ).then( function ( res ) {
					if ( res && res.success ) {
						updateStatNumbers( res.data );
					}
				} );
			}

			function updateStatNumbers( stats ) {
				pendingEl.textContent = stats.pending;
				processingEl.textContent = stats.processing || 0;
				doneEl.textContent = stats.done;
				failedEl.textContent = stats.failed;
			}

			function updateProgress( remaining ) {
				if ( totalAtStart > 0 ) {
					var doneCount = totalAtStart - remaining;
					var pct = Math.max( 0, Math.min( 100, Math.round( ( doneCount / totalAtStart ) * 100 ) ) );
					progressBar.style.width = pct + '%';
				}
			}

			function toggleRunningButtons( running ) {
				startBtn.disabled = running;
				retryBtn.disabled = running;
				stopBtn.hidden = ! running;
				stopBtn.disabled = false;
			}

			function startBatch() {
				isRunning = true;
				stopRequested = false;
				progressBar.style.width = '0%';
				toggleRunningButtons( true );
				statusEl.textContent = AISEO_ADMIN.i18n.starting;

				postAction( 'aiseo_ml_duplicate_batch_enqueue' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}
					updateStatNumbers( res.data.stats );
					totalAtStart = res.data.stats.pending;

					if ( totalAtStart <= 0 ) {
						statusEl.textContent = AISEO_ADMIN.i18n.mlDupNoNewImages;
						isRunning = false;
						toggleRunningButtons( false );
						return;
					}
					runTick();
				} ).catch( finishWithError );
			}

			function runTick() {
				if ( stopRequested ) {
					finishRun( false );
					return;
				}

				statusEl.textContent = AISEO_ADMIN.i18n.processing;

				postAction( 'aiseo_ml_duplicate_batch_tick' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}

					var data = res.data;

					if ( data.locked ) {
						statusEl.textContent = AISEO_ADMIN.i18n.locked;
						if ( ! stopRequested ) {
							setTimeout( runTick, 3000 );
						} else {
							finishRun( false );
						}
						return;
					}

					pendingEl.textContent = data.remaining;
					processingEl.textContent = 0;
					doneEl.textContent = Number( doneEl.textContent || 0 ) + data.hashed;
					failedEl.textContent = Number( failedEl.textContent || 0 ) + data.failed;
					updateProgress( data.remaining );

					if ( data.remaining > 0 && ! stopRequested ) {
						setTimeout( runTick, 400 );
					} else {
						finishRun( data.remaining <= 0 );
					}
				} ).catch( finishWithError );
			}

			function finishRun( completed ) {
				isRunning = false;
				toggleRunningButtons( false );
				refreshStats();
				statusEl.textContent = completed ? AISEO_ADMIN.i18n.mlDupDone : AISEO_ADMIN.i18n.stopped;
				if ( completed ) {
					progressBar.style.width = '100%';
				}
			}

			function finishWithError() {
				statusEl.textContent = AISEO_ADMIN.i18n.error;
				isRunning = false;
				toggleRunningButtons( false );
			}

			function loadGroups() {
				if ( ! groupsContainer ) {
					return;
				}
				groupsContainer.innerHTML = '<p class="aiseo-batch-status">' + AISEO_ADMIN.i18n.reportLoading + '</p>';

				postAction( 'aiseo_ml_duplicate_groups' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						groupsContainer.innerHTML = '<p class="aiseo-batch-status">' + AISEO_ADMIN.i18n.error + '</p>';
						return;
					}

					var groups = res.data.groups || [];

					if ( ! groups.length ) {
						groupsContainer.innerHTML = '<p class="aiseo-ml-empty">' + AISEO_ADMIN.i18n.mlDupNoGroups + '</p>';
						return;
					}

					groupsContainer.innerHTML = '';
					groups.forEach( function ( group ) {
						groupsContainer.appendChild( renderGroup( group ) );
					} );
				} ).catch( function () {
					groupsContainer.innerHTML = '<p class="aiseo-batch-status">' + AISEO_ADMIN.i18n.error + '</p>';
				} );
			}

			function renderGroup( group ) {
				var wrap = document.createElement( 'div' );
				wrap.className = 'aiseo-ml-group';

				var title = document.createElement( 'div' );
				title.className = 'aiseo-ml-group-title';
				title.textContent = group.count + ' فایل با محتوای یکسان';
				wrap.appendChild( title );

				group.items.forEach( function ( item ) {
					wrap.appendChild( renderDuplicateRow( item ) );
				} );

				return wrap;
			}

			function renderDuplicateRow( item ) {
				var row = document.createElement( 'div' );
				row.className = 'aiseo-ml-item-row';

				var img = document.createElement( 'img' );
				img.className = 'aiseo-ml-thumb';
				img.src = item.thumb || item.url;
				img.alt = '';
				row.appendChild( img );

				var info = document.createElement( 'div' );
				info.className = 'aiseo-ml-item-info';

				var titleEl = document.createElement( 'div' );
				titleEl.className = 'aiseo-ml-item-title';
				titleEl.textContent = item.title || item.filename;
				info.appendChild( titleEl );

				var metaEl = document.createElement( 'div' );
				metaEl.className = 'aiseo-ml-item-meta';
				metaEl.textContent = item.filename + ' — ' + formatBytes( item.filesize );
				info.appendChild( metaEl );

				row.appendChild( info );

				var actions = document.createElement( 'div' );
				actions.className = 'aiseo-ml-item-actions';

				if ( item.edit_link ) {
					var editLink = document.createElement( 'a' );
					editLink.href = item.edit_link;
					editLink.target = '_blank';
					editLink.rel = 'noopener';
					editLink.className = 'button button-small';
					editLink.textContent = 'ویرایش';
					actions.appendChild( editLink );
				}

				var deleteBtn = document.createElement( 'button' );
				deleteBtn.type = 'button';
				deleteBtn.className = 'button button-small';
				deleteBtn.textContent = 'حذف';
				deleteBtn.addEventListener( 'click', function () {
					if ( ! window.confirm( AISEO_ADMIN.i18n.mlDupConfirmDelete ) ) {
						return;
					}
					deleteBtn.disabled = true;

					postAction( 'aiseo_ml_delete_attachment', { attachment_id: item.id } ).then( function ( res ) {
						if ( ! res || ! res.success ) {
							deleteBtn.disabled = false;
							window.alert( ( res && res.data && res.data.message ) ? res.data.message : AISEO_ADMIN.i18n.error );
							return;
						}
						row.remove();
					} ).catch( function () {
						deleteBtn.disabled = false;
						window.alert( AISEO_ADMIN.i18n.error );
					} );
				} );
				actions.appendChild( deleteBtn );

				row.appendChild( actions );

				return row;
			}
		}

		// -------------------------------------------------------------
		// بررسی سلامت فایل / بازسازی thumbnail
		// -------------------------------------------------------------

		function initMlCleanupBatch() {
			var panel = document.getElementById( 'aiseo-ml-cleanup-batch-panel' );
			if ( ! panel ) {
				return;
			}

			var startBtn = document.getElementById( 'aiseo-ml-cln-batch-start' );
			var stopBtn = document.getElementById( 'aiseo-ml-cln-batch-stop' );
			var retryBtn = document.getElementById( 'aiseo-ml-cln-batch-retry' );
			var itemsBtn = document.getElementById( 'aiseo-ml-cln-items-refresh' );
			var statusEl = document.getElementById( 'aiseo-ml-cln-batch-status' );
			var progressBar = document.getElementById( 'aiseo-ml-cln-progress-bar' );
			var pendingEl = document.getElementById( 'aiseo-ml-cln-stat-pending' );
			var processingEl = document.getElementById( 'aiseo-ml-cln-stat-processing' );
			var doneEl = document.getElementById( 'aiseo-ml-cln-stat-done' );
			var failedEl = document.getElementById( 'aiseo-ml-cln-stat-failed' );
			var itemsContainer = document.getElementById( 'aiseo-ml-cleanup-items' );

			var isRunning = false;
			var stopRequested = false;
			var totalAtStart = 0;

			refreshStats();

			startBtn.addEventListener( 'click', function () {
				if ( isRunning ) {
					return;
				}
				startBatch();
			} );

			stopBtn.addEventListener( 'click', function () {
				if ( ! isRunning ) {
					return;
				}
				stopRequested = true;
				stopBtn.disabled = true;
				statusEl.textContent = AISEO_ADMIN.i18n.stopped;
			} );

			retryBtn.addEventListener( 'click', function () {
				if ( isRunning ) {
					return;
				}
				retryBtn.disabled = true;
				statusEl.textContent = AISEO_ADMIN.i18n.retrying;

				postAction( 'aiseo_ml_cleanup_batch_retry_failed' ).then( function ( res ) {
					retryBtn.disabled = false;
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}
					updateStatNumbers( res.data.stats );
					if ( ! res.data.requeued ) {
						statusEl.textContent = AISEO_ADMIN.i18n.noFailed;
						return;
					}
					totalAtStart = res.data.stats.pending;
					stopRequested = false;
					isRunning = true;
					toggleRunningButtons( true );
					runTick();
				} ).catch( finishWithError );
			} );

			if ( itemsBtn ) {
				itemsBtn.addEventListener( 'click', loadItems );
			}

			function refreshStats() {
				postAction( 'aiseo_ml_cleanup_batch_stats' ).then( function ( res ) {
					if ( res && res.success ) {
						updateStatNumbers( res.data );
					}
				} );
			}

			function updateStatNumbers( stats ) {
				pendingEl.textContent = stats.pending;
				processingEl.textContent = stats.processing || 0;
				doneEl.textContent = stats.done;
				failedEl.textContent = stats.failed;
			}

			function updateProgress( remaining ) {
				if ( totalAtStart > 0 ) {
					var doneCount = totalAtStart - remaining;
					var pct = Math.max( 0, Math.min( 100, Math.round( ( doneCount / totalAtStart ) * 100 ) ) );
					progressBar.style.width = pct + '%';
				}
			}

			function toggleRunningButtons( running ) {
				startBtn.disabled = running;
				retryBtn.disabled = running;
				stopBtn.hidden = ! running;
				stopBtn.disabled = false;
			}

			function startBatch() {
				isRunning = true;
				stopRequested = false;
				progressBar.style.width = '0%';
				toggleRunningButtons( true );
				statusEl.textContent = AISEO_ADMIN.i18n.starting;

				postAction( 'aiseo_ml_cleanup_batch_enqueue' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}
					updateStatNumbers( res.data.stats );
					totalAtStart = res.data.stats.pending;

					if ( totalAtStart <= 0 ) {
						statusEl.textContent = AISEO_ADMIN.i18n.mlClnNoNewImages;
						isRunning = false;
						toggleRunningButtons( false );
						return;
					}
					runTick();
				} ).catch( finishWithError );
			}

			function runTick() {
				if ( stopRequested ) {
					finishRun( false );
					return;
				}

				statusEl.textContent = AISEO_ADMIN.i18n.processing;

				postAction( 'aiseo_ml_cleanup_batch_tick' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						finishWithError();
						return;
					}

					var data = res.data;

					if ( data.locked ) {
						statusEl.textContent = AISEO_ADMIN.i18n.locked;
						if ( ! stopRequested ) {
							setTimeout( runTick, 3000 );
						} else {
							finishRun( false );
						}
						return;
					}

					pendingEl.textContent = data.remaining;
					processingEl.textContent = 0;
					doneEl.textContent = Number( doneEl.textContent || 0 ) + data.ok + data.fixed;
					failedEl.textContent = Number( failedEl.textContent || 0 ) + data.failed + data.missing_sizes + data.missing_file;
					updateProgress( data.remaining );

					if ( data.remaining > 0 && ! stopRequested ) {
						setTimeout( runTick, 400 );
					} else {
						finishRun( data.remaining <= 0 );
					}
				} ).catch( finishWithError );
			}

			function finishRun( completed ) {
				isRunning = false;
				toggleRunningButtons( false );
				refreshStats();
				statusEl.textContent = completed ? AISEO_ADMIN.i18n.mlClnDone : AISEO_ADMIN.i18n.stopped;
				if ( completed ) {
					progressBar.style.width = '100%';
				}
			}

			function finishWithError() {
				statusEl.textContent = AISEO_ADMIN.i18n.error;
				isRunning = false;
				toggleRunningButtons( false );
			}

			function loadItems() {
				if ( ! itemsContainer ) {
					return;
				}
				itemsContainer.innerHTML = '<p class="aiseo-batch-status">' + AISEO_ADMIN.i18n.reportLoading + '</p>';

				postAction( 'aiseo_ml_cleanup_items' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						itemsContainer.innerHTML = '<p class="aiseo-batch-status">' + AISEO_ADMIN.i18n.error + '</p>';
						return;
					}

					var items = res.data.items || [];

					if ( ! items.length ) {
						itemsContainer.innerHTML = '<p class="aiseo-ml-empty">' + AISEO_ADMIN.i18n.mlClnNoProblems + '</p>';
						return;
					}

					itemsContainer.innerHTML = '';
					items.forEach( function ( item ) {
						itemsContainer.appendChild( renderCleanupRow( item ) );
					} );
				} ).catch( function () {
					itemsContainer.innerHTML = '<p class="aiseo-batch-status">' + AISEO_ADMIN.i18n.error + '</p>';
				} );
			}

			function statusLabel( status ) {
				if ( 'missing_file' === status ) {
					return 'فایل اصلی گم‌شده';
				}
				if ( 'missing_sizes' === status ) {
					return 'thumbnail ناقص';
				}
				return status;
			}

			function renderCleanupRow( item ) {
				var row = document.createElement( 'div' );
				row.className = 'aiseo-ml-item-row';

				var img = document.createElement( 'img' );
				img.className = 'aiseo-ml-thumb';
				img.src = item.thumb || '';
				img.alt = '';
				row.appendChild( img );

				var info = document.createElement( 'div' );
				info.className = 'aiseo-ml-item-info';

				var titleEl = document.createElement( 'div' );
				titleEl.className = 'aiseo-ml-item-title';
				titleEl.textContent = item.title || ( '#' + item.id );
				info.appendChild( titleEl );

				var metaEl = document.createElement( 'div' );
				metaEl.className = 'aiseo-ml-item-meta';
				var metaText = statusLabel( item.status );
				if ( item.missing_sizes && item.missing_sizes.length ) {
					metaText += ' (' + item.missing_sizes.join( '، ' ) + ')';
				}
				metaEl.textContent = metaText;
				info.appendChild( metaEl );

				row.appendChild( info );

				var actions = document.createElement( 'div' );
				actions.className = 'aiseo-ml-item-actions';

				if ( item.edit_link ) {
					var editLink = document.createElement( 'a' );
					editLink.href = item.edit_link;
					editLink.target = '_blank';
					editLink.rel = 'noopener';
					editLink.className = 'button button-small';
					editLink.textContent = 'ویرایش';
					actions.appendChild( editLink );
				}

				if ( 'missing_sizes' === item.status ) {
					var rebuildBtn = document.createElement( 'button' );
					rebuildBtn.type = 'button';
					rebuildBtn.className = 'button button-small button-primary';
					rebuildBtn.textContent = 'بازسازی thumbnail ها';
					rebuildBtn.addEventListener( 'click', function () {
						rebuildBtn.disabled = true;
						rebuildBtn.textContent = AISEO_ADMIN.i18n.mlClnRebuilding;

						postAction( 'aiseo_ml_cleanup_rebuild_one', { attachment_id: item.id } ).then( function ( res ) {
							if ( ! res || ! res.success ) {
								rebuildBtn.disabled = false;
								rebuildBtn.textContent = 'بازسازی thumbnail ها';
								window.alert( ( res && res.data && res.data.message ) ? res.data.message : AISEO_ADMIN.i18n.error );
								return;
							}
							if ( 'ok' === res.data.status || 'fixed' === res.data.status ) {
								row.remove();
							} else {
								rebuildBtn.disabled = false;
								rebuildBtn.textContent = 'بازسازی thumbnail ها';
								metaEl.textContent = AISEO_ADMIN.i18n.mlClnRebuildDone + ' — ' + statusLabel( res.data.status );
							}
						} ).catch( function () {
							rebuildBtn.disabled = false;
							rebuildBtn.textContent = 'بازسازی thumbnail ها';
							window.alert( AISEO_ADMIN.i18n.error );
						} );
					} );
					actions.appendChild( rebuildBtn );
				}

				row.appendChild( actions );

				return row;
			}
		}
	}

} )();
