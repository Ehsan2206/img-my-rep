/**
 * ویرایشگر تصویر پیشرفته (فاز ۶): مودال تعاملی برش/تغییراندازه/چرخش/فلیپ/فیلتر +
 * Undo/Redo، به‌علاوه پنل پردازش دسته‌ای. بدون وابستگی به jQuery یا کتابخانه‌ی بیرونی؛
 * دقیقاً هم‌فلسفه‌ی admin.js (Vanilla JS، سبک، خودبسنده).
 *
 * دکمه‌ی «ویرایشگر تصویر AISEO» به‌صورت داینامیک توسط وردپرس (فیلتر attachment_fields_to_edit)
 * داخل مودال/فهرست کتابخانه‌ی رسانه رندر می‌شود؛ به همین دلیل باینداینگ کلیک با event
 * delegation روی document انجام می‌شود، نه querySelectorAll در زمان بارگذاری صفحه.
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		if ( typeof AISEO_ADMIN === 'undefined' ) {
			return;
		}
		initEditorOpenBinding();
		initEditorBatchPanel();
	} );

	function postAction( action, extra ) {
		var body = new URLSearchParams( Object.assign( { action: action, nonce: AISEO_ADMIN.nonce }, extra || {} ) );
		return fetch( AISEO_ADMIN.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: body.toString(),
		} ).then( function ( res ) {
			return res.json();
		} );
	}

	function t( key, fallback ) {
		if ( AISEO_ADMIN.i18n && AISEO_ADMIN.i18n[ key ] ) {
			return AISEO_ADMIN.i18n[ key ];
		}
		return fallback;
	}

	// -------------------------------------------------------------------
	// باز کردن ویرایشگر از دکمه‌ی داخل کتابخانه‌ی رسانه
	// -------------------------------------------------------------------

	function initEditorOpenBinding() {
		document.addEventListener( 'click', function ( e ) {
			var btn = e.target.closest( '.aiseo-editor-open' );
			if ( ! btn ) {
				return;
			}
			e.preventDefault();
			var attachmentId = parseInt( btn.getAttribute( 'data-attachment-id' ), 10 );
			if ( attachmentId ) {
				AiseoEditorModal.open( attachmentId );
			}
		} );
	}

	// -------------------------------------------------------------------
	// مودال ویرایشگر
	// -------------------------------------------------------------------

	var AiseoEditorModal = {
		el: null,
		attachmentId: 0,
		naturalWidth: 0,
		naturalHeight: 0,
		cropMode: false,
		cropRect: null, // { x, y, w, h } به مقیاس نمایش داده‌شده (px روی صفحه)

		open: function ( attachmentId ) {
			this.attachmentId = attachmentId;
			this.build();
			this.setStatus( t( 'editorLoading', 'در حال بارگذاری تصویر...' ) );
			this.refreshState();
		},

		build: function () {
			if ( this.el ) {
				this.el.remove();
			}

			var wrap = document.createElement( 'div' );
			wrap.className = 'aiseo-editor-overlay';
			wrap.innerHTML =
				'<div class="aiseo-editor-modal">' +
				'  <div class="aiseo-editor-modal-header">' +
				'    <span>' + escapeHtml( t( 'editorOpenTitle', 'ویرایشگر تصویر AISEO' ) ) + '</span>' +
				'    <button type="button" class="aiseo-editor-close" aria-label="close">&times;</button>' +
				'  </div>' +
				'  <div class="aiseo-editor-modal-body">' +
				'    <div class="aiseo-editor-canvas-wrap">' +
				'      <div class="aiseo-editor-canvas-stage">' +
				'        <img class="aiseo-editor-image" alt="" />' +
				'        <div class="aiseo-editor-crop-box" hidden></div>' +
				'      </div>' +
				'      <p class="aiseo-editor-status"></p>' +
				'    </div>' +
				'    <div class="aiseo-editor-tools">' +
				this.toolsMarkup() +
				'    </div>' +
				'  </div>' +
				'  <div class="aiseo-editor-modal-footer">' +
				'    <button type="button" class="button" id="aiseo-editor-undo">↶ Undo</button>' +
				'    <button type="button" class="button" id="aiseo-editor-redo">↷ Redo</button>' +
				'    <button type="button" class="button" id="aiseo-editor-reset">بازگشت به اصل</button>' +
				'    <span class="aiseo-editor-steps-info"></span>' +
				'    <button type="button" class="button button-primary aiseo-editor-close">' + escapeHtml( t( 'editorClose', 'بستن' ) ) + '</button>' +
				'  </div>' +
				'</div>';

			document.body.appendChild( wrap );
			this.el = wrap;
			this.bindEvents();
		},

		toolsMarkup: function () {
			return (
				'<div class="aiseo-editor-tool-group">' +
				'  <h4>برش (Crop)</h4>' +
				'  <button type="button" class="button" id="aiseo-editor-crop-toggle">شروع انتخاب برش</button>' +
				'  <button type="button" class="button button-primary" id="aiseo-editor-crop-apply" disabled>اعمال برش</button>' +
				'</div>' +
				'<div class="aiseo-editor-tool-group">' +
				'  <h4>چرخش / فلیپ</h4>' +
				'  <button type="button" class="button" data-op="rotate" data-degrees="-90">↺ ۹۰°</button>' +
				'  <button type="button" class="button" data-op="rotate" data-degrees="90">↻ ۹۰°</button>' +
				'  <button type="button" class="button" data-op="rotate" data-degrees="180">۱۸۰°</button>' +
				'  <button type="button" class="button" data-op="flip" data-axis="horizontal">فلیپ افقی</button>' +
				'  <button type="button" class="button" data-op="flip" data-axis="vertical">فلیپ عمودی</button>' +
				'</div>' +
				'<div class="aiseo-editor-tool-group">' +
				'  <h4>تغییر اندازه</h4>' +
				'  <label>عرض <input type="number" id="aiseo-editor-resize-w" min="1" /></label>' +
				'  <label>ارتفاع <input type="number" id="aiseo-editor-resize-h" min="1" /></label>' +
				'  <label><input type="checkbox" id="aiseo-editor-resize-aspect" checked /> حفظ نسبت</label>' +
				'  <button type="button" class="button button-primary" id="aiseo-editor-resize-apply">اعمال تغییر اندازه</button>' +
				'</div>' +
				'<div class="aiseo-editor-tool-group">' +
				'  <h4>فیلترها</h4>' +
				'  <label>روشنایی <input type="range" id="aiseo-editor-brightness" min="-100" max="100" value="0" /></label>' +
				'  <button type="button" class="button" id="aiseo-editor-brightness-apply">اعمال روشنایی</button>' +
				'  <label>کنتراست <input type="range" id="aiseo-editor-contrast" min="-100" max="100" value="0" /></label>' +
				'  <button type="button" class="button" id="aiseo-editor-contrast-apply">اعمال کنتراست</button>' +
				'  <button type="button" class="button" data-op="filter" data-filter="grayscale">گری‌اسکیل</button>' +
				'  <label>آستانه‌ی سیاه‌وسفید <input type="range" id="aiseo-editor-bw-threshold" min="0" max="255" value="128" /></label>' +
				'  <button type="button" class="button" id="aiseo-editor-bw-apply">اعمال سیاه‌وسفید</button>' +
				'</div>'
			);
		},

		bindEvents: function () {
			var self = this;
			this.el.querySelectorAll( '.aiseo-editor-close' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					self.close();
				} );
			} );

			this.el.querySelectorAll( '[data-op="rotate"]' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					self.apply( 'rotate', { degrees: parseFloat( btn.getAttribute( 'data-degrees' ) ) } );
				} );
			} );
			this.el.querySelectorAll( '[data-op="flip"]' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					self.apply( 'flip', { axis: btn.getAttribute( 'data-axis' ) } );
				} );
			} );
			this.el.querySelectorAll( '[data-op="filter"]' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					self.apply( 'filter', { filter: btn.getAttribute( 'data-filter' ) } );
				} );
			} );

			this.el.querySelector( '#aiseo-editor-brightness-apply' ).addEventListener( 'click', function () {
				var amount = parseInt( self.el.querySelector( '#aiseo-editor-brightness' ).value, 10 );
				self.apply( 'filter', { filter: 'brightness', amount: amount } );
			} );
			this.el.querySelector( '#aiseo-editor-contrast-apply' ).addEventListener( 'click', function () {
				var amount = parseInt( self.el.querySelector( '#aiseo-editor-contrast' ).value, 10 );
				self.apply( 'filter', { filter: 'contrast', amount: amount } );
			} );
			this.el.querySelector( '#aiseo-editor-bw-apply' ).addEventListener( 'click', function () {
				var amount = parseInt( self.el.querySelector( '#aiseo-editor-bw-threshold' ).value, 10 );
				self.apply( 'filter', { filter: 'bw', amount: amount } );
			} );

			this.el.querySelector( '#aiseo-editor-resize-apply' ).addEventListener( 'click', function () {
				var w = parseInt( self.el.querySelector( '#aiseo-editor-resize-w' ).value, 10 );
				var h = parseInt( self.el.querySelector( '#aiseo-editor-resize-h' ).value, 10 );
				var keepAspect = self.el.querySelector( '#aiseo-editor-resize-aspect' ).checked;
				if ( w > 0 && h > 0 ) {
					self.apply( 'resize', { width: w, height: h, keep_aspect: keepAspect } );
				}
			} );

			this.el.querySelector( '#aiseo-editor-undo' ).addEventListener( 'click', function () {
				self.callSimple( 'aiseo_editor_undo' );
			} );
			this.el.querySelector( '#aiseo-editor-redo' ).addEventListener( 'click', function () {
				self.callSimple( 'aiseo_editor_redo' );
			} );
			this.el.querySelector( '#aiseo-editor-reset' ).addEventListener( 'click', function () {
				if ( window.confirm( t( 'editorConfirmReset', 'تصویر به نسخه‌ی اصلی بازگردانده شود؟ همه‌ی مراحل ویرایش از دست می‌روند.' ) ) ) {
					self.callSimple( 'aiseo_editor_reset' );
				}
			} );

			this.el.querySelector( '#aiseo-editor-crop-toggle' ).addEventListener( 'click', function () {
				self.toggleCropMode();
			} );
			this.el.querySelector( '#aiseo-editor-crop-apply' ).addEventListener( 'click', function () {
				self.applyCrop();
			} );

			this.initCropDrag();
		},

		close: function () {
			if ( this.el ) {
				this.el.remove();
				this.el = null;
			}
		},

		setStatus: function ( text, isError ) {
			var el = this.el && this.el.querySelector( '.aiseo-editor-status' );
			if ( el ) {
				el.textContent = text || '';
				el.classList.toggle( 'aiseo-editor-status-error', !! isError );
			}
		},

		setBusy: function ( busy ) {
			if ( ! this.el ) {
				return;
			}
			this.el.querySelectorAll( 'button, input' ).forEach( function ( elm ) {
				elm.disabled = busy && ! elm.classList.contains( 'aiseo-editor-close' );
			} );
			if ( busy ) {
				this.setStatus( t( 'editorApplying', 'در حال اعمال تغییرات...' ) );
			}
		},

		refreshState: function () {
			var self = this;
			postAction( 'aiseo_editor_get_state', { attachment_id: this.attachmentId } ).then( function ( res ) {
				if ( ! res.success ) {
					self.setStatus( ( res.data && res.data.message ) || t( 'editorError', 'خطایی رخ داد.' ), true );
					return;
				}
				self.applyServerResponse( res.data );
				self.setStatus( '' );
			} ).catch( function () {
				self.setStatus( t( 'editorError', 'خطایی رخ داد. لطفاً دوباره تلاش کنید.' ), true );
			} );
		},

		applyServerResponse: function ( data ) {
			if ( ! this.el ) {
				return;
			}
			var img = this.el.querySelector( '.aiseo-editor-image' );
			img.src = data.url;
			this.naturalWidth = data.width;
			this.naturalHeight = data.height;

			var wInput = this.el.querySelector( '#aiseo-editor-resize-w' );
			var hInput = this.el.querySelector( '#aiseo-editor-resize-h' );
			if ( wInput && ! wInput.value ) {
				wInput.value = data.width;
			}
			if ( hInput && ! hInput.value ) {
				hInput.value = data.height;
			}

			var st = data.state || {};
			this.el.querySelector( '#aiseo-editor-undo' ).disabled = ! st.can_undo;
			this.el.querySelector( '#aiseo-editor-redo' ).disabled = ! st.can_redo;
			this.el.querySelector( '.aiseo-editor-steps-info' ).textContent =
				'مرحله ' + ( ( st.pointer || 0 ) + 1 ) + ' از ' + ( st.steps || 1 );

			this.exitCropMode();
		},

		apply: function ( op, args ) {
			var self = this;
			this.setBusy( true );
			postAction( 'aiseo_editor_apply', {
				attachment_id: this.attachmentId,
				op: op,
				args: JSON.stringify( args ),
			} ).then( function ( res ) {
				self.setBusy( false );
				if ( ! res.success ) {
					self.setStatus( ( res.data && res.data.message ) || t( 'editorError', 'خطایی رخ داد.' ), true );
					return;
				}
				self.applyServerResponse( res.data );
			} ).catch( function () {
				self.setBusy( false );
				self.setStatus( t( 'editorError', 'خطایی رخ داد. لطفاً دوباره تلاش کنید.' ), true );
			} );
		},

		callSimple: function ( action ) {
			var self = this;
			this.setBusy( true );
			postAction( action, { attachment_id: this.attachmentId } ).then( function ( res ) {
				self.setBusy( false );
				if ( ! res.success ) {
					self.setStatus( ( res.data && res.data.message ) || t( 'editorError', 'خطایی رخ داد.' ), true );
					return;
				}
				self.applyServerResponse( res.data );
			} ).catch( function () {
				self.setBusy( false );
				self.setStatus( t( 'editorError', 'خطایی رخ داد. لطفاً دوباره تلاش کنید.' ), true );
			} );
		},

		// -------------------------------------------------------------
		// ابزار برش تعاملی: یک مستطیل کشیدنی روی تصویر نمایش داده‌شده
		// -------------------------------------------------------------

		toggleCropMode: function () {
			this.cropMode ? this.exitCropMode() : this.enterCropMode();
		},

		enterCropMode: function () {
			this.cropMode = true;
			var img = this.el.querySelector( '.aiseo-editor-image' );
			var box = this.el.querySelector( '.aiseo-editor-crop-box' );
			var rect = img.getBoundingClientRect();

			this.cropRect = { x: rect.width * 0.1, y: rect.height * 0.1, w: rect.width * 0.8, h: rect.height * 0.8 };
			box.hidden = false;
			this.el.querySelector( '#aiseo-editor-crop-apply' ).disabled = false;
			this.el.querySelector( '#aiseo-editor-crop-toggle' ).textContent = 'لغو انتخاب برش';
			this.renderCropBox();
		},

		exitCropMode: function () {
			this.cropMode = false;
			this.cropRect = null;
			if ( ! this.el ) {
				return;
			}
			this.el.querySelector( '.aiseo-editor-crop-box' ).hidden = true;
			this.el.querySelector( '#aiseo-editor-crop-apply' ).disabled = true;
			this.el.querySelector( '#aiseo-editor-crop-toggle' ).textContent = 'شروع انتخاب برش';
		},

		renderCropBox: function () {
			var box = this.el.querySelector( '.aiseo-editor-crop-box' );
			var r = this.cropRect;
			box.style.left = r.x + 'px';
			box.style.top = r.y + 'px';
			box.style.width = r.w + 'px';
			box.style.height = r.h + 'px';
		},

		initCropDrag: function () {
			var self = this;
			var box = this.el.querySelector( '.aiseo-editor-crop-box' );
			var stage = this.el.querySelector( '.aiseo-editor-canvas-stage' );
			var dragging = false;
			var startX = 0;
			var startY = 0;
			var startRect = null;

			box.addEventListener( 'pointerdown', function ( e ) {
				if ( ! self.cropMode ) {
					return;
				}
				dragging = true;
				startX = e.clientX;
				startY = e.clientY;
				startRect = Object.assign( {}, self.cropRect );
				box.setPointerCapture( e.pointerId );
			} );

			box.addEventListener( 'pointermove', function ( e ) {
				if ( ! dragging ) {
					return;
				}
				var stageRect = stage.getBoundingClientRect();
				var dx = e.clientX - startX;
				var dy = e.clientY - startY;

				var newX = clamp( startRect.x + dx, 0, stageRect.width - startRect.w );
				var newY = clamp( startRect.y + dy, 0, stageRect.height - startRect.h );

				self.cropRect.x = newX;
				self.cropRect.y = newY;
				self.renderCropBox();
			} );

			box.addEventListener( 'pointerup', function () {
				dragging = false;
			} );
		},

		applyCrop: function () {
			if ( ! this.cropRect ) {
				return;
			}
			var img = this.el.querySelector( '.aiseo-editor-image' );
			var rect = img.getBoundingClientRect();
			var scaleX = this.naturalWidth / rect.width;
			var scaleY = this.naturalHeight / rect.height;

			var args = {
				x: Math.round( this.cropRect.x * scaleX ),
				y: Math.round( this.cropRect.y * scaleY ),
				width: Math.round( this.cropRect.w * scaleX ),
				height: Math.round( this.cropRect.h * scaleY ),
			};

			this.apply( 'crop', args );
		},
	};

	function clamp( value, min, max ) {
		return Math.max( min, Math.min( max, value ) );
	}

	function escapeHtml( str ) {
		var div = document.createElement( 'div' );
		div.textContent = String( str || '' );
		return div.innerHTML;
	}

	// -------------------------------------------------------------------
	// پنل پردازش دسته‌ای ویرایشگر (همان الگوی initWatermarkPanel در admin.js)
	// -------------------------------------------------------------------

	function initEditorBatchPanel() {
		var panel = document.getElementById( 'aiseo-editor-batch-panel' );
		if ( ! panel ) {
			return;
		}

		var startBtn = document.getElementById( 'aiseo-editor-batch-start' );
		var stopBtn = document.getElementById( 'aiseo-editor-batch-stop' );
		var retryBtn = document.getElementById( 'aiseo-editor-batch-retry' );
		var refreshBtn = document.getElementById( 'aiseo-editor-batch-refresh' );
		var statusEl = document.getElementById( 'aiseo-editor-batch-status' );
		var progressBar = document.getElementById( 'aiseo-editor-progress-bar' );
		var pendingEl = document.getElementById( 'aiseo-editor-stat-pending' );
		var processingEl = document.getElementById( 'aiseo-editor-stat-processing' );
		var doneEl = document.getElementById( 'aiseo-editor-stat-done' );
		var failedEl = document.getElementById( 'aiseo-editor-stat-failed' );

		var isRunning = false;
		var stopRequested = false;
		var totalAtStart = 0;

		refreshStats();

		startBtn.addEventListener( 'click', function () {
			stopRequested = false;
			startBtn.hidden = true;
			stopBtn.hidden = false;
			statusEl.textContent = 'در حال اسکن کتابخانه...';

			postAction( 'aiseo_editor_batch_enqueue' ).then( function ( res ) {
				if ( ! res.success ) {
					statusEl.textContent = ( res.data && res.data.message ) || t( 'editorError', 'خطایی رخ داد.' );
					stopBatchUi();
					return;
				}
				if ( ! res.data.added && res.data.stats.pending === 0 ) {
					statusEl.textContent = t( 'editorBatchNoNewImages', 'همه‌ی تصاویر بررسی شده‌اند؛ موردی برای پردازش نیست.' );
					updateStats( res.data.stats );
					stopBatchUi();
					return;
				}
				totalAtStart = res.data.stats.pending;
				updateStats( res.data.stats );
				isRunning = true;
				runTick();
			} );
		} );

		stopBtn.addEventListener( 'click', function () {
			stopRequested = true;
			statusEl.textContent = 'در حال توقف...';
		} );

		retryBtn.addEventListener( 'click', function () {
			postAction( 'aiseo_editor_batch_retry_failed' ).then( function ( res ) {
				if ( res.success ) {
					updateStats( res.data.stats );
					statusEl.textContent = res.data.requeued + ' آیتم ناموفق دوباره به صف اضافه شد.';
				}
			} );
		} );

		refreshBtn.addEventListener( 'click', refreshStats );

		function runTick() {
			if ( stopRequested ) {
				statusEl.textContent = 'متوقف شد.';
				stopBatchUi();
				return;
			}

			postAction( 'aiseo_editor_batch_tick' ).then( function ( res ) {
				if ( ! res.success ) {
					statusEl.textContent = ( res.data && res.data.message ) || t( 'editorError', 'خطایی رخ داد.' );
					stopBatchUi();
					return;
				}

				var data = res.data;
				updateStats( { pending: data.remaining, processing: 0, done: doneEl.textContent, failed: failedEl.textContent } );

				if ( data.processed === 0 && data.remaining === 0 ) {
					statusEl.textContent = t( 'editorBatchDone', 'پردازش دسته‌ای ویرایشگر با موفقیت به پایان رسید.' );
					refreshStats();
					stopBatchUi();
					return;
				}

				statusEl.textContent = data.remaining + ' تصویر باقی مانده...';
				setTimeout( runTick, data.locked ? 1500 : 300 );
			} ).catch( function () {
				statusEl.textContent = t( 'editorError', 'خطایی رخ داد. لطفاً دوباره تلاش کنید.' );
				stopBatchUi();
			} );
		}

		function stopBatchUi() {
			isRunning = false;
			startBtn.hidden = false;
			stopBtn.hidden = true;
		}

		function refreshStats() {
			postAction( 'aiseo_editor_batch_stats' ).then( function ( res ) {
				if ( res.success ) {
					updateStats( res.data );
				}
			} );
		}

		function updateStats( stats ) {
			pendingEl.textContent = stats.pending;
			processingEl.textContent = stats.processing || 0;
			doneEl.textContent = stats.done;
			failedEl.textContent = stats.failed;

			if ( totalAtStart > 0 ) {
				var done = totalAtStart - stats.pending;
				var pct = Math.min( 100, Math.round( ( done / totalAtStart ) * 100 ) );
				progressBar.style.width = pct + '%';
			}
		}
	}
} )();
