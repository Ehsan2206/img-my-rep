<?php
/**
 * @var \AISEO\Server_Capabilities $server_capabilities
 * @var \AISEO\Logger              $logger
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$caps = $server_capabilities->detect();

$badge = function ( bool $ok ) {
	return $ok
		? '<span class="aiseo-badge aiseo-badge-ok">' . esc_html__( 'موجود', 'advanced-image-seo-optimizer' ) . '</span>'
		: '<span class="aiseo-badge aiseo-badge-off">' . esc_html__( 'ناموجود', 'advanced-image-seo-optimizer' ) . '</span>';
};
?>
<div class="wrap aiseo-wrap">
	<h1><?php esc_html_e( 'وضعیت سرور', 'advanced-image-seo-optimizer' ); ?></h1>

	<h2><?php esc_html_e( 'کتابخانه‌های تصویر', 'advanced-image-seo-optimizer' ); ?></h2>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'قابلیت', 'advanced-image-seo-optimizer' ); ?></th>
				<th><?php esc_html_e( 'وضعیت', 'advanced-image-seo-optimizer' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<tr><td>GD</td><td><?php echo wp_kses_post( $badge( $caps['gd']['available'] ) ); ?> <?php echo $caps['gd']['version'] ? esc_html( $caps['gd']['version'] ) : ''; ?></td></tr>
			<tr><td>Imagick</td><td><?php echo wp_kses_post( $badge( $caps['imagick']['available'] ) ); ?></td></tr>
			<tr><td><?php esc_html_e( 'خروجی WebP (GD)', 'advanced-image-seo-optimizer' ); ?></td><td><?php echo wp_kses_post( $badge( $caps['gd']['webp'] ) ); ?></td></tr>
			<tr><td><?php esc_html_e( 'خروجی AVIF (GD)', 'advanced-image-seo-optimizer' ); ?></td><td><?php echo wp_kses_post( $badge( $caps['gd']['avif'] ) ); ?></td></tr>
			<tr><td><?php esc_html_e( 'خروجی WebP (Imagick)', 'advanced-image-seo-optimizer' ); ?></td><td><?php echo wp_kses_post( $badge( $caps['imagick']['webp'] ) ); ?></td></tr>
			<tr><td><?php esc_html_e( 'خروجی AVIF (Imagick)', 'advanced-image-seo-optimizer' ); ?></td><td><?php echo wp_kses_post( $badge( $caps['imagick']['avif'] ) ); ?></td></tr>
			<tr><td><?php esc_html_e( 'پشتیبانی SVG (Imagick)', 'advanced-image-seo-optimizer' ); ?></td><td><?php echo wp_kses_post( $badge( $caps['imagick']['svg'] ) ); ?></td></tr>
			<tr><td><?php esc_html_e( 'پشتیبانی TIFF (Imagick)', 'advanced-image-seo-optimizer' ); ?></td><td><?php echo wp_kses_post( $badge( $caps['imagick']['tiff'] ) ); ?></td></tr>
		</tbody>
	</table>

	<h2><?php esc_html_e( 'محدودیت‌های PHP', 'advanced-image-seo-optimizer' ); ?></h2>
	<table class="widefat striped">
		<tbody>
			<tr><td>memory_limit</td><td><?php echo esc_html( $caps['memory_limit'] ); ?></td></tr>
			<tr><td>max_execution_time</td><td><?php echo esc_html( $caps['max_execution_time'] ); ?></td></tr>
		</tbody>
	</table>

	<h2><?php esc_html_e( 'آخرین رویدادهای ثبت‌شده', 'advanced-image-seo-optimizer' ); ?></h2>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'زمان', 'advanced-image-seo-optimizer' ); ?></th>
				<th><?php esc_html_e( 'سطح', 'advanced-image-seo-optimizer' ); ?></th>
				<th><?php esc_html_e( 'ماژول', 'advanced-image-seo-optimizer' ); ?></th>
				<th><?php esc_html_e( 'پیام', 'advanced-image-seo-optimizer' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php
			$logs = $logger->get_recent( 30 );
			if ( empty( $logs ) ) :
				?>
				<tr><td colspan="4"><?php esc_html_e( 'هنوز هیچ لاگی ثبت نشده.', 'advanced-image-seo-optimizer' ); ?></td></tr>
				<?php
			endif;
			foreach ( $logs as $log ) :
				?>
				<tr>
					<td><?php echo esc_html( $log->created_at ); ?></td>
					<td><span class="aiseo-badge aiseo-badge-<?php echo esc_attr( $log->level ); ?>"><?php echo esc_html( $log->level ); ?></span></td>
					<td><?php echo esc_html( $log->module ); ?></td>
					<td><?php echo esc_html( $log->message ); ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>
