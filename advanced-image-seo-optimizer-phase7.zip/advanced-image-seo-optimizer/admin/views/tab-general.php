<?php
/** @var \AISEO\Settings $settings */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<h2><?php esc_html_e( 'تنظیمات عمومی', 'advanced-image-seo-optimizer' ); ?></h2>
<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'فعال‌سازی تبدیل خودکار', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_opt_enable_conversion" value="1" <?php checked( 1, get_option( 'aiseo_opt_enable_conversion', 1 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
			<p class="description"><?php esc_html_e( 'تصاویر هنگام آپلود به‌طور خودکار بهینه‌سازی و تبدیل شوند.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'فرمت خروجی', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label><input type="radio" name="aiseo_opt_output_format" value="webp" <?php checked( 'webp', get_option( 'aiseo_opt_output_format', 'webp' ) ); ?> /> WebP</label>
			&nbsp;&nbsp;
			<label><input type="radio" name="aiseo_opt_output_format" value="avif" <?php checked( 'avif', get_option( 'aiseo_opt_output_format', 'webp' ) ); ?> /> AVIF</label>
			<p class="description"><?php esc_html_e( 'GIF‌ها همیشه به WebP تبدیل می‌شوند تا انیمیشن حفظ شود.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'حفظ نسخه‌ی اصلی', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_opt_keep_original_backup" value="1" <?php checked( 1, get_option( 'aiseo_opt_keep_original_backup', 1 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
			<p class="description"><?php esc_html_e( 'توصیه‌شده: فایل اصلی حذف نمی‌شود، بلکه در پوشه‌ای محافظت‌شده نگه‌داری و قابل بازگردانی می‌ماند.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
</table>
