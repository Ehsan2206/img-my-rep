<?php
/** @var \AISEO\Settings $settings */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<h2><?php esc_html_e( 'ویرایشگر تصویر پیشرفته', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description">
	<?php esc_html_e( 'ویرایش تعاملی (برش، تغییر اندازه، چرخش/فلیپ، فیلترها) از داخل کتابخانه‌ی رسانه انجام می‌شود: روی هر تصویر کلیک کنید و دکمه‌ی «ویرایشگر تصویر AISEO» را بزنید. تمام ویرایش‌ها غیرمخرب است و همیشه قابل بازگشت به نسخه‌ی اصلی.', 'advanced-image-seo-optimizer' ); ?>
</p>

<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><label for="aiseo_editor_max_history"><?php esc_html_e( 'حداکثر مراحل Undo برای هر تصویر', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td>
			<input type="number" id="aiseo_editor_max_history" name="aiseo_editor_max_history" min="1" max="50"
				value="<?php echo esc_attr( $settings->get_editor_max_history() ); ?>" />
			<p class="description"><?php esc_html_e( 'نسخه‌ی اصلی همیشه جدا نگه داشته می‌شود و در این سقف حساب نمی‌شود؛ فقط تعداد مراحل میانی محدود است.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_editor_jpeg_quality"><?php esc_html_e( 'کیفیت خروجی JPEG/WebP', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td>
			<input type="number" id="aiseo_editor_jpeg_quality" name="aiseo_editor_jpeg_quality" min="1" max="100"
				value="<?php echo esc_attr( $settings->get_editor_jpeg_quality() ); ?>" />
			<p class="description"><?php esc_html_e( 'برای هر بار ذخیره‌ی نتیجه‌ی ویرایش (تک‌تصویری یا دسته‌ای) استفاده می‌شود.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_editor_batch_operation"><?php esc_html_e( 'عملیات پردازش دسته‌ای', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td>
			<?php $batch_op = $settings->get_editor_batch_operation(); ?>
			<select id="aiseo_editor_batch_operation" name="aiseo_editor_batch_operation">
				<option value="rotate_cw" <?php selected( 'rotate_cw', $batch_op ); ?>><?php esc_html_e( 'چرخش ۹۰ درجه ساعت‌گرد', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="rotate_ccw" <?php selected( 'rotate_ccw', $batch_op ); ?>><?php esc_html_e( 'چرخش ۹۰ درجه پادساعت‌گرد', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="rotate_180" <?php selected( 'rotate_180', $batch_op ); ?>><?php esc_html_e( 'چرخش ۱۸۰ درجه', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="flip_h" <?php selected( 'flip_h', $batch_op ); ?>><?php esc_html_e( 'فلیپ افقی', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="flip_v" <?php selected( 'flip_v', $batch_op ); ?>><?php esc_html_e( 'فلیپ عمودی', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="grayscale" <?php selected( 'grayscale', $batch_op ); ?>><?php esc_html_e( 'گری‌اسکیل', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="bw" <?php selected( 'bw', $batch_op ); ?>><?php esc_html_e( 'سیاه‌وسفید (Threshold)', 'advanced-image-seo-optimizer' ); ?></option>
			</select>
			<p class="description"><?php esc_html_e( 'این یک عملیات، هنگام «شروع پردازش دسته‌ای» زیر روی همه‌ی تصاویر کتابخانه اعمال می‌شود. برای اعمال ترکیبی از چند تغییر، از ویرایشگر تعاملی روی هر تصویر استفاده کنید.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
</table>

<hr class="aiseo-report-divider" />

<h2><?php esc_html_e( 'پردازش دسته‌ای ویرایشگر', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description"><?php esc_html_e( 'عملیات انتخاب‌شده در بالا را روی کل کتابخانه‌ی رسانه اعمال می‌کند. هر تصویر همچنان از طریق ویرایشگر تعاملی قابل Undo/بازگشت به اصل است؛ اگر تنظیمات را بعداً تغییر دهید، دفعه‌ی بعد باید دوباره اسکن کنید.', 'advanced-image-seo-optimizer' ); ?></p>
<div id="aiseo-editor-batch-panel" class="aiseo-batch-panel">
	<div class="aiseo-batch-stats">
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-editor-stat-pending">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در انتظار', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-editor-stat-processing">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در حال پردازش', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-editor-stat-done">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'انجام‌شده', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat aiseo-stat-warn"><span class="aiseo-stat-num" id="aiseo-editor-stat-failed">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'ناموفق', 'advanced-image-seo-optimizer' ); ?></span></div>
	</div>
	<div class="aiseo-progress-bar-wrap"><div id="aiseo-editor-progress-bar" class="aiseo-progress-bar"></div></div>
	<p id="aiseo-editor-batch-status" class="aiseo-batch-status"></p>
	<div class="aiseo-batch-actions">
		<button type="button" id="aiseo-editor-batch-start" class="button button-primary"><?php esc_html_e( 'اسکن و شروع پردازش', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-editor-batch-stop" class="button" hidden><?php esc_html_e( 'توقف', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-editor-batch-retry" class="button"><?php esc_html_e( 'تلاش مجدد آیتم‌های ناموفق', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-editor-batch-refresh" class="button"><?php esc_html_e( 'به‌روزرسانی وضعیت', 'advanced-image-seo-optimizer' ); ?></button>
	</div>
</div>
