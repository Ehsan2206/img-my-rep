<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$modules = array(
	'aiseo_module_optimization'  => array( __( 'بهینه‌سازی تصویر', 'advanced-image-seo-optimizer' ), true, '' ),
	'aiseo_module_seo'           => array( __( 'سئوی تصویر', 'advanced-image-seo-optimizer' ), true, '' ),
	'aiseo_module_watermark'     => array( __( 'واترمارک', 'advanced-image-seo-optimizer' ), true, '' ),
	'aiseo_module_editor'        => array( __( 'ویرایشگر تصویر', 'advanced-image-seo-optimizer' ), true, '' ),
	'aiseo_module_media_library' => array( __( 'مدیریت کتابخانه‌ی رسانه', 'advanced-image-seo-optimizer' ), true, '' ),
);
?>
<h2><?php esc_html_e( 'ماژول‌های افزونه', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description"><?php esc_html_e( 'هر ماژول کاملاً مستقل است. غیرفعال کردن یک ماژول تأثیری روی بقیه ندارد.', 'advanced-image-seo-optimizer' ); ?></p>
<table class="form-table" role="presentation">
	<?php foreach ( $modules as $option_key => $meta ) : ?>
		<?php list( $label, $ready, $badge ) = $meta; ?>
		<tr>
			<th scope="row"><?php echo esc_html( $label ); ?></th>
			<td>
				<label class="aiseo-switch">
					<input type="checkbox" name="<?php echo esc_attr( $option_key ); ?>" value="1"
						<?php checked( 1, get_option( $option_key, $ready ? 1 : 0 ) ); ?>
						<?php disabled( ! $ready ); ?> />
					<span class="aiseo-slider"></span>
				</label>
				<?php if ( ! $ready ) : ?>
					<span class="aiseo-badge"><?php echo esc_html( $badge ); ?> &mdash; <?php esc_html_e( 'به‌زودی', 'advanced-image-seo-optimizer' ); ?></span>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; ?>
</table>
