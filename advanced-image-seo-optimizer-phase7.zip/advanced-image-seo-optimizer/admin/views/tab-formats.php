<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$formats = get_option( 'aiseo_opt_convert_formats', array() );

$labels = array(
	'jpeg' => 'JPEG',
	'png'  => 'PNG',
	'gif'  => 'GIF ' . __( '(شامل انیمیشن)', 'advanced-image-seo-optimizer' ),
	'bmp'  => 'BMP',
	'tiff' => 'TIFF',
	'svg'  => 'SVG',
	'avif' => 'AVIF',
);
?>
<h2><?php esc_html_e( 'فرمت‌های ورودی', 'advanced-image-seo-optimizer' ); ?></h2>
<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'انتخاب فرمت‌ها برای تبدیل', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<?php foreach ( $labels as $key => $label ) : ?>
				<label class="aiseo-checkbox-row">
					<input type="checkbox" name="aiseo_opt_convert_formats[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( 1, $formats[ $key ] ?? 1 ); ?> />
					<?php echo esc_html( $label ); ?>
				</label><br />
			<?php endforeach; ?>
			<p class="description"><?php esc_html_e( 'فرمت‌هایی که انتخاب شوند، هنگام آپلود و در پردازش دسته‌ای به فرمت خروجی تبدیل می‌شوند. SVG و TIFF فقط با Imagick پشتیبانی می‌شوند.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
</table>
