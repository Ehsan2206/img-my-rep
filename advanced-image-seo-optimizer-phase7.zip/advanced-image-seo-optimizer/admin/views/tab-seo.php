<?php
/** @var \AISEO\Settings $settings */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<h2><?php esc_html_e( 'تنظیمات سئوی تصویر', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description">
	<?php esc_html_e( 'تولید Alt/Title/Caption/Description کاملاً rule-based و محلی است (بدون AI/API بیرونی). می‌توانید از {filename}، {parent_title}، {site_name} و {date} در قالب‌ها استفاده کنید.', 'advanced-image-seo-optimizer' ); ?>
</p>
<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'تولید خودکار حین آپلود', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_seo_auto_generate_on_upload" value="1" <?php checked( 1, get_option( 'aiseo_seo_auto_generate_on_upload', 1 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
			<p class="description"><?php esc_html_e( 'برای هر تصویر تازه آپلودشده، فیلدهای خالی به‌صورت خودکار پر می‌شوند.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'بازنویسی فیلدهای پرشده', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_seo_overwrite_existing" value="1" <?php checked( 1, get_option( 'aiseo_seo_overwrite_existing', 0 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
			<p class="description"><?php esc_html_e( 'پیش‌فرض خاموش: فقط فیلدهای خالی پر می‌شوند. با فعال بودن این گزینه، پردازش دسته‌ای مقادیر قبلی را هم بازنویسی می‌کند.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_seo_alt_template"><?php esc_html_e( 'قالب Alt', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td><input type="text" id="aiseo_seo_alt_template" name="aiseo_seo_alt_template" class="regular-text" value="<?php echo esc_attr( get_option( 'aiseo_seo_alt_template', '{filename} - {site_name}' ) ); ?>" /></td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_seo_title_template"><?php esc_html_e( 'قالب Title', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td><input type="text" id="aiseo_seo_title_template" name="aiseo_seo_title_template" class="regular-text" value="<?php echo esc_attr( get_option( 'aiseo_seo_title_template', '{filename}' ) ); ?>" /></td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_seo_caption_template"><?php esc_html_e( 'قالب Caption', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td><input type="text" id="aiseo_seo_caption_template" name="aiseo_seo_caption_template" class="regular-text" value="<?php echo esc_attr( get_option( 'aiseo_seo_caption_template', '{filename}' ) ); ?>" /></td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_seo_description_template"><?php esc_html_e( 'قالب Description', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td><input type="text" id="aiseo_seo_description_template" name="aiseo_seo_description_template" class="regular-text" value="<?php echo esc_attr( get_option( 'aiseo_seo_description_template', '{filename} - {parent_title}' ) ); ?>" /></td>
	</tr>
</table>

<hr class="aiseo-report-divider" />

<h2><?php esc_html_e( 'امتیاز سئوی کتابخانه', 'advanced-image-seo-optimizer' ); ?></h2>
<div id="aiseo-seo-score">
	<p id="aiseo-seo-score-loading" class="aiseo-batch-status"></p>
	<div id="aiseo-seo-score-content" class="aiseo-batch-stats" hidden>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-seo-score-average">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'میانگین امتیاز', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-seo-score-good">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'خوب', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-seo-score-fair">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'متوسط', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat aiseo-stat-warn"><span class="aiseo-stat-num" id="aiseo-seo-score-poor">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'ضعیف', 'advanced-image-seo-optimizer' ); ?></span></div>
	</div>
	<p class="description"><?php esc_html_e( 'برای عملکرد بهتر، فقط روی نمونه‌ای از جدیدترین تصاویر محاسبه می‌شود.', 'advanced-image-seo-optimizer' ); ?></p>
</div>

<hr class="aiseo-report-divider" />

<h2><?php esc_html_e( 'بررسی Alt متن‌ها', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description"><?php esc_html_e( 'تصاویر با Alt خالی یا تکراری را پیدا می‌کند (فقط خواندنی، تغییری اعمال نمی‌شود).', 'advanced-image-seo-optimizer' ); ?></p>
<button type="button" id="aiseo-seo-alt-check" class="button button-secondary"><?php esc_html_e( 'اجرای بررسی', 'advanced-image-seo-optimizer' ); ?></button>
<div id="aiseo-seo-alt-report" class="aiseo-batch-stats" hidden style="margin-top:12px;">
	<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-alt-total">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'کل تصاویر', 'advanced-image-seo-optimizer' ); ?></span></div>
	<div class="aiseo-stat aiseo-stat-warn"><span class="aiseo-stat-num" id="aiseo-alt-missing">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'Alt خالی', 'advanced-image-seo-optimizer' ); ?></span></div>
	<div class="aiseo-stat aiseo-stat-warn"><span class="aiseo-stat-num" id="aiseo-alt-duplicate">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'Alt تکراری', 'advanced-image-seo-optimizer' ); ?></span></div>
</div>

<hr class="aiseo-report-divider" />

<h2><?php esc_html_e( 'پردازش دسته‌ای متادیتای سئو (کتابخانه‌ی قدیمی)', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description"><?php esc_html_e( 'فیلدهای خالی تصاویر موجود در کتابخانه را طبق قالب‌های بالا پر می‌کند (بدون بازنویسی مقادیر قبلی، مگر این‌که گزینه‌ی «بازنویسی» را روشن کرده باشید).', 'advanced-image-seo-optimizer' ); ?></p>
<div id="aiseo-seo-batch-panel" class="aiseo-batch-panel">
	<div class="aiseo-batch-stats">
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-seo-stat-pending">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در انتظار', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-seo-stat-processing">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در حال پردازش', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-seo-stat-done">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'انجام‌شده', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat aiseo-stat-warn"><span class="aiseo-stat-num" id="aiseo-seo-stat-failed">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'ناموفق', 'advanced-image-seo-optimizer' ); ?></span></div>
	</div>
	<div class="aiseo-progress-bar-wrap"><div id="aiseo-seo-progress-bar" class="aiseo-progress-bar"></div></div>
	<p id="aiseo-seo-batch-status" class="aiseo-batch-status"></p>
	<div class="aiseo-batch-actions">
		<button type="button" id="aiseo-seo-batch-start" class="button button-primary"><?php esc_html_e( 'اسکن و شروع پردازش', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-seo-batch-stop" class="button" hidden><?php esc_html_e( 'توقف', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-seo-batch-retry" class="button"><?php esc_html_e( 'تلاش مجدد آیتم‌های ناموفق', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-seo-batch-refresh" class="button"><?php esc_html_e( 'به‌روزرسانی وضعیت', 'advanced-image-seo-optimizer' ); ?></button>
	</div>
</div>

<hr class="aiseo-report-divider" />

<h2><?php esc_html_e( 'نقشه‌سایت تصویری', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description"><?php esc_html_e( 'فایل XML مطابق پروتکل تصویری گوگل، مستقیماً در پوشه‌ی uploads ساخته می‌شود؛ بدون هیچ اتصال بیرونی.', 'advanced-image-seo-optimizer' ); ?></p>
<button type="button" id="aiseo-seo-sitemap-generate" class="button button-secondary"><?php esc_html_e( 'ساخت / به‌روزرسانی نقشه‌سایت', 'advanced-image-seo-optimizer' ); ?></button>
<p id="aiseo-seo-sitemap-status" class="aiseo-batch-status"></p>
