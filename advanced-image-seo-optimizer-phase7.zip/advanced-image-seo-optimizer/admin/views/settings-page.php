<?php
/**
 * View: صفحه‌ی تنظیمات اصلی.
 * متغیرهای در دسترس (از Admin::render_settings_page تزریق می‌شوند):
 * @var \AISEO\Settings            $settings
 * @var \AISEO\Server_Capabilities $server_capabilities
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$caps = $server_capabilities->detect();
?>
<div class="wrap aiseo-wrap">
	<h1 class="aiseo-title">
		<span class="dashicons dashicons-images-alt2"></span>
		<?php esc_html_e( 'تنظیمات Advanced Image SEO & Optimization Suite', 'advanced-image-seo-optimizer' ); ?>
	</h1>
	<p class="aiseo-subtitle">
		<?php esc_html_e( 'همه چیز کاملاً محلی و آفلاین اجرا می‌شود؛ بدون هیچ اتصال به سرویس یا API بیرونی.', 'advanced-image-seo-optimizer' ); ?>
	</p>

	<?php if ( ! $caps['imagick']['available'] && ! $caps['gd']['available'] ) : ?>
		<div class="notice notice-error"><p>
			<?php esc_html_e( 'هشدار: نه GD و نه Imagick روی این سرور در دسترس نیست. ماژول بهینه‌سازی تصویر غیرفعال است.', 'advanced-image-seo-optimizer' ); ?>
		</p></div>
	<?php elseif ( ! $caps['imagick']['available'] ) : ?>
		<div class="notice notice-warning"><p>
			<?php esc_html_e( 'Imagick نصب نیست. تبدیل بر پایه‌ی GD انجام می‌شود که از SVG، TIFF و AVIF (روی اکثر نسخه‌ها) پشتیبانی نمی‌کند.', 'advanced-image-seo-optimizer' ); ?>
		</p></div>
	<?php endif; ?>

	<div class="aiseo-tabs">
		<ul class="aiseo-tab-nav" role="tablist">
			<li><a href="#tab-general" class="active" data-tab="tab-general"><?php esc_html_e( 'عمومی', 'advanced-image-seo-optimizer' ); ?></a></li>
			<li><a href="#tab-formats" data-tab="tab-formats"><?php esc_html_e( 'فرمت‌ها', 'advanced-image-seo-optimizer' ); ?></a></li>
			<li><a href="#tab-optimization" data-tab="tab-optimization"><?php esc_html_e( 'بهینه‌سازی', 'advanced-image-seo-optimizer' ); ?></a></li>
			<li><a href="#tab-modules" data-tab="tab-modules"><?php esc_html_e( 'ماژول‌ها', 'advanced-image-seo-optimizer' ); ?></a></li>
			<li><a href="#tab-seo" data-tab="tab-seo"><?php esc_html_e( 'سئوی تصویر', 'advanced-image-seo-optimizer' ); ?></a></li>
			<li><a href="#tab-watermark" data-tab="tab-watermark"><?php esc_html_e( 'واترمارک', 'advanced-image-seo-optimizer' ); ?></a></li>
			<li><a href="#tab-editor" data-tab="tab-editor"><?php esc_html_e( 'ویرایشگر', 'advanced-image-seo-optimizer' ); ?></a></li>
			<li><a href="#tab-media-library" data-tab="tab-media-library"><?php esc_html_e( 'کتابخانه‌ی رسانه', 'advanced-image-seo-optimizer' ); ?></a></li>
			<li><a href="#tab-advanced" data-tab="tab-advanced"><?php esc_html_e( 'پیشرفته', 'advanced-image-seo-optimizer' ); ?></a></li>
			<li><a href="#tab-batch" data-tab="tab-batch"><?php esc_html_e( 'پردازش دسته‌ای', 'advanced-image-seo-optimizer' ); ?></a></li>
		</ul>

		<form method="post" action="options.php" class="aiseo-form">
			<?php settings_fields( \AISEO\Settings::OPTION_GROUP ); ?>

			<div id="tab-general" class="aiseo-tab-content active">
				<?php require __DIR__ . '/tab-general.php'; ?>
			</div>

			<div id="tab-formats" class="aiseo-tab-content">
				<?php require __DIR__ . '/tab-formats.php'; ?>
			</div>

			<div id="tab-optimization" class="aiseo-tab-content">
				<?php require __DIR__ . '/tab-optimization-settings.php'; ?>
			</div>

			<div id="tab-modules" class="aiseo-tab-content">
				<?php require __DIR__ . '/tab-modules.php'; ?>
			</div>

			<div id="tab-seo" class="aiseo-tab-content">
				<?php require __DIR__ . '/tab-seo.php'; ?>
			</div>

			<div id="tab-watermark" class="aiseo-tab-content">
				<?php require __DIR__ . '/tab-watermark.php'; ?>
			</div>

			<div id="tab-editor" class="aiseo-tab-content">
				<?php require __DIR__ . '/tab-editor.php'; ?>
			</div>

			<div id="tab-media-library" class="aiseo-tab-content">
				<?php require __DIR__ . '/tab-media-library.php'; ?>
			</div>

			<div id="tab-advanced" class="aiseo-tab-content">
				<?php require __DIR__ . '/tab-advanced.php'; ?>
			</div>

			<?php submit_button( __( 'ذخیره‌ی تنظیمات', 'advanced-image-seo-optimizer' ) ); ?>
		</form>

		<div id="tab-batch" class="aiseo-tab-content">
			<?php require __DIR__ . '/tab-batch.php'; ?>
		</div>
	</div>
</div>
