<?php
/** @var \AISEO\Settings $settings */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<h2><?php esc_html_e( 'مدیریت هوشمند کتابخانه‌ی رسانه', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description">
	<?php esc_html_e( 'داشبورد آماری کتابخانه، تشخیص تصاویر تکراری (بر اساس محتوای فایل، نه نام) و بررسی سلامت فایل‌ها (فایل گم‌شده یا سایز thumbnail ناقص). همه چیز محلی و بدون اتصال بیرونی.', 'advanced-image-seo-optimizer' ); ?>
</p>

<div id="aiseo-ml-stats" class="aiseo-ml-cards">
	<p id="aiseo-ml-stats-loading" class="aiseo-batch-status"></p>
</div>
<div id="aiseo-ml-format-list" class="aiseo-ml-format-list" hidden></div>
<button type="button" id="aiseo-ml-stats-refresh" class="button"><?php esc_html_e( 'به‌روزرسانی آمار', 'advanced-image-seo-optimizer' ); ?></button>

<hr class="aiseo-report-divider" />

<h2><?php esc_html_e( 'تنظیمات بازسازی', 'advanced-image-seo-optimizer' ); ?></h2>
<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'بازسازی خودکار thumbnail های گم‌شده', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_ml_auto_rebuild_thumbnails" value="1" <?php checked( 1, get_option( 'aiseo_ml_auto_rebuild_thumbnails', 0 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
			<p class="description"><?php esc_html_e( 'پیش‌فرض خاموش. با روشن بودن، اسکن سلامت به‌محض پیدا کردن سایز گم‌شده بلافاصله آن را از روی فایل اصلی بازسازی می‌کند. در غیر این‌صورت فقط گزارش می‌دهد و بازسازی هر مورد را باید دستی تأیید کنید.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
</table>
<p class="description"><?php esc_html_e( 'این تنظیم با دکمه‌ی «ذخیره‌ی تنظیمات» بالای صفحه ذخیره می‌شود؛ پنل‌های زیر مستقل و آنی عمل می‌کنند.', 'advanced-image-seo-optimizer' ); ?></p>

<hr class="aiseo-report-divider" />

<h2><?php esc_html_e( 'تشخیص تصاویر تکراری', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description"><?php esc_html_e( 'بر اساس هش محتوای واقعی فایل تشخیص می‌دهد؛ دو تصویر با نام‌های متفاوت اما محتوای یکسان هم پیدا می‌شوند. حذف هر تصویر باید دستی و آگاهانه انجام شود.', 'advanced-image-seo-optimizer' ); ?></p>

<div id="aiseo-ml-duplicate-batch-panel" class="aiseo-batch-panel">
	<div class="aiseo-batch-stats">
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-ml-dup-stat-pending">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در انتظار', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-ml-dup-stat-processing">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در حال پردازش', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-ml-dup-stat-done">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'انجام‌شده', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat aiseo-stat-warn"><span class="aiseo-stat-num" id="aiseo-ml-dup-stat-failed">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'ناموفق', 'advanced-image-seo-optimizer' ); ?></span></div>
	</div>
	<div class="aiseo-progress-bar-wrap"><div id="aiseo-ml-dup-progress-bar" class="aiseo-progress-bar"></div></div>
	<p id="aiseo-ml-dup-batch-status" class="aiseo-batch-status"></p>
	<div class="aiseo-batch-actions">
		<button type="button" id="aiseo-ml-dup-batch-start" class="button button-primary"><?php esc_html_e( 'اسکن و هش کردن تصاویر جدید', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-ml-dup-batch-stop" class="button" hidden><?php esc_html_e( 'توقف', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-ml-dup-batch-retry" class="button"><?php esc_html_e( 'تلاش مجدد آیتم‌های ناموفق', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-ml-dup-groups-refresh" class="button"><?php esc_html_e( 'نمایش/به‌روزرسانی گروه‌های تکراری', 'advanced-image-seo-optimizer' ); ?></button>
	</div>
</div>

<div id="aiseo-ml-duplicate-groups" style="margin-top:16px;"></div>

<hr class="aiseo-report-divider" />

<h2><?php esc_html_e( 'بررسی سلامت فایل و بازسازی Thumbnail', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description"><?php esc_html_e( 'کل کتابخانه را برای فایل اصلی گم‌شده یا سایزهای thumbnail ناقص بررسی می‌کند. می‌توانید صفحه را ببندید و بعداً برگردید؛ صف نگه داشته می‌شود.', 'advanced-image-seo-optimizer' ); ?></p>

<div id="aiseo-ml-cleanup-batch-panel" class="aiseo-batch-panel">
	<div class="aiseo-batch-stats">
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-ml-cln-stat-pending">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در انتظار', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-ml-cln-stat-processing">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در حال پردازش', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-ml-cln-stat-done">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'انجام‌شده', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat aiseo-stat-warn"><span class="aiseo-stat-num" id="aiseo-ml-cln-stat-failed">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'ناموفق', 'advanced-image-seo-optimizer' ); ?></span></div>
	</div>
	<div class="aiseo-progress-bar-wrap"><div id="aiseo-ml-cln-progress-bar" class="aiseo-progress-bar"></div></div>
	<p id="aiseo-ml-cln-batch-status" class="aiseo-batch-status"></p>
	<div class="aiseo-batch-actions">
		<button type="button" id="aiseo-ml-cln-batch-start" class="button button-primary"><?php esc_html_e( 'اسکن کامل کتابخانه', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-ml-cln-batch-stop" class="button" hidden><?php esc_html_e( 'توقف', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-ml-cln-batch-retry" class="button"><?php esc_html_e( 'تلاش مجدد آیتم‌های ناموفق', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-ml-cln-items-refresh" class="button"><?php esc_html_e( 'نمایش/به‌روزرسانی موارد مشکل‌دار', 'advanced-image-seo-optimizer' ); ?></button>
	</div>
</div>

<div id="aiseo-ml-cleanup-items" style="margin-top:16px;"></div>
