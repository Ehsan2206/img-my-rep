<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<h2><?php esc_html_e( 'تنظیمات پیشرفته', 'advanced-image-seo-optimizer' ); ?></h2>
<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'حذف کامل داده‌ها هنگام حذف افزونه', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_remove_data_on_uninstall" value="1" <?php checked( 1, get_option( 'aiseo_remove_data_on_uninstall', 0 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
			<p class="description">
				<?php esc_html_e( 'در صورت فعال بودن، با حذف کامل افزونه از صفحه‌ی افزونه‌ها، جداول، تنظیمات و نسخه‌های بکاپ اصلی تصاویر پاک می‌شوند. پیش‌فرض خاموش است تا داده‌ای به‌اشتباه از دست نرود.', 'advanced-image-seo-optimizer' ); ?>
			</p>
		</td>
	</tr>
</table>
