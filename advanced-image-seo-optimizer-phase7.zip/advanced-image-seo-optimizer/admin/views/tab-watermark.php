<?php
/** @var \AISEO\Settings $settings */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$logo_id  = (int) get_option( 'aiseo_watermark_image_id', 0 );
$logo_url = $logo_id > 0 ? wp_get_attachment_image_url( $logo_id, 'thumbnail' ) : '';
$type     = get_option( 'aiseo_watermark_type', 'text' );
?>
<h2><?php esc_html_e( 'تنظیمات واترمارک', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description">
	<?php esc_html_e( 'واترمارک متنی یا تصویری روی سایزهای انتخابی تصاویر اعمال می‌شود؛ کاملاً محلی و غیرمخرب (نسخه‌ی پیش از واترمارک قابل بازیابی نگه داشته می‌شود).', 'advanced-image-seo-optimizer' ); ?>
</p>
<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'اعمال خودکار حین آپلود', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_watermark_apply_on_upload" value="1" <?php checked( 1, get_option( 'aiseo_watermark_apply_on_upload', 0 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
			<p class="description"><?php esc_html_e( 'پیش‌فرض خاموش؛ در صورت روشن بودن، تصاویر تازه بلافاصله بعد از آپلود واترمارک می‌شوند.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'نگه‌داری نسخه‌ی پیش از واترمارک', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_watermark_keep_backup" value="1" <?php checked( 1, get_option( 'aiseo_watermark_keep_backup', 1 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
			<p class="description"><?php esc_html_e( 'پیش‌فرض روشن (Non-destructive)؛ نسخه‌ی هر سایز پیش از واترمارک در پوشه‌ی محافظت‌شده نگه داشته می‌شود.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_watermark_type"><?php esc_html_e( 'نوع واترمارک', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td>
			<select id="aiseo_watermark_type" name="aiseo_watermark_type">
				<option value="text" <?php selected( 'text', $type ); ?>><?php esc_html_e( 'متن', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="image" <?php selected( 'image', $type ); ?>><?php esc_html_e( 'تصویر (لوگو)', 'advanced-image-seo-optimizer' ); ?></option>
			</select>
		</td>
	</tr>
	<tr class="aiseo-watermark-field-text">
		<th scope="row"><label for="aiseo_watermark_text"><?php esc_html_e( 'متن واترمارک', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td>
			<input type="text" id="aiseo_watermark_text" name="aiseo_watermark_text" class="regular-text" value="<?php echo esc_attr( get_option( 'aiseo_watermark_text', '{site_name}' ) ); ?>" />
			<p class="description"><?php esc_html_e( 'می‌توانید از {site_name} و {date} استفاده کنید.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr class="aiseo-watermark-field-text">
		<th scope="row"><label for="aiseo_watermark_text_color"><?php esc_html_e( 'رنگ متن', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td><input type="text" id="aiseo_watermark_text_color" name="aiseo_watermark_text_color" class="aiseo-color-field" value="<?php echo esc_attr( get_option( 'aiseo_watermark_text_color', '#ffffff' ) ); ?>" /></td>
	</tr>
	<tr class="aiseo-watermark-field-text">
		<th scope="row"><label for="aiseo_watermark_font_size"><?php esc_html_e( 'اندازه‌ی فونت', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td><input type="number" id="aiseo_watermark_font_size" name="aiseo_watermark_font_size" min="8" max="96" value="<?php echo esc_attr( get_option( 'aiseo_watermark_font_size', 16 ) ); ?>" /></td>
	</tr>
	<tr class="aiseo-watermark-field-image">
		<th scope="row"><?php esc_html_e( 'تصویر لوگو', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<input type="hidden" id="aiseo_watermark_image_id" name="aiseo_watermark_image_id" value="<?php echo esc_attr( $logo_id ); ?>" />
			<img id="aiseo-watermark-logo-preview" src="<?php echo esc_url( $logo_url ); ?>" style="max-width:120px;max-height:80px;display:<?php echo $logo_url ? 'block' : 'none'; ?>;margin-bottom:8px;" />
			<br />
			<button type="button" id="aiseo-watermark-logo-select" class="button"><?php esc_html_e( 'انتخاب از کتابخانه‌ی رسانه', 'advanced-image-seo-optimizer' ); ?></button>
			<button type="button" id="aiseo-watermark-logo-remove" class="button" <?php echo $logo_url ? '' : 'style="display:none;"'; ?>><?php esc_html_e( 'حذف', 'advanced-image-seo-optimizer' ); ?></button>
		</td>
	</tr>
	<tr class="aiseo-watermark-field-image">
		<th scope="row"><label for="aiseo_watermark_scale"><?php esc_html_e( 'اندازه‌ی لوگو (٪ از عرض تصویر)', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td><input type="number" id="aiseo_watermark_scale" name="aiseo_watermark_scale" min="5" max="100" value="<?php echo esc_attr( get_option( 'aiseo_watermark_scale', 20 ) ); ?>" /></td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_watermark_position"><?php esc_html_e( 'موقعیت', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td>
			<?php $position = get_option( 'aiseo_watermark_position', 'bottom-right' ); ?>
			<select id="aiseo_watermark_position" name="aiseo_watermark_position">
				<option value="top-left" <?php selected( 'top-left', $position ); ?>><?php esc_html_e( 'بالا-چپ', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="top-right" <?php selected( 'top-right', $position ); ?>><?php esc_html_e( 'بالا-راست', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="center" <?php selected( 'center', $position ); ?>><?php esc_html_e( 'مرکز', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="bottom-left" <?php selected( 'bottom-left', $position ); ?>><?php esc_html_e( 'پایین-چپ', 'advanced-image-seo-optimizer' ); ?></option>
				<option value="bottom-right" <?php selected( 'bottom-right', $position ); ?>><?php esc_html_e( 'پایین-راست', 'advanced-image-seo-optimizer' ); ?></option>
			</select>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_watermark_opacity"><?php esc_html_e( 'شفافیت (٪)', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td><input type="number" id="aiseo_watermark_opacity" name="aiseo_watermark_opacity" min="0" max="100" value="<?php echo esc_attr( get_option( 'aiseo_watermark_opacity', 60 ) ); ?>" /></td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_watermark_margin"><?php esc_html_e( 'فاصله از لبه (پیکسل)', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td><input type="number" id="aiseo_watermark_margin" name="aiseo_watermark_margin" min="0" value="<?php echo esc_attr( get_option( 'aiseo_watermark_margin', 16 ) ); ?>" /></td>
	</tr>
	<tr>
		<th scope="row"><label for="aiseo_watermark_min_width"><?php esc_html_e( 'حداقل عرض تصویر (پیکسل)', 'advanced-image-seo-optimizer' ); ?></label></th>
		<td>
			<input type="number" id="aiseo_watermark_min_width" name="aiseo_watermark_min_width" min="0" value="<?php echo esc_attr( get_option( 'aiseo_watermark_min_width', 400 ) ); ?>" />
			<p class="description"><?php esc_html_e( 'تصاویر کوچک‌تر از این عرض واترمارک نمی‌شوند (برای جلوگیری از خراب شدن thumbnail های ریز).', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'سایزهای هدف', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<?php
			$targets = get_option( 'aiseo_watermark_target_sizes', array( 'full' => 1, 'large' => 1, 'medium' => 0, 'thumbnail' => 0 ) );
			$labels  = array(
				'full'      => __( 'اصلی (Full)', 'advanced-image-seo-optimizer' ),
				'large'     => __( 'بزرگ (Large)', 'advanced-image-seo-optimizer' ),
				'medium'    => __( 'متوسط (Medium)', 'advanced-image-seo-optimizer' ),
				'thumbnail' => __( 'بندانگشتی (Thumbnail)', 'advanced-image-seo-optimizer' ),
			);
			foreach ( $labels as $key => $label ) :
				?>
				<label style="margin-left:16px;">
					<input type="checkbox" name="aiseo_watermark_target_sizes[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( 1, $targets[ $key ] ?? 0 ); ?> />
					<?php echo esc_html( $label ); ?>
				</label>
			<?php endforeach; ?>
		</td>
	</tr>
</table>

<hr class="aiseo-report-divider" />

<h2><?php esc_html_e( 'اعمال واترمارک روی کتابخانه‌ی قدیمی', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description"><?php esc_html_e( 'تصاویر موجود در کتابخانه را طبق تنظیمات بالا واترمارک می‌کند (نسخه‌ی پیش از واترمارک هر سایز نگه داشته می‌شود، مگر این‌که خاموش کرده باشید).', 'advanced-image-seo-optimizer' ); ?></p>
<div id="aiseo-watermark-batch-panel" class="aiseo-batch-panel">
	<div class="aiseo-batch-stats">
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-watermark-stat-pending">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در انتظار', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-watermark-stat-processing">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در حال پردازش', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-watermark-stat-done">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'انجام‌شده', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat aiseo-stat-warn"><span class="aiseo-stat-num" id="aiseo-watermark-stat-failed">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'ناموفق', 'advanced-image-seo-optimizer' ); ?></span></div>
	</div>
	<div class="aiseo-progress-bar-wrap"><div id="aiseo-watermark-progress-bar" class="aiseo-progress-bar"></div></div>
	<p id="aiseo-watermark-batch-status" class="aiseo-batch-status"></p>
	<div class="aiseo-batch-actions">
		<button type="button" id="aiseo-watermark-batch-start" class="button button-primary"><?php esc_html_e( 'اسکن و شروع پردازش', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-watermark-batch-stop" class="button" hidden><?php esc_html_e( 'توقف', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-watermark-batch-retry" class="button"><?php esc_html_e( 'تلاش مجدد آیتم‌های ناموفق', 'advanced-image-seo-optimizer' ); ?></button>
		<button type="button" id="aiseo-watermark-batch-refresh" class="button"><?php esc_html_e( 'به‌روزرسانی وضعیت', 'advanced-image-seo-optimizer' ); ?></button>
	</div>
</div>
