<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<h2><?php esc_html_e( 'تنظیمات بهینه‌سازی', 'advanced-image-seo-optimizer' ); ?></h2>
<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'کیفیت تصویر (۰ تا ۱۰۰)', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<input type="range" min="0" max="100" name="aiseo_opt_quality"
				value="<?php echo esc_attr( get_option( 'aiseo_opt_quality', 80 ) ); ?>"
				class="aiseo-range" oninput="this.nextElementSibling.value = this.value" />
			<output><?php echo esc_html( get_option( 'aiseo_opt_quality', 80 ) ); ?></output>
			<p class="description"><?php esc_html_e( 'کیفیت بالاتر یعنی حجم فایل بیشتر.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'فشرده‌سازی بدون افت کیفیت (Lossless)', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_opt_lossless" value="1" <?php checked( 1, get_option( 'aiseo_opt_lossless', 0 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
			<p class="description"><?php esc_html_e( 'حجم بیشتر با حداکثر کیفیت؛ فقط روی Imagick تضمین‌شده است.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'حذف متادیتای EXIF', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_opt_strip_metadata" value="1" <?php checked( 1, get_option( 'aiseo_opt_strip_metadata', 1 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
			<p class="description"><?php esc_html_e( 'کاهش حجم فایل و حفظ حریم خصوصی (مثل موقعیت GPS دوربین) با حذف متادیتا.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'تغییر اندازه‌ی هوشمند', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<label class="aiseo-switch">
				<input type="checkbox" name="aiseo_opt_enable_resize" value="1" <?php checked( 1, get_option( 'aiseo_opt_enable_resize', 1 ) ); ?> />
				<span class="aiseo-slider"></span>
			</label>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'بزرگ‌ترین ضلع مجاز (پیکسل)', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<input type="number" min="100" max="10000" step="10" name="aiseo_opt_max_size"
				value="<?php echo esc_attr( get_option( 'aiseo_opt_max_size', 2560 ) ); ?>" class="small-text" />
			<p class="description"><?php esc_html_e( 'اگر عرض یا ارتفاع تصویر از این مقدار بیشتر باشد، با حفظ نسبت ابعاد کوچک می‌شود.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'حداکثر حجم فایل خروجی (کیلوبایت)', 'advanced-image-seo-optimizer' ); ?></th>
		<td>
			<input type="number" min="0" step="10" name="aiseo_opt_max_file_size_kb"
				value="<?php echo esc_attr( get_option( 'aiseo_opt_max_file_size_kb', 0 ) ); ?>" class="small-text" />
			<p class="description"><?php esc_html_e( '۰ یعنی بدون محدودیت. اگر فایل خروجی از این حد بیشتر شود، تبدیل لغو و فایل اصلی دست‌نخورده باقی می‌ماند.', 'advanced-image-seo-optimizer' ); ?></p>
		</td>
	</tr>
</table>
