<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<h2><?php esc_html_e( 'پردازش دسته‌ای تصاویر قدیمی', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description">
	<?php esc_html_e( 'تصاویر موجود در کتابخانه‌ی رسانه به‌صورت تکه‌های کوچک و قابل ادامه پردازش می‌شوند تا روی هاست‌های محدود با تایم‌اوت مواجه نشوید. می‌توانید این صفحه را ببندید و بعداً برگردید؛ صف نگه داشته می‌شود.', 'advanced-image-seo-optimizer' ); ?>
</p>

<div id="aiseo-batch-panel" class="aiseo-batch-panel">
	<div class="aiseo-batch-stats">
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-stat-pending">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در انتظار', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-stat-processing">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'در حال پردازش', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-stat-done">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'انجام‌شده', 'advanced-image-seo-optimizer' ); ?></span></div>
		<div class="aiseo-stat aiseo-stat-warn"><span class="aiseo-stat-num" id="aiseo-stat-failed">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'ناموفق', 'advanced-image-seo-optimizer' ); ?></span></div>
	</div>

	<div class="aiseo-progress-bar-wrap">
		<div id="aiseo-progress-bar" class="aiseo-progress-bar"></div>
	</div>
	<p id="aiseo-batch-status" class="aiseo-batch-status"></p>

	<div id="aiseo-run-report" class="aiseo-run-report" hidden>
		<strong><?php esc_html_e( 'صرفه‌جویی این اجرا:', 'advanced-image-seo-optimizer' ); ?></strong>
		<span id="aiseo-run-report-text"></span>
	</div>

	<div class="aiseo-batch-actions">
		<button type="button" id="aiseo-batch-start" class="button button-primary">
			<?php esc_html_e( 'اسکن و شروع پردازش دسته‌ای', 'advanced-image-seo-optimizer' ); ?>
		</button>
		<button type="button" id="aiseo-batch-stop" class="button" hidden>
			<?php esc_html_e( 'توقف', 'advanced-image-seo-optimizer' ); ?>
		</button>
		<button type="button" id="aiseo-batch-retry" class="button">
			<?php esc_html_e( 'تلاش مجدد آیتم‌های ناموفق', 'advanced-image-seo-optimizer' ); ?>
		</button>
		<button type="button" id="aiseo-batch-refresh" class="button">
			<?php esc_html_e( 'به‌روزرسانی وضعیت', 'advanced-image-seo-optimizer' ); ?>
		</button>
	</div>
</div>

<hr class="aiseo-report-divider" />

<h2><?php esc_html_e( 'گزارش کاهش حجم', 'advanced-image-seo-optimizer' ); ?></h2>
<p class="description">
	<?php esc_html_e( 'مجموع صرفه‌جویی حجم از ابتدای نصب افزونه، شامل تبدیل‌های آپلود تازه و پردازش دسته‌ای. برخلاف آمار بالا، این گزارش با پاک‌سازی صف از بین نمی‌رود.', 'advanced-image-seo-optimizer' ); ?>
</p>

<div id="aiseo-size-report">
	<p id="aiseo-size-report-loading" class="aiseo-batch-status"></p>

	<div id="aiseo-size-report-content" hidden>
		<div class="aiseo-batch-stats">
			<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-report-files">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'تصویر بهینه‌شده', 'advanced-image-seo-optimizer' ); ?></span></div>
			<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-report-saved">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'حجم صرفه‌جویی‌شده', 'advanced-image-seo-optimizer' ); ?></span></div>
			<div class="aiseo-stat"><span class="aiseo-stat-num" id="aiseo-report-percent">-</span><span class="aiseo-stat-label"><?php esc_html_e( 'درصد کاهش میانگین', 'advanced-image-seo-optimizer' ); ?></span></div>
		</div>

		<table class="widefat striped aiseo-report-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'تاریخ', 'advanced-image-seo-optimizer' ); ?></th>
					<th><?php esc_html_e( 'تعداد', 'advanced-image-seo-optimizer' ); ?></th>
					<th><?php esc_html_e( 'حجم قبل', 'advanced-image-seo-optimizer' ); ?></th>
					<th><?php esc_html_e( 'حجم بعد', 'advanced-image-seo-optimizer' ); ?></th>
					<th><?php esc_html_e( 'کاهش', 'advanced-image-seo-optimizer' ); ?></th>
				</tr>
			</thead>
			<tbody id="aiseo-report-daily-body"></tbody>
		</table>
	</div>
</div>
