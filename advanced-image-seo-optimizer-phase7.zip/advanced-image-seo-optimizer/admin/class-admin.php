<?php
namespace AISEO\Admin;

use AISEO\Settings;
use AISEO\Logger;
use AISEO\Server_Capabilities;
use AISEO\Capabilities;
use AISEO\Stats_Recorder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ثبت منوی ادمین، صفحات تنظیمات/وضعیت، و بارگذاری CSS/JS پنل مدیریت.
 * تمام رندر HTML واقعی در admin/views/*.php انجام می‌شود؛ این کلاس فقط orchestration است.
 */
class Admin {

	private const MENU_SLUG = 'advanced-image-seo-optimizer';

	private Settings $settings;
	private Logger $logger;
	private Server_Capabilities $server_capabilities;
	private Stats_Recorder $stats_recorder;
	private Ajax $ajax;

	public function __construct( Settings $settings, Logger $logger, Server_Capabilities $server_capabilities, Stats_Recorder $stats_recorder ) {
		$this->settings            = $settings;
		$this->logger               = $logger;
		$this->server_capabilities  = $server_capabilities;
		$this->stats_recorder       = $stats_recorder;
		$this->ajax                 = new Ajax( $settings, $logger, $stats_recorder );
	}

	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this->settings, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( $this, 'maybe_show_welcome_notice' ) );

		$this->ajax->register();
	}

	public function register_menu(): void {
		if ( ! Capabilities::current_user_can_manage() ) {
			return;
		}

		add_menu_page(
			__( 'سئو و بهینه‌سازی تصویر', 'advanced-image-seo-optimizer' ),
			__( 'سئوی تصویر', 'advanced-image-seo-optimizer' ),
			Capabilities::MANAGE,
			self::MENU_SLUG,
			array( $this, 'render_settings_page' ),
			'dashicons-images-alt2',
			25
		);

		add_submenu_page(
			self::MENU_SLUG,
			__( 'تنظیمات', 'advanced-image-seo-optimizer' ),
			__( 'تنظیمات', 'advanced-image-seo-optimizer' ),
			Capabilities::MANAGE,
			self::MENU_SLUG,
			array( $this, 'render_settings_page' )
		);

		add_submenu_page(
			self::MENU_SLUG,
			__( 'وضعیت سرور', 'advanced-image-seo-optimizer' ),
			__( 'وضعیت سرور', 'advanced-image-seo-optimizer' ),
			Capabilities::MANAGE,
			self::MENU_SLUG . '-status',
			array( $this, 'render_status_page' )
		);
	}

	public function enqueue_assets( string $hook ): void {
		$is_own_page   = false !== strpos( $hook, self::MENU_SLUG );
		$is_media_page = in_array( $hook, array( 'upload.php', 'post.php', 'post-new.php' ), true );
		$editor_active = ! empty( $this->settings->get_enabled_modules()['editor'] );

		if ( ! $is_own_page && ! ( $is_media_page && $editor_active ) ) {
			return;
		}

		wp_enqueue_style(
			'aiseo-admin',
			AISEO_PLUGIN_URL . 'admin/css/admin.css',
			array(),
			AISEO_VERSION
		);

		// لازم برای انتخاب‌گر لوگوی واترمارک (تب سئو/واترمارک) و پیش‌نمایش‌های کتابخانه‌ی رسانه.
		wp_enqueue_media();

		if ( $is_own_page ) {
			wp_enqueue_script(
				'aiseo-admin',
				AISEO_PLUGIN_URL . 'admin/js/admin.js',
				array(),
				AISEO_VERSION,
				true
			);
		}

		if ( $editor_active ) {
			wp_enqueue_script(
				'aiseo-editor',
				AISEO_PLUGIN_URL . 'admin/js/editor.js',
				array(),
				AISEO_VERSION,
				true
			);
			wp_localize_script( 'aiseo-editor', 'AISEO_ADMIN', $this->get_localized_data() );
		}

		if ( $is_own_page ) {
			wp_localize_script( 'aiseo-admin', 'AISEO_ADMIN', $this->get_localized_data() );
		}
	}

	/**
	 * داده‌ی مشترک localize برای هر دو اسکریپت (aiseo-admin و aiseo-editor)، تا هر دو
	 * به همان AJAX URL/nonce/رشته‌های ترجمه دسترسی داشته باشند بدون تعریف تکراری.
	 */
	private function get_localized_data(): array {
		return array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'aiseo_admin_nonce' ),
				'i18n'     => array(
					'starting'      => __( 'در حال شروع...', 'advanced-image-seo-optimizer' ),
					'processing'    => __( 'در حال پردازش...', 'advanced-image-seo-optimizer' ),
					'done'          => __( 'پردازش دسته‌ای با موفقیت به پایان رسید.', 'advanced-image-seo-optimizer' ),
					'error'         => __( 'خطایی رخ داد. لطفاً دوباره تلاش کنید.', 'advanced-image-seo-optimizer' ),
					'locked'        => __( 'یک پردازش دیگر در حال اجراست، کمی صبر کنید...', 'advanced-image-seo-optimizer' ),
					'stopped'       => __( 'متوقف شد. آیتم‌های باقی‌مانده در صف نگه داشته شدند؛ با «ادامه» می‌توانید بعداً از همین‌جا ادامه دهید.', 'advanced-image-seo-optimizer' ),
					'retrying'      => __( 'در حال صف‌بندی دوباره‌ی آیتم‌های ناموفق...', 'advanced-image-seo-optimizer' ),
					'noFailed'      => __( 'هیچ آیتم ناموفقی برای تلاش مجدد وجود ندارد.', 'advanced-image-seo-optimizer' ),
					'noNewImages'   => __( 'تصویر جدیدی برای بهینه‌سازی پیدا نشد؛ همه چیز به‌روز است.', 'advanced-image-seo-optimizer' ),
					'reportLoading' => __( 'در حال بارگذاری گزارش...', 'advanced-image-seo-optimizer' ),
					'reportEmpty'   => __( 'هنوز هیچ تصویری بهینه نشده؛ گزارش پس از اولین تبدیل نمایش داده می‌شود.', 'advanced-image-seo-optimizer' ),
					'seoNoNewImages' => __( 'همه‌ی تصاویر بررسی شده‌اند؛ موردی برای پردازش نیست.', 'advanced-image-seo-optimizer' ),
					'seoDone'        => __( 'پردازش متادیتای سئو با موفقیت به پایان رسید.', 'advanced-image-seo-optimizer' ),
					'seoChecking'    => __( 'در حال بررسی...', 'advanced-image-seo-optimizer' ),
					'seoScoring'     => __( 'در حال محاسبه‌ی امتیاز...', 'advanced-image-seo-optimizer' ),
					'sitemapWorking' => __( 'در حال ساخت نقشه‌سایت...', 'advanced-image-seo-optimizer' ),
					'watermarkNoNewImages' => __( 'همه‌ی تصاویر بررسی شده‌اند؛ موردی برای واترمارک نیست.', 'advanced-image-seo-optimizer' ),
					'watermarkDone'        => __( 'اعمال واترمارک با موفقیت به پایان رسید.', 'advanced-image-seo-optimizer' ),
					'wpMediaTitle'         => __( 'انتخاب تصویر لوگو', 'advanced-image-seo-optimizer' ),
					'wpMediaButton'        => __( 'استفاده از این تصویر', 'advanced-image-seo-optimizer' ),
					'editorOpenTitle'      => __( 'ویرایشگر تصویر AISEO', 'advanced-image-seo-optimizer' ),
					'editorLoading'        => __( 'در حال بارگذاری تصویر...', 'advanced-image-seo-optimizer' ),
					'editorApplying'       => __( 'در حال اعمال تغییرات...', 'advanced-image-seo-optimizer' ),
					'editorError'          => __( 'خطایی رخ داد. لطفاً دوباره تلاش کنید.', 'advanced-image-seo-optimizer' ),
					'editorConfirmReset'   => __( 'تصویر به نسخه‌ی اصلی بازگردانده شود؟ همه‌ی مراحل ویرایش از دست می‌روند.', 'advanced-image-seo-optimizer' ),
					'editorCropApply'      => __( 'اعمال برش', 'advanced-image-seo-optimizer' ),
					'editorClose'          => __( 'بستن', 'advanced-image-seo-optimizer' ),
					'editorNoStrategy'     => __( 'هیچ کتابخانه‌ی تصویری (GD/Imagick) برای ویرایش در دسترس نیست.', 'advanced-image-seo-optimizer' ),
					'editorBatchNoNewImages' => __( 'همه‌ی تصاویر بررسی شده‌اند؛ موردی برای پردازش نیست.', 'advanced-image-seo-optimizer' ),
					'editorBatchDone'      => __( 'پردازش دسته‌ای ویرایشگر با موفقیت به پایان رسید.', 'advanced-image-seo-optimizer' ),
					'mlDupNoNewImages'     => __( 'تصویر هش‌نشده‌ی جدیدی پیدا نشد؛ همه چیز به‌روز است.', 'advanced-image-seo-optimizer' ),
					'mlDupDone'            => __( 'هش کردن تصاویر با موفقیت به پایان رسید.', 'advanced-image-seo-optimizer' ),
					'mlDupNoGroups'        => __( 'هیچ تصویر تکراری‌ای پیدا نشد.', 'advanced-image-seo-optimizer' ),
					'mlDupConfirmDelete'   => __( 'این تصویر برای همیشه حذف شود؟ این کار قابل بازگشت نیست.', 'advanced-image-seo-optimizer' ),
					'mlClnNoNewImages'     => __( 'موردی برای اسکن باقی نمانده.', 'advanced-image-seo-optimizer' ),
					'mlClnDone'            => __( 'اسکن سلامت کتابخانه با موفقیت به پایان رسید.', 'advanced-image-seo-optimizer' ),
					'mlClnNoProblems'      => __( 'هیچ موردی با فایل گم‌شده یا thumbnail ناقص پیدا نشد.', 'advanced-image-seo-optimizer' ),
					'mlClnRebuilding'      => __( 'در حال بازسازی...', 'advanced-image-seo-optimizer' ),
					'mlClnRebuildDone'     => __( 'بازسازی شد.', 'advanced-image-seo-optimizer' ),
					'mlStatsLoading'       => __( 'در حال بارگذاری آمار...', 'advanced-image-seo-optimizer' ),
				),
		);
	}

	public function render_settings_page(): void {
		Capabilities::require_manage_or_die();
		$settings            = $this->settings;
		$server_capabilities = $this->server_capabilities;
		require AISEO_PLUGIN_DIR . 'admin/views/settings-page.php';
	}

	public function render_status_page(): void {
		Capabilities::require_manage_or_die();
		$server_capabilities = $this->server_capabilities;
		$logger              = $this->logger;
		require AISEO_PLUGIN_DIR . 'admin/views/status-page.php';
	}

	public function maybe_show_welcome_notice(): void {
		if ( ! get_transient( 'aiseo_activation_redirect' ) || ! Capabilities::current_user_can_manage() ) {
			return;
		}
		delete_transient( 'aiseo_activation_redirect' );

		$settings_url = admin_url( 'admin.php?page=' . self::MENU_SLUG );
		printf(
			'<div class="notice notice-success is-dismissible"><p>%1$s <a href="%2$s">%3$s</a></p></div>',
			esc_html__( 'افزونه‌ی Advanced Image SEO & Optimization Suite فعال شد.', 'advanced-image-seo-optimizer' ),
			esc_url( $settings_url ),
			esc_html__( 'رفتن به تنظیمات', 'advanced-image-seo-optimizer' )
		);
	}
}
