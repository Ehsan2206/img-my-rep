<?php
namespace AISEO\Admin;

use AISEO\Settings;
use AISEO\Logger;
use AISEO\Capabilities;
use AISEO\Stats_Recorder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * اکشن‌های AJAX پنل مدیریت.
 * هر اکشن: 1) nonce را بررسی می‌کند 2) capability را بررسی می‌کند 3) کار را به ماژول مربوطه می‌سپارد.
 * فعلاً فقط اکشن‌های مربوط به پردازش دسته‌ای ماژول بهینه‌سازی پیاده‌سازی شده‌اند؛
 * ماژول‌های آینده (سئو، واترمارک، ...) اکشن‌های خودشان را در فاز مربوطه اضافه می‌کنند.
 */
class Ajax {

	private Settings $settings;
	private Logger $logger;
	private Stats_Recorder $stats_recorder;

	public function __construct( Settings $settings, Logger $logger, Stats_Recorder $stats_recorder ) {
		$this->settings       = $settings;
		$this->logger         = $logger;
		$this->stats_recorder = $stats_recorder;
	}

	public function register(): void {
		add_action( 'wp_ajax_aiseo_batch_enqueue', array( $this, 'handle_batch_enqueue' ) );
		add_action( 'wp_ajax_aiseo_batch_tick', array( $this, 'handle_batch_tick' ) );
		add_action( 'wp_ajax_aiseo_batch_stats', array( $this, 'handle_batch_stats' ) );
		add_action( 'wp_ajax_aiseo_batch_retry_failed', array( $this, 'handle_batch_retry_failed' ) );
		add_action( 'wp_ajax_aiseo_size_report', array( $this, 'handle_size_report' ) );

		add_action( 'wp_ajax_aiseo_seo_batch_enqueue', array( $this, 'handle_seo_batch_enqueue' ) );
		add_action( 'wp_ajax_aiseo_seo_batch_tick', array( $this, 'handle_seo_batch_tick' ) );
		add_action( 'wp_ajax_aiseo_seo_batch_stats', array( $this, 'handle_seo_batch_stats' ) );
		add_action( 'wp_ajax_aiseo_seo_batch_retry_failed', array( $this, 'handle_seo_batch_retry_failed' ) );
		add_action( 'wp_ajax_aiseo_seo_alt_check', array( $this, 'handle_seo_alt_check' ) );
		add_action( 'wp_ajax_aiseo_seo_score_summary', array( $this, 'handle_seo_score_summary' ) );
		add_action( 'wp_ajax_aiseo_seo_sitemap_generate', array( $this, 'handle_seo_sitemap_generate' ) );

		add_action( 'wp_ajax_aiseo_watermark_batch_enqueue', array( $this, 'handle_watermark_batch_enqueue' ) );
		add_action( 'wp_ajax_aiseo_watermark_batch_tick', array( $this, 'handle_watermark_batch_tick' ) );
		add_action( 'wp_ajax_aiseo_watermark_batch_stats', array( $this, 'handle_watermark_batch_stats' ) );
		add_action( 'wp_ajax_aiseo_watermark_batch_retry_failed', array( $this, 'handle_watermark_batch_retry_failed' ) );

		add_action( 'wp_ajax_aiseo_editor_get_state', array( $this, 'handle_editor_get_state' ) );
		add_action( 'wp_ajax_aiseo_editor_apply', array( $this, 'handle_editor_apply' ) );
		add_action( 'wp_ajax_aiseo_editor_undo', array( $this, 'handle_editor_undo' ) );
		add_action( 'wp_ajax_aiseo_editor_redo', array( $this, 'handle_editor_redo' ) );
		add_action( 'wp_ajax_aiseo_editor_reset', array( $this, 'handle_editor_reset' ) );
		add_action( 'wp_ajax_aiseo_editor_batch_enqueue', array( $this, 'handle_editor_batch_enqueue' ) );
		add_action( 'wp_ajax_aiseo_editor_batch_tick', array( $this, 'handle_editor_batch_tick' ) );
		add_action( 'wp_ajax_aiseo_editor_batch_stats', array( $this, 'handle_editor_batch_stats' ) );
		add_action( 'wp_ajax_aiseo_editor_batch_retry_failed', array( $this, 'handle_editor_batch_retry_failed' ) );

		add_action( 'wp_ajax_aiseo_ml_stats_summary', array( $this, 'handle_ml_stats_summary' ) );

		add_action( 'wp_ajax_aiseo_ml_duplicate_batch_enqueue', array( $this, 'handle_ml_duplicate_batch_enqueue' ) );
		add_action( 'wp_ajax_aiseo_ml_duplicate_batch_tick', array( $this, 'handle_ml_duplicate_batch_tick' ) );
		add_action( 'wp_ajax_aiseo_ml_duplicate_batch_stats', array( $this, 'handle_ml_duplicate_batch_stats' ) );
		add_action( 'wp_ajax_aiseo_ml_duplicate_batch_retry_failed', array( $this, 'handle_ml_duplicate_batch_retry_failed' ) );
		add_action( 'wp_ajax_aiseo_ml_duplicate_groups', array( $this, 'handle_ml_duplicate_groups' ) );

		add_action( 'wp_ajax_aiseo_ml_cleanup_batch_enqueue', array( $this, 'handle_ml_cleanup_batch_enqueue' ) );
		add_action( 'wp_ajax_aiseo_ml_cleanup_batch_tick', array( $this, 'handle_ml_cleanup_batch_tick' ) );
		add_action( 'wp_ajax_aiseo_ml_cleanup_batch_stats', array( $this, 'handle_ml_cleanup_batch_stats' ) );
		add_action( 'wp_ajax_aiseo_ml_cleanup_batch_retry_failed', array( $this, 'handle_ml_cleanup_batch_retry_failed' ) );
		add_action( 'wp_ajax_aiseo_ml_cleanup_items', array( $this, 'handle_ml_cleanup_items' ) );
		add_action( 'wp_ajax_aiseo_ml_cleanup_rebuild_one', array( $this, 'handle_ml_cleanup_rebuild_one' ) );

		add_action( 'wp_ajax_aiseo_ml_delete_attachment', array( $this, 'handle_ml_delete_attachment' ) );
	}

	private function verify_request(): bool {
		if ( ! Capabilities::current_user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'advanced-image-seo-optimizer' ) ), 403 );
			return false;
		}

		check_ajax_referer( 'aiseo_admin_nonce', 'nonce' );
		return true;
	}

	private function get_batch_processor() {
		$engine = \AISEO\Plugin::get_instance()->get_module( 'optimization' );
		if ( ! $engine ) {
			return null;
		}
		return $engine->get_batch_processor();
	}

	public function handle_batch_enqueue(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$processor = $this->get_batch_processor();
		if ( ! $processor ) {
			wp_send_json_error( array( 'message' => __( 'ماژول بهینه‌سازی فعال نیست.', 'advanced-image-seo-optimizer' ) ) );
			return;
		}

		$added = $processor->enqueue_eligible();
		$stats = $processor->get_stats();

		wp_send_json_success(
			array(
				'added' => $added,
				'stats' => $stats,
			)
		);
	}

	public function handle_batch_tick(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$processor = $this->get_batch_processor();
		if ( ! $processor ) {
			wp_send_json_error( array( 'message' => __( 'ماژول بهینه‌سازی فعال نیست.', 'advanced-image-seo-optimizer' ) ) );
			return;
		}

		$result = $processor->process_tick();
		wp_send_json_success( $result );
	}

	public function handle_batch_stats(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$processor = $this->get_batch_processor();
		if ( ! $processor ) {
			wp_send_json_error( array( 'message' => __( 'ماژول بهینه‌سازی فعال نیست.', 'advanced-image-seo-optimizer' ) ) );
			return;
		}

		wp_send_json_success( $processor->get_stats() );
	}

	public function handle_batch_retry_failed(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$processor = $this->get_batch_processor();
		if ( ! $processor ) {
			wp_send_json_error( array( 'message' => __( 'ماژول بهینه‌سازی فعال نیست.', 'advanced-image-seo-optimizer' ) ) );
			return;
		}

		$requeued = $processor->retry_failed();

		wp_send_json_success(
			array(
				'requeued' => $requeued,
				'stats'    => $processor->get_stats(),
			)
		);
	}

	/**
	 * گزارش کاهش حجم: خلاصه‌ی کل عمر افزونه + روند ۱۴ روز اخیر.
	 * این آمار مستقل از صف است؛ حتی بعد از پاک شدن صف (reset_completed) باقی می‌ماند.
	 */
	public function handle_size_report(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		wp_send_json_success(
			array(
				'summary' => $this->stats_recorder->get_summary(),
				'daily'   => $this->stats_recorder->get_daily( 14 ),
			)
		);
	}

	// -------------------------------------------------------------------
	// ماژول سئو (فاز ۴)
	// -------------------------------------------------------------------

	private function get_seo_engine() {
		return \AISEO\Plugin::get_instance()->get_module( 'seo' );
	}

	private function seo_unavailable_response(): void {
		wp_send_json_error( array( 'message' => __( 'ماژول سئو فعال نیست.', 'advanced-image-seo-optimizer' ) ) );
	}

	public function handle_seo_batch_enqueue(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine = $this->get_seo_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->seo_unavailable_response();
			return;
		}

		$added = $processor->enqueue_eligible();
		wp_send_json_success(
			array(
				'added' => $added,
				'stats' => $processor->get_stats(),
			)
		);
	}

	public function handle_seo_batch_tick(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_seo_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->seo_unavailable_response();
			return;
		}

		$overwrite = $this->settings->should_overwrite_existing_seo();
		wp_send_json_success( $processor->process_tick( $overwrite ) );
	}

	public function handle_seo_batch_stats(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_seo_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->seo_unavailable_response();
			return;
		}

		wp_send_json_success( $processor->get_stats() );
	}

	public function handle_seo_batch_retry_failed(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_seo_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->seo_unavailable_response();
			return;
		}

		$requeued = $processor->retry_failed();
		wp_send_json_success(
			array(
				'requeued' => $requeued,
				'stats'    => $processor->get_stats(),
			)
		);
	}

	public function handle_seo_alt_check(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine = $this->get_seo_engine();
		if ( ! $engine ) {
			$this->seo_unavailable_response();
			return;
		}

		wp_send_json_success( $engine->get_alt_checker()->scan() );
	}

	public function handle_seo_score_summary(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine = $this->get_seo_engine();
		if ( ! $engine ) {
			$this->seo_unavailable_response();
			return;
		}

		wp_send_json_success( $engine->get_scorer()->get_library_summary() );
	}

	public function handle_seo_sitemap_generate(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine = $this->get_seo_engine();
		if ( ! $engine ) {
			$this->seo_unavailable_response();
			return;
		}

		$result = $engine->get_sitemap_generator()->generate();

		if ( 'failed' === $result['status'] ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
			return;
		}

		wp_send_json_success( $result );
	}

	// -------------------------------------------------------------------
	// ماژول واترمارک (فاز ۵)
	// -------------------------------------------------------------------

	private function get_watermark_engine() {
		return \AISEO\Plugin::get_instance()->get_module( 'watermark' );
	}

	private function watermark_unavailable_response(): void {
		wp_send_json_error( array( 'message' => __( 'ماژول واترمارک فعال نیست.', 'advanced-image-seo-optimizer' ) ) );
	}

	public function handle_watermark_batch_enqueue(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_watermark_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->watermark_unavailable_response();
			return;
		}

		$added = $processor->enqueue_eligible();
		wp_send_json_success(
			array(
				'added' => $added,
				'stats' => $processor->get_stats(),
			)
		);
	}

	public function handle_watermark_batch_tick(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_watermark_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->watermark_unavailable_response();
			return;
		}

		wp_send_json_success( $processor->process_tick() );
	}

	public function handle_watermark_batch_stats(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_watermark_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->watermark_unavailable_response();
			return;
		}

		wp_send_json_success( $processor->get_stats() );
	}

	public function handle_watermark_batch_retry_failed(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_watermark_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->watermark_unavailable_response();
			return;
		}

		$requeued = $processor->retry_failed();
		wp_send_json_success(
			array(
				'requeued' => $requeued,
				'stats'    => $processor->get_stats(),
			)
		);
	}

	// -------------------------------------------------------------------
	// ماژول ویرایشگر تصویر (فاز ۶)
	// -------------------------------------------------------------------

	private function get_editor_engine() {
		return \AISEO\Plugin::get_instance()->get_module( 'editor' );
	}

	private function editor_unavailable_response(): void {
		wp_send_json_error( array( 'message' => __( 'ماژول ویرایشگر فعال نیست.', 'advanced-image-seo-optimizer' ) ) );
	}

	/**
	 * دریافت شناسه‌ی attachment از درخواست، با اعتبارسنجی پایه.
	 * @return int 0 در صورت نامعتبر بودن (و ارسال خودکار پاسخ خطا).
	 */
	private function require_attachment_id(): int {
		$attachment_id = isset( $_POST['attachment_id'] ) ? absint( wp_unslash( $_POST['attachment_id'] ) ) : 0;
		if ( $attachment_id <= 0 || 'attachment' !== get_post_type( $attachment_id ) ) {
			wp_send_json_error( array( 'message' => __( 'شناسه‌ی تصویر نامعتبر است.', 'advanced-image-seo-optimizer' ) ) );
			return 0;
		}
		return $attachment_id;
	}

	private function attachment_image_payload( int $attachment_id ): array {
		$file_path = get_attached_file( $attachment_id );
		$version   = ( is_string( $file_path ) && file_exists( $file_path ) ) ? filemtime( $file_path ) : time();
		$metadata  = wp_get_attachment_metadata( $attachment_id );

		return array(
			'url'    => add_query_arg( 'aiseo_v', $version, (string) wp_get_attachment_url( $attachment_id ) ),
			'width'  => is_array( $metadata ) ? (int) ( $metadata['width'] ?? 0 ) : 0,
			'height' => is_array( $metadata ) ? (int) ( $metadata['height'] ?? 0 ) : 0,
		);
	}

	public function handle_editor_get_state(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$attachment_id = $this->require_attachment_id();
		if ( ! $attachment_id ) {
			return;
		}

		$engine = $this->get_editor_engine();
		if ( ! $engine ) {
			$this->editor_unavailable_response();
			return;
		}

		wp_send_json_success(
			array_merge(
				$this->attachment_image_payload( $attachment_id ),
				array( 'state' => $engine->get_history()->get_state( $attachment_id ) )
			)
		);
	}

	public function handle_editor_apply(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$attachment_id = $this->require_attachment_id();
		if ( ! $attachment_id ) {
			return;
		}

		$engine = $this->get_editor_engine();
		if ( ! $engine ) {
			$this->editor_unavailable_response();
			return;
		}

		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		$args_raw = isset( $_POST['args'] ) ? wp_unslash( $_POST['args'] ) : '{}';
		$args = json_decode( is_string( $args_raw ) ? $args_raw : '{}', true );
		$args = is_array( $args ) ? $this->sanitize_editor_args( $op, $args ) : array();

		$result = $engine->get_history()->apply_operation( $attachment_id, $op, $args );

		if ( 'failed' === $result['status'] ) {
			wp_send_json_error( array( 'message' => $result['message'] ?? __( 'عملیات ناموفق بود.', 'advanced-image-seo-optimizer' ) ) );
			return;
		}

		wp_send_json_success( array_merge( $this->attachment_image_payload( $attachment_id ), array( 'state' => $result['state'] ) ) );
	}

	/**
	 * اعتبارسنجی/پاک‌سازی آرگومان‌های عملیات ویرایش پیش از ارسال به Editor_Renderer،
	 * تا هیچ ورودی خام کاربر مستقیماً به GD/Imagick نرسد.
	 */
	private function sanitize_editor_args( string $op, array $args ): array {
		$clean = array();

		switch ( $op ) {
			case 'crop':
				$clean['x']      = max( 0, (int) ( $args['x'] ?? 0 ) );
				$clean['y']      = max( 0, (int) ( $args['y'] ?? 0 ) );
				$clean['width']  = max( 1, (int) ( $args['width'] ?? 1 ) );
				$clean['height'] = max( 1, (int) ( $args['height'] ?? 1 ) );
				break;
			case 'resize':
				$clean['width']       = max( 1, (int) ( $args['width'] ?? 1 ) );
				$clean['height']      = max( 1, (int) ( $args['height'] ?? 1 ) );
				$clean['keep_aspect'] = ! empty( $args['keep_aspect'] );
				break;
			case 'rotate':
				$degrees = (float) ( $args['degrees'] ?? 0 );
				$clean['degrees'] = max( -360, min( 360, $degrees ) );
				break;
			case 'flip':
				$axis = (string) ( $args['axis'] ?? 'horizontal' );
				$clean['axis'] = 'vertical' === $axis ? 'vertical' : 'horizontal';
				break;
			case 'filter':
				$filter = (string) ( $args['filter'] ?? '' );
				$allowed = array( 'brightness', 'contrast', 'grayscale', 'bw' );
				$clean['filter'] = in_array( $filter, $allowed, true ) ? $filter : '';
				$clean['amount'] = max( -100, min( 255, (int) ( $args['amount'] ?? 0 ) ) );
				break;
		}

		return $clean;
	}

	public function handle_editor_undo(): void {
		if ( ! $this->verify_request() ) {
			return;
		}
		$attachment_id = $this->require_attachment_id();
		if ( ! $attachment_id ) {
			return;
		}
		$engine = $this->get_editor_engine();
		if ( ! $engine ) {
			$this->editor_unavailable_response();
			return;
		}

		$result = $engine->get_history()->undo( $attachment_id );
		if ( 'failed' === $result['status'] ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
			return;
		}
		wp_send_json_success( array_merge( $this->attachment_image_payload( $attachment_id ), array( 'state' => $result['state'] ) ) );
	}

	public function handle_editor_redo(): void {
		if ( ! $this->verify_request() ) {
			return;
		}
		$attachment_id = $this->require_attachment_id();
		if ( ! $attachment_id ) {
			return;
		}
		$engine = $this->get_editor_engine();
		if ( ! $engine ) {
			$this->editor_unavailable_response();
			return;
		}

		$result = $engine->get_history()->redo( $attachment_id );
		if ( 'failed' === $result['status'] ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
			return;
		}
		wp_send_json_success( array_merge( $this->attachment_image_payload( $attachment_id ), array( 'state' => $result['state'] ) ) );
	}

	public function handle_editor_reset(): void {
		if ( ! $this->verify_request() ) {
			return;
		}
		$attachment_id = $this->require_attachment_id();
		if ( ! $attachment_id ) {
			return;
		}
		$engine = $this->get_editor_engine();
		if ( ! $engine ) {
			$this->editor_unavailable_response();
			return;
		}

		$result = $engine->get_history()->reset_to_original( $attachment_id );
		if ( 'failed' === $result['status'] ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
			return;
		}
		wp_send_json_success( array_merge( $this->attachment_image_payload( $attachment_id ), array( 'state' => $result['state'] ) ) );
	}

	public function handle_editor_batch_enqueue(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_editor_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->editor_unavailable_response();
			return;
		}

		$added = $processor->enqueue_eligible();
		wp_send_json_success(
			array(
				'added' => $added,
				'stats' => $processor->get_stats(),
			)
		);
	}

	public function handle_editor_batch_tick(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_editor_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->editor_unavailable_response();
			return;
		}

		wp_send_json_success( $processor->process_tick() );
	}

	public function handle_editor_batch_stats(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_editor_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->editor_unavailable_response();
			return;
		}

		wp_send_json_success( $processor->get_stats() );
	}

	public function handle_editor_batch_retry_failed(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_editor_engine();
		$processor = $engine ? $engine->get_batch_processor() : null;
		if ( ! $processor ) {
			$this->editor_unavailable_response();
			return;
		}

		$requeued = $processor->retry_failed();
		wp_send_json_success(
			array(
				'requeued' => $requeued,
				'stats'    => $processor->get_stats(),
			)
		);
	}

	// -------------------------------------------------------------------
	// ماژول مدیریت کتابخانه‌ی رسانه (فاز ۷)
	// -------------------------------------------------------------------

	private function get_media_library_engine() {
		return \AISEO\Plugin::get_instance()->get_module( 'media_library' );
	}

	private function media_library_unavailable_response(): void {
		wp_send_json_error( array( 'message' => __( 'ماژول مدیریت کتابخانه فعال نیست.', 'advanced-image-seo-optimizer' ) ) );
	}

	public function handle_ml_stats_summary(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine = $this->get_media_library_engine();
		if ( ! $engine ) {
			$this->media_library_unavailable_response();
			return;
		}

		wp_send_json_success( $engine->get_stats_dashboard()->get_summary() );
	}

	// --- تشخیص تکراری ---

	public function handle_ml_duplicate_batch_enqueue(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_media_library_engine();
		$processor = $engine ? $engine->get_duplicate_batch_processor() : null;
		if ( ! $processor ) {
			$this->media_library_unavailable_response();
			return;
		}

		$added = $processor->enqueue_eligible();
		wp_send_json_success(
			array(
				'added' => $added,
				'stats' => $processor->get_stats(),
			)
		);
	}

	public function handle_ml_duplicate_batch_tick(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_media_library_engine();
		$processor = $engine ? $engine->get_duplicate_batch_processor() : null;
		if ( ! $processor ) {
			$this->media_library_unavailable_response();
			return;
		}

		wp_send_json_success( $processor->process_tick() );
	}

	public function handle_ml_duplicate_batch_stats(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_media_library_engine();
		$processor = $engine ? $engine->get_duplicate_batch_processor() : null;
		if ( ! $processor ) {
			$this->media_library_unavailable_response();
			return;
		}

		wp_send_json_success( $processor->get_stats() );
	}

	public function handle_ml_duplicate_batch_retry_failed(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_media_library_engine();
		$processor = $engine ? $engine->get_duplicate_batch_processor() : null;
		if ( ! $processor ) {
			$this->media_library_unavailable_response();
			return;
		}

		$requeued = $processor->retry_failed();
		wp_send_json_success(
			array(
				'requeued' => $requeued,
				'stats'    => $processor->get_stats(),
			)
		);
	}

	public function handle_ml_duplicate_groups(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine = $this->get_media_library_engine();
		if ( ! $engine ) {
			$this->media_library_unavailable_response();
			return;
		}

		wp_send_json_success(
			array( 'groups' => $engine->get_duplicate_detector()->get_duplicate_groups( 30 ) )
		);
	}

	// --- سلامت فایل / بازسازی thumbnail ---

	public function handle_ml_cleanup_batch_enqueue(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_media_library_engine();
		$processor = $engine ? $engine->get_cleanup_batch_processor() : null;
		if ( ! $processor ) {
			$this->media_library_unavailable_response();
			return;
		}

		$added = $processor->enqueue_eligible();
		wp_send_json_success(
			array(
				'added' => $added,
				'stats' => $processor->get_stats(),
			)
		);
	}

	public function handle_ml_cleanup_batch_tick(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_media_library_engine();
		$processor = $engine ? $engine->get_cleanup_batch_processor() : null;
		if ( ! $processor ) {
			$this->media_library_unavailable_response();
			return;
		}

		wp_send_json_success( $processor->process_tick() );
	}

	public function handle_ml_cleanup_batch_stats(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_media_library_engine();
		$processor = $engine ? $engine->get_cleanup_batch_processor() : null;
		if ( ! $processor ) {
			$this->media_library_unavailable_response();
			return;
		}

		wp_send_json_success( $processor->get_stats() );
	}

	public function handle_ml_cleanup_batch_retry_failed(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine    = $this->get_media_library_engine();
		$processor = $engine ? $engine->get_cleanup_batch_processor() : null;
		if ( ! $processor ) {
			$this->media_library_unavailable_response();
			return;
		}

		$requeued = $processor->retry_failed();
		wp_send_json_success(
			array(
				'requeued' => $requeued,
				'stats'    => $processor->get_stats(),
			)
		);
	}

	public function handle_ml_cleanup_items(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$engine = $this->get_media_library_engine();
		if ( ! $engine ) {
			$this->media_library_unavailable_response();
			return;
		}

		wp_send_json_success(
			array( 'items' => $engine->get_cleanup_manager()->get_problem_items( 50 ) )
		);
	}

	public function handle_ml_cleanup_rebuild_one(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$attachment_id = isset( $_POST['attachment_id'] ) ? absint( wp_unslash( $_POST['attachment_id'] ) ) : 0;
		if ( $attachment_id <= 0 || 'attachment' !== get_post_type( $attachment_id ) ) {
			wp_send_json_error( array( 'message' => __( 'شناسه‌ی تصویر نامعتبر است.', 'advanced-image-seo-optimizer' ) ) );
			return;
		}

		$engine = $this->get_media_library_engine();
		if ( ! $engine ) {
			$this->media_library_unavailable_response();
			return;
		}

		$cleanup_manager = $engine->get_cleanup_manager();
		$success         = $cleanup_manager->rebuild( $attachment_id );

		if ( ! $success ) {
			wp_send_json_error( array( 'message' => __( 'بازسازی thumbnail ها ناموفق بود (احتمالاً فایل اصلی موجود نیست).', 'advanced-image-seo-optimizer' ) ) );
			return;
		}

		$result = $cleanup_manager->scan_attachment( $attachment_id );
		wp_send_json_success( array( 'status' => $result['status'] ) );
	}

	// --- حذف دستی یک تصویر تکراری از داخل پنل ---

	public function handle_ml_delete_attachment(): void {
		if ( ! $this->verify_request() ) {
			return;
		}

		$attachment_id = isset( $_POST['attachment_id'] ) ? absint( wp_unslash( $_POST['attachment_id'] ) ) : 0;
		if ( $attachment_id <= 0 || 'attachment' !== get_post_type( $attachment_id ) ) {
			wp_send_json_error( array( 'message' => __( 'شناسه‌ی تصویر نامعتبر است.', 'advanced-image-seo-optimizer' ) ) );
			return;
		}

		$result = wp_delete_attachment( $attachment_id, true );

		if ( ! $result ) {
			wp_send_json_error( array( 'message' => __( 'حذف تصویر ناموفق بود.', 'advanced-image-seo-optimizer' ) ) );
			return;
		}

		$this->logger->info( 'media_library', "attachment #{$attachment_id} از طریق پنل مدیریت کتابخانه حذف شد." );

		wp_send_json_success( array( 'deleted' => $attachment_id ) );
	}
}
