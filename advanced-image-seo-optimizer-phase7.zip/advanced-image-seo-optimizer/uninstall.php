<?php
/**
 * اجرا فقط هنگام حذف کامل افزونه از صفحه‌ی افزونه‌های وردپرس (نه غیرفعال‌سازی ساده).
 * طبق اصل Non-destructive: به‌طور پیش‌فرض هیچ داده‌ای حذف نمی‌شود، مگر این‌که کاربر
 * صراحتاً گزینه‌ی «حذف کامل داده‌ها هنگام حذف افزونه» را در تنظیمات فعال کرده باشد.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$remove_data = (bool) get_option( 'aiseo_remove_data_on_uninstall', 0 );

if ( ! $remove_data ) {
	return;
}

global $wpdb;

// حذف جداول سفارشی
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}aiseo_queue" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}aiseo_logs" );

// حذف همه‌ی options با پیشوند aiseo_
$option_names = $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'aiseo\_%'" );
foreach ( $option_names as $option_name ) {
	delete_option( $option_name );
}

// حذف postmeta مربوط به بکاپ فایل اصلی و تاریخچه‌ی Undo/Redo ویرایشگر (فاز ۶)
$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_aiseo_original_backup'" );
$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ( '_aiseo_editor_history', '_aiseo_editor_pointer' )" );

// حذف postmeta مربوط به ماژول مدیریت کتابخانه (فاز ۷): هش تکراری و نتیجه‌ی اسکن سلامت
$wpdb->query(
	"DELETE FROM {$wpdb->postmeta} WHERE meta_key IN (
		'_aiseo_content_hash', '_aiseo_ml_scan_status', '_aiseo_ml_scan_details',
		'_aiseo_ml_file_size', '_aiseo_ml_scan_time'
	)"
);

// حذف پوشه‌ی بکاپ‌های فایل اصلی (فقط اگر کاربر صراحتاً درخواست حذف کامل داده کرده باشد)
$upload_dir = wp_get_upload_dir();
$backup_dir = trailingslashit( $upload_dir['basedir'] ) . 'aiseo-backups';

if ( is_dir( $backup_dir ) ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	WP_Filesystem();
	global $wp_filesystem;
	if ( $wp_filesystem ) {
		$wp_filesystem->delete( $backup_dir, true );
	}
}
