<?php
namespace AISEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * موتور صف پردازش دسته‌ای.
 * روی جدول سفارشی {prefix}aiseo_queue کار می‌کند تا پردازش قابل توقف/ادامه باشد
 * و در برابر تایم‌اوت هاست‌های ضعیف مقاوم شود (به‌جای یک درخواست طولانی، تکه‌های کوچک).
 * قفل‌گذاری با transient از اجرای همزمان دو batch جلوگیری می‌کند.
 */
class Queue_Manager {

	private string $table;
	private Logger $logger;

	public function __construct( Logger $logger ) {
		global $wpdb;
		$this->table  = $wpdb->prefix . 'aiseo_queue';
		$this->logger = $logger;
	}

	/**
	 * افزودن یک آیتم به صف. اگر آیتم مشابه (همان type + object_id) در وضعیت
	 * pending یا processing از قبل وجود داشته باشد، دوباره اضافه نمی‌شود
	 * (جلوگیری از پردازش تکراری طبق نیازمندی محصول).
	 */
	public function enqueue( string $item_type, int $object_id ): bool {
		global $wpdb;

		$exists = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$this->table} WHERE item_type = %s AND object_id = %d AND status IN ('pending','processing') LIMIT 1",
				$item_type,
				$object_id
			)
		);

		if ( $exists ) {
			return false;
		}

		$now = current_time( 'mysql' );

		return false !== $wpdb->insert(
			$this->table,
			array(
				'item_type'  => $item_type,
				'object_id'  => $object_id,
				'status'     => 'pending',
				'attempts'   => 0,
				'created_at' => $now,
				'updated_at' => $now,
			),
			array( '%s', '%d', '%s', '%d', '%s', '%s' )
		);
	}

	/**
	 * گرفتن یک تکه از آیتم‌های pending و علامت‌گذاری آن‌ها به processing،
	 * تا در صورت اجرای همزمان دو تیک، آیتم‌ها دوبار پردازش نشوند.
	 */
	public function claim_batch( string $item_type, int $limit ): array {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$this->table} WHERE item_type = %s AND status = 'pending' ORDER BY id ASC LIMIT %d",
				$item_type,
				$limit
			)
		);

		if ( empty( $rows ) ) {
			return array();
		}

		$ids = wp_list_pluck( $rows, 'id' );
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- placeholders به‌صورت پویا ولی امن با %d ساخته شده‌اند.
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$this->table} SET status = 'processing', updated_at = %s WHERE id IN ({$placeholders})",
				array_merge( array( current_time( 'mysql' ) ), $ids )
			)
		);

		return $rows;
	}

	public function mark_done( int $queue_id ): void {
		$this->update_status( $queue_id, 'done', '' );
	}

	public function mark_failed( int $queue_id, string $message ): void {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$this->table} SET status = 'failed', attempts = attempts + 1, message = %s, updated_at = %s WHERE id = %d",
				$message,
				current_time( 'mysql' ),
				$queue_id
			)
		);
	}

	private function update_status( int $queue_id, string $status, string $message ): void {
		global $wpdb;
		$wpdb->update(
			$this->table,
			array(
				'status'     => $status,
				'message'    => $message,
				'updated_at' => current_time( 'mysql' ),
			),
			array( 'id' => $queue_id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	public function get_stats( string $item_type ): array {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT status, COUNT(*) as cnt FROM {$this->table} WHERE item_type = %s GROUP BY status",
				$item_type
			),
			ARRAY_A
		);

		$stats = array(
			'pending'    => 0,
			'processing' => 0,
			'done'       => 0,
			'failed'     => 0,
		);

		foreach ( $rows as $row ) {
			$stats[ $row['status'] ] = (int) $row['cnt'];
		}

		return $stats;
	}

	/**
	 * پاکسازی صف تکمیل‌شده برای شروع یک batch جدید تمیز.
	 */
	public function clear_completed( string $item_type ): void {
		global $wpdb;
		$wpdb->delete(
			$this->table,
			array( 'item_type' => $item_type, 'status' => 'done' ),
			array( '%s', '%s' )
		);
	}

	/**
	 * بازگرداندن آیتم‌های failed به pending برای تلاش مجدد، بدون افزایش شمارنده‌ی attempts
	 * (attempts در mark_failed افزایش یافته و همچنان برای تشخیص «چندبار تلاش شده» باقی می‌ماند).
	 * آیتم‌های گیرکرده در وضعیت processing هم شامل می‌شوند: چون هر تیک synchronous است و در همان
	 * درخواست HTTP به done/failed می‌رسد، processing باقی‌مانده یعنی آن درخواست میانه‌ی کار
	 * (مثلاً به‌خاطر خطای fatal کمبود حافظه روی هاست ضعیف) قطع شده است.
	 *
	 * @return int تعداد ردیف‌های تغییر‌یافته
	 */
	public function retry_failed( string $item_type ): int {
		global $wpdb;

		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$this->table} SET status = 'pending', message = '', updated_at = %s
				WHERE item_type = %s AND status IN ('failed','processing')",
				current_time( 'mysql' ),
				$item_type
			)
		);

		return false === $updated ? 0 : (int) $updated;
	}

	// -------------------------------------------------------------------
	// قفل ساده‌ی transient برای جلوگیری از اجرای همزمان دو batch
	// -------------------------------------------------------------------

	public function acquire_lock( string $item_type, int $ttl_seconds = 60 ): bool {
		$lock_key = 'aiseo_queue_lock_' . $item_type;
		if ( get_transient( $lock_key ) ) {
			return false;
		}
		set_transient( $lock_key, 1, $ttl_seconds );
		return true;
	}

	public function release_lock( string $item_type ): void {
		delete_transient( 'aiseo_queue_lock_' . $item_type );
	}
}
