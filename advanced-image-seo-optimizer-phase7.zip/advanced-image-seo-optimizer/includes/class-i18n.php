<?php
namespace AISEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * بارگذاری فایل‌های ترجمه. زبان پیش‌فرض توسعه فارسی (fa_IR) است؛
 * انگلیسی به‌عنوان زبان دوم پشتیبانی می‌شود.
 */
class I18n {

	public function load(): void {
		load_plugin_textdomain(
			'advanced-image-seo-optimizer',
			false,
			dirname( AISEO_PLUGIN_BASENAME ) . '/languages'
		);
	}
}
