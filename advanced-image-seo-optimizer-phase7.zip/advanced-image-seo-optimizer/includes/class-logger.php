<?php
namespace AISEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * سیستم لاگ حرفه‌ای افزونه.
 * سطح‌بندی: info / warning / error.
 * ذخیره در جدول سفارشی DB به‌جای error_log خام تا در داشبورد ادمین قابل نمایش و فیلتر باشد.
 * شکست در نوشتن لاگ هرگز نباید باعث توقف فرآیند اصلی افزونه شود (fail-silent با error_log پشتیبان).
 */
class Logger {

	private const LEVELS = array( 'info', 'warning', 'error' );
	private const MAX_ROWS = 5000; // سقف نگهداری برای جلوگیری از رشد بی‌رویه جدول روی هاست‌های ضعیف

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'aiseo_logs';
	}

	public function info( string $module, string $message, array $context = array() ): void {
		$this->log( 'info', $module, $message, $context );
	}

	public function warning( string $module, string $message, array $context = array() ): void {
		$this->log( 'warning', $module, $message, $context );
	}

	public function error( string $module, string $message, array $context = array() ): void {
		$this->log( 'error', $module, $message, $context );
	}

	public function log( string $level, string $module, string $message, array $context = array() ): void {
		if ( ! in_array( $level, self::LEVELS, true ) ) {
			$level = 'info';
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- جدول اختصاصی افزونه، بدون کش لازم برای لاگ.
		$inserted = $wpdb->insert(
			$this->table,
			array(
				'level'      => $level,
				'module'     => sanitize_key( $module ),
				'message'    => wp_strip_all_tags( $message ),
				'context'    => ! empty( $context ) ? wp_json_encode( $context ) : null,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s' )
		);

		if ( false === $inserted ) {
			// fallback: اگر جدول هنوز ساخته نشده یا خطای DB رخ داده، حداقل در لاگ سرور ثبت شود.
			error_log( sprintf( '[AISEO][%s][%s] %s', $level, $module, $message ) );
			return;
		}

		$this->maybe_prune();
	}

	/**
	 * وقتی تعداد ردیف‌ها از سقف عبور کند، قدیمی‌ترین‌ها حذف می‌شوند (چرخش ساده).
	 * فقط گاه‌به‌گاه (۱ از هر ۵۰ درج) بررسی می‌شود تا هزینه‌ی هر درخواست بالا نرود.
	 */
	private function maybe_prune(): void {
		if ( 0 !== wp_rand( 0, 49 ) ) {
			return;
		}

		global $wpdb;
		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table}" );

		if ( $count > self::MAX_ROWS ) {
			$excess = $count - self::MAX_ROWS;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- حذف چرخشی قدیمی‌ترین لاگ‌ها.
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$this->table} ORDER BY id ASC LIMIT %d", $excess ) );
		}
	}

	/**
	 * دریافت آخرین لاگ‌ها برای نمایش در داشبورد ادمین.
	 */
	public function get_recent( int $limit = 50, string $level = '' ): array {
		global $wpdb;
		$limit = max( 1, min( 500, $limit ) );

		if ( '' !== $level && in_array( $level, self::LEVELS, true ) ) {
			return $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$this->table} WHERE level = %s ORDER BY id DESC LIMIT %d",
					$level,
					$limit
				)
			);
		}

		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table} ORDER BY id DESC LIMIT %d", $limit ) );
	}
}
