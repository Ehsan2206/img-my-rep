<?php
namespace AISEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * منطق فعال‌سازی افزونه: ساخت جداول سفارشی DB (صف و لاگ) و مقداردهی اولیه‌ی options.
 * طبق تصمیم معماری فاز ۱: صف و لاگ در جدول سفارشی نگه‌داری می‌شوند نه در options،
 * تا روی گالری‌های بزرگ عملکرد بهتری داشته باشیم.
 */
class Activator {

	/**
	 * نسخه‌ی طرح DB، مستقل از نسخه‌ی افزونه. فقط وقتی جدولی اضافه/تغییر می‌کند این عدد بالا می‌رود
	 * تا dbDelta روی هر ارتقای جزئی افزونه بی‌جهت اجرا نشود.
	 */
	private const DB_SCHEMA_VERSION = '2';

	public static function activate(): void {
		self::create_tables();
		self::set_default_options();
		update_option( 'aiseo_db_version', self::DB_SCHEMA_VERSION );

		// یک flag موقت که به Admin می‌گوید بعد از فعال‌سازی، یک بار پیام خوش‌آمد نشان بده.
		set_transient( 'aiseo_activation_redirect', true, 30 );
	}

	/**
	 * روی هر بارگذاری افزونه بررسی می‌کند آیا طرح DB به‌روز است یا نه.
	 * برای مواردی که فایل‌های افزونه از طریق آپلود/آپدیت خودکار جایگزین شده‌اند
	 * بدون این‌که hook فعال‌سازی دوباره اجرا شود (چون افزونه غیرفعال نشده).
	 * dbDelta idempotent است، پس فراخوانی امن است؛ فقط وقتی نسخه فرق دارد اجرا می‌شود.
	 */
	public static function maybe_upgrade(): void {
		if ( get_option( 'aiseo_db_version' ) === self::DB_SCHEMA_VERSION ) {
			return;
		}

		self::create_tables();
		self::set_default_options();
		update_option( 'aiseo_db_version', self::DB_SCHEMA_VERSION );
	}

	private static function create_tables(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		$queue_table = $wpdb->prefix . 'aiseo_queue';
		$logs_table  = $wpdb->prefix . 'aiseo_logs';

		$sql_queue = "CREATE TABLE {$queue_table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			item_type VARCHAR(64) NOT NULL DEFAULT 'optimize_image',
			object_id BIGINT UNSIGNED NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			message TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY status_idx (status),
			KEY item_type_idx (item_type),
			KEY object_id_idx (object_id)
		) {$charset_collate};";

		$sql_logs = "CREATE TABLE {$logs_table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			level VARCHAR(10) NOT NULL DEFAULT 'info',
			module VARCHAR(64) NOT NULL DEFAULT 'core',
			message TEXT NOT NULL,
			context LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY level_idx (level),
			KEY created_at_idx (created_at)
		) {$charset_collate};";

		dbDelta( $sql_queue );
		dbDelta( $sql_logs );
		dbDelta( Stats_Recorder::get_schema_sql() );
	}

	private static function set_default_options(): void {
		$defaults = Settings::get_default_options();

		foreach ( $defaults as $key => $value ) {
			// add_option() در صورت وجود قبلی کلید، هیچ کاری نمی‌کند؛ پس بازنویسی تنظیمات کاربر رخ نمی‌دهد.
			add_option( $key, $value );
		}
	}
}
