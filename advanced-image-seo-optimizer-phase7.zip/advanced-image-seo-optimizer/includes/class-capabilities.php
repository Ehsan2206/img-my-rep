<?php
namespace AISEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تعریف و بررسی مرکزی دسترسی‌ها.
 * فعلاً روی capability استاندارد manage_options وردپرس سوار می‌شود؛
 * در آینده در صورت نیاز به نقش‌های سفارشی (مثلاً "ویرایشگر سئوی تصویر")
 * فقط همین کلاس تغییر می‌کند و بقیه‌ی کد دست‌نخورده می‌ماند.
 */
class Capabilities {

	public const MANAGE = 'manage_options';

	public static function current_user_can_manage(): bool {
		return current_user_can( self::MANAGE );
	}

	/**
	 * بررسی دسترسی + توقف اجرا با پیام مناسب در صورت نبود مجوز.
	 * برای استفاده در ابتدای اکشن‌های حساس ادمین (صفحات، AJAX).
	 */
	public static function require_manage_or_die(): void {
		if ( ! self::current_user_can_manage() ) {
			wp_die(
				esc_html__( 'شما دسترسی لازم برای انجام این عملیات را ندارید.', 'advanced-image-seo-optimizer' ),
				esc_html__( 'دسترسی غیرمجاز', 'advanced-image-seo-optimizer' ),
				array( 'response' => 403 )
			);
		}
	}
}
