<?php
namespace AISEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * منطق غیرفعال‌سازی: فقط پاکسازی cron/transient های موقت.
 * هیچ داده‌ای (جداول، options، فایل‌های بکاپ) در غیرفعال‌سازی حذف نمی‌شود؛
 * حذف قطعی داده فقط در uninstall.php و طبق تنظیم صریح کاربر انجام می‌شود.
 */
class Deactivator {

	public static function deactivate(): void {
		$scheduled_hooks = array(
			'aiseo_queue_tick',
			'aiseo_daily_log_cleanup',
		);

		foreach ( $scheduled_hooks as $hook ) {
			$timestamp = wp_next_scheduled( $hook );
			if ( $timestamp ) {
				wp_unschedule_event( $timestamp, $hook );
			}
			wp_clear_scheduled_hook( $hook );
		}

		delete_transient( 'aiseo_activation_redirect' );
	}
}
