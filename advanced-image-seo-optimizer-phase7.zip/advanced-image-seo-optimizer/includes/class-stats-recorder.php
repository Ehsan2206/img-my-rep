<?php
namespace AISEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ثبت آماری حجم کاهش‌یافته توسط تبدیل تصاویر (چه از مسیر آپلود تکی، چه پردازش دسته‌ای).
 * روی جدول سفارشی DB با یک ردیف در روز کار می‌کند (نه یک ردیف به‌ازای هر تصویر)
 * تا هم روی گالری‌های چند هزار تصویری سبک بماند و هم گزارش روند روزانه ممکن باشد.
 * برخلاف جدول صف که با هر ریست پاک می‌شود، این آمار زنده و همیشگی است.
 */
class Stats_Recorder {

	private string $table;

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'aiseo_optim_stats';
	}

	public static function get_schema_sql(): string {
		global $wpdb;
		$table            = $wpdb->prefix . 'aiseo_optim_stats';
		$charset_collate  = $wpdb->get_charset_collate();

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			stat_date DATE NOT NULL,
			files_converted INT UNSIGNED NOT NULL DEFAULT 0,
			bytes_before BIGINT UNSIGNED NOT NULL DEFAULT 0,
			bytes_after BIGINT UNSIGNED NOT NULL DEFAULT 0,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY stat_date_idx (stat_date)
		) {$charset_collate};";
	}

	/**
	 * ثبت یک تبدیل موفق. با یک کوئری اتمیک (INSERT ... ON DUPLICATE KEY UPDATE) روی ردیف
	 * امروز جمع زده می‌شود، بدون نیاز به خواندن-تغییر-نوشتن جداگانه (امن در برابر تداخل درخواست‌های همزمان).
	 */
	public function record_conversion( int $bytes_before, int $bytes_after ): void {
		if ( $bytes_before <= 0 || $bytes_after < 0 ) {
			return;
		}

		global $wpdb;
		$today = current_time( 'Y-m-d' );
		$now   = current_time( 'mysql' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- مقادیر با wpdb->prepare پاک‌سازی شده‌اند.
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$this->table} (stat_date, files_converted, bytes_before, bytes_after, updated_at)
				VALUES (%s, 1, %d, %d, %s)
				ON DUPLICATE KEY UPDATE
					files_converted = files_converted + 1,
					bytes_before = bytes_before + VALUES(bytes_before),
					bytes_after = bytes_after + VALUES(bytes_after),
					updated_at = VALUES(updated_at)",
				$today,
				$bytes_before,
				$bytes_after,
				$now
			)
		);
	}

	/**
	 * خلاصه‌ی کل عمر افزونه (از ابتدای نصب تاکنون).
	 *
	 * @return array{files:int, bytes_before:int, bytes_after:int, bytes_saved:int, percent_saved:float}
	 */
	public function get_summary(): array {
		global $wpdb;

		$row = $wpdb->get_row(
			"SELECT
				COALESCE(SUM(files_converted), 0) AS files,
				COALESCE(SUM(bytes_before), 0) AS bytes_before,
				COALESCE(SUM(bytes_after), 0) AS bytes_after
			FROM {$this->table}",
			ARRAY_A
		);

		return $this->to_report_row( $row );
	}

	/**
	 * گزارش روزانه‌ی N روز اخیر برای نمایش روند در داشبورد.
	 *
	 * @return array<int, array{date:string, files:int, bytes_before:int, bytes_after:int, bytes_saved:int, percent_saved:float}>
	 */
	public function get_daily( int $days = 14 ): array {
		global $wpdb;
		$days = max( 1, min( 90, $days ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT stat_date, files_converted, bytes_before, bytes_after
				FROM {$this->table}
				ORDER BY stat_date DESC
				LIMIT %d",
				$days
			),
			ARRAY_A
		);

		$report = array();
		foreach ( (array) $rows as $row ) {
			$item         = $this->to_report_row(
				array(
					'files'        => $row['files_converted'],
					'bytes_before' => $row['bytes_before'],
					'bytes_after'  => $row['bytes_after'],
				)
			);
			$item['date'] = $row['stat_date'];
			$report[]     = $item;
		}

		return $report;
	}

	/**
	 * @param array{files:int|string, bytes_before:int|string, bytes_after:int|string}|null $row
	 * @return array{files:int, bytes_before:int, bytes_after:int, bytes_saved:int, percent_saved:float}
	 */
	private function to_report_row( ?array $row ): array {
		$files        = (int) ( $row['files'] ?? 0 );
		$bytes_before = (int) ( $row['bytes_before'] ?? 0 );
		$bytes_after  = (int) ( $row['bytes_after'] ?? 0 );
		$bytes_saved  = max( 0, $bytes_before - $bytes_after );
		$percent      = $bytes_before > 0 ? round( ( $bytes_saved / $bytes_before ) * 100, 1 ) : 0.0;

		return array(
			'files'         => $files,
			'bytes_before'  => $bytes_before,
			'bytes_after'   => $bytes_after,
			'bytes_saved'   => $bytes_saved,
			'percent_saved' => $percent,
		);
	}
}
