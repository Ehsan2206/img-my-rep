<?php
namespace AISEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * نقطه‌ی مرکزی مدیریت تنظیمات افزونه.
 * تمام کلیدهای option با پیشوند aiseo_ ثبت می‌شوند تا از تداخل با افزونه‌های دیگر
 * (از جمله webp-converter.php قدیمی) جلوگیری شود.
 */
class Settings {

	public const OPTION_GROUP = 'aiseo_settings_group';

	/**
	 * مقادیر پیش‌فرض همه‌ی تنظیمات افزونه.
	 */
	public static function get_default_options(): array {
		return array(
			// فعال/غیرفعال بودن هر ماژول
			'aiseo_module_optimization'   => 1,
			'aiseo_module_seo'            => 0, // فاز ۴
			'aiseo_module_watermark'      => 0, // فاز ۵
			'aiseo_module_editor'         => 0, // فاز ۶
			'aiseo_module_media_library'  => 0, // فاز ۷

			// تنظیمات ماژول بهینه‌سازی (برگرفته از webp-converter.php و منطبق با معماری جدید)
			'aiseo_opt_enable_conversion' => 1,
			'aiseo_opt_output_format'     => 'webp', // webp | avif
			'aiseo_opt_quality'           => 80,
			'aiseo_opt_lossless'          => 0,
			'aiseo_opt_enable_resize'     => 1,
			'aiseo_opt_max_size'          => 2560,
			'aiseo_opt_max_file_size_kb'  => 0, // 0 = بدون محدودیت
			'aiseo_opt_strip_metadata'    => 1,
			'aiseo_opt_convert_formats'   => array(
				'jpeg' => 1,
				'png'  => 1,
				'gif'  => 1,
				'bmp'  => 1,
				'tiff' => 1,
				'svg'  => 1,
				'avif' => 1,
			),
			// تصمیم معماری کلیدی #۴ (Non-destructive): پیش‌فرض همیشه نسخه‌ی اصلی نگه داشته می‌شود.
			'aiseo_opt_keep_original_backup' => 1,
			'aiseo_opt_batch_chunk_size'      => 5,

			// تنظیمات ماژول سئو (فاز ۴)
			'aiseo_seo_auto_generate_on_upload' => 1,
			'aiseo_seo_alt_template'             => '{filename} - {site_name}',
			'aiseo_seo_title_template'           => '{filename}',
			'aiseo_seo_caption_template'         => '{filename}',
			'aiseo_seo_description_template'     => '{filename} - {parent_title}',
			'aiseo_seo_overwrite_existing'       => 0,

			// تنظیمات ماژول واترمارک (فاز ۵)
			'aiseo_watermark_type'            => 'text',
			'aiseo_watermark_text'            => '{site_name}',
			'aiseo_watermark_text_color'      => '#ffffff',
			'aiseo_watermark_font_size'       => 16,
			'aiseo_watermark_image_id'        => 0,
			'aiseo_watermark_position'        => 'bottom-right',
			'aiseo_watermark_opacity'         => 60,
			'aiseo_watermark_margin'          => 16,
			'aiseo_watermark_scale'           => 20,
			'aiseo_watermark_min_width'       => 400,
			'aiseo_watermark_apply_on_upload' => 0,
			'aiseo_watermark_keep_backup'     => 1,
			'aiseo_watermark_target_sizes'    => array(
				'full'      => 1,
				'large'     => 1,
				'medium'    => 0,
				'thumbnail' => 0,
			),

			// تنظیمات ماژول ویرایشگر تصویر (فاز ۶)
			'aiseo_editor_max_history'     => 10,
			'aiseo_editor_jpeg_quality'    => 90,
			'aiseo_editor_batch_operation' => 'rotate_cw',

			// تنظیمات ماژول مدیریت کتابخانه‌ی رسانه (فاز ۷)
			'aiseo_ml_auto_rebuild_thumbnails' => 0,

			// عمومی
			'aiseo_remove_data_on_uninstall' => 0,
			'aiseo_db_version'                => AISEO_VERSION,
		);
	}

	public function get_enabled_modules(): array {
		return array(
			'optimization'  => (bool) get_option( 'aiseo_module_optimization', 1 ),
			'seo'           => (bool) get_option( 'aiseo_module_seo', 0 ),
			'watermark'     => (bool) get_option( 'aiseo_module_watermark', 0 ),
			'editor'        => (bool) get_option( 'aiseo_module_editor', 0 ),
			'media_library' => (bool) get_option( 'aiseo_module_media_library', 0 ),
		);
	}

	/**
	 * ثبت رسمی همه‌ی options نزد وردپرس با sanitize callback مناسب هرکدام.
	 * روی هوک admin_init فراخوانی می‌شود.
	 */
	public function register(): void {
		$sanitizer = new Helpers\Sanitizer();

		$bool_keys = array(
			'aiseo_module_optimization',
			'aiseo_module_seo',
			'aiseo_module_watermark',
			'aiseo_module_editor',
			'aiseo_module_media_library',
			'aiseo_opt_enable_conversion',
			'aiseo_opt_lossless',
			'aiseo_opt_enable_resize',
			'aiseo_opt_strip_metadata',
			'aiseo_opt_keep_original_backup',
			'aiseo_seo_auto_generate_on_upload',
			'aiseo_seo_overwrite_existing',
			'aiseo_watermark_apply_on_upload',
			'aiseo_watermark_keep_backup',
			'aiseo_ml_auto_rebuild_thumbnails',
			'aiseo_remove_data_on_uninstall',
		);

		foreach ( $bool_keys as $key ) {
			register_setting(
				self::OPTION_GROUP,
				$key,
				array(
					'type'              => 'boolean',
					'sanitize_callback' => array( $sanitizer, 'sanitize_bool' ),
					'default'           => 0,
				)
			);
		}

		register_setting(
			self::OPTION_GROUP,
			'aiseo_opt_output_format',
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $sanitizer, 'sanitize_output_format' ),
				'default'           => 'webp',
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_opt_quality',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_quality' ),
				'default'           => 80,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_opt_max_size',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_positive_int' ),
				'default'           => 2560,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_opt_max_file_size_kb',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_non_negative_int' ),
				'default'           => 0,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_opt_batch_chunk_size',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_batch_chunk' ),
				'default'           => 5,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_opt_convert_formats',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $sanitizer, 'sanitize_format_list' ),
				'default'           => self::get_default_options()['aiseo_opt_convert_formats'],
			)
		);

		$template_keys = array(
			'aiseo_seo_alt_template'         => '{filename} - {site_name}',
			'aiseo_seo_title_template'       => '{filename}',
			'aiseo_seo_caption_template'     => '{filename}',
			'aiseo_seo_description_template' => '{filename} - {parent_title}',
			'aiseo_watermark_text'           => '{site_name}',
		);

		foreach ( $template_keys as $key => $default ) {
			register_setting(
				self::OPTION_GROUP,
				$key,
				array(
					'type'              => 'string',
					'sanitize_callback' => array( $sanitizer, 'sanitize_template' ),
					'default'           => $default,
				)
			);
		}

		// -------------------------------------------------------------------
		// ماژول واترمارک (فاز ۵)
		// -------------------------------------------------------------------

		register_setting(
			self::OPTION_GROUP,
			'aiseo_watermark_type',
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $sanitizer, 'sanitize_watermark_type' ),
				'default'           => 'text',
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_watermark_text_color',
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $sanitizer, 'sanitize_hex_color' ),
				'default'           => '#ffffff',
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_watermark_font_size',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_watermark_font_size' ),
				'default'           => 16,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_watermark_image_id',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_attachment_id' ),
				'default'           => 0,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_watermark_position',
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $sanitizer, 'sanitize_watermark_position' ),
				'default'           => 'bottom-right',
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_watermark_opacity',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_percentage' ),
				'default'           => 60,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_watermark_margin',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_non_negative_int' ),
				'default'           => 16,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_watermark_scale',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_watermark_scale' ),
				'default'           => 20,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_watermark_min_width',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_non_negative_int' ),
				'default'           => 400,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_watermark_target_sizes',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $sanitizer, 'sanitize_watermark_size_list' ),
				'default'           => self::get_default_options()['aiseo_watermark_target_sizes'],
			)
		);

		// -------------------------------------------------------------------
		// ماژول ویرایشگر تصویر (فاز ۶)
		// -------------------------------------------------------------------

		register_setting(
			self::OPTION_GROUP,
			'aiseo_editor_max_history',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_editor_max_history' ),
				'default'           => 10,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_editor_jpeg_quality',
			array(
				'type'              => 'integer',
				'sanitize_callback' => array( $sanitizer, 'sanitize_quality' ),
				'default'           => 90,
			)
		);

		register_setting(
			self::OPTION_GROUP,
			'aiseo_editor_batch_operation',
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $sanitizer, 'sanitize_editor_batch_operation' ),
				'default'           => 'rotate_cw',
			)
		);

		// -------------------------------------------------------------------
		// ماژول مدیریت کتابخانه‌ی رسانه (فاز ۷)
		// -------------------------------------------------------------------
		// aiseo_ml_auto_rebuild_thumbnails در $bool_keys بالا ثبت شده است.
	}

	// -------------------------------------------------------------------
	// Getter های تایپ‌شده برای استفاده‌ی راحت در ماژول‌ها
	// -------------------------------------------------------------------

	public function is_conversion_enabled(): bool {
		return (bool) get_option( 'aiseo_opt_enable_conversion', 1 );
	}

	public function get_output_format(): string {
		$format = get_option( 'aiseo_opt_output_format', 'webp' );
		return in_array( $format, array( 'webp', 'avif' ), true ) ? $format : 'webp';
	}

	public function get_quality(): int {
		return (int) get_option( 'aiseo_opt_quality', 80 );
	}

	public function is_lossless(): bool {
		return (bool) get_option( 'aiseo_opt_lossless', 0 );
	}

	public function is_resize_enabled(): bool {
		return (bool) get_option( 'aiseo_opt_enable_resize', 1 );
	}

	public function get_max_size(): int {
		return (int) get_option( 'aiseo_opt_max_size', 2560 );
	}

	public function get_max_file_size_bytes(): int {
		return (int) get_option( 'aiseo_opt_max_file_size_kb', 0 ) * 1024;
	}

	public function should_strip_metadata(): bool {
		return (bool) get_option( 'aiseo_opt_strip_metadata', 1 );
	}

	public function get_convert_formats(): array {
		$formats = get_option( 'aiseo_opt_convert_formats', array() );
		return is_array( $formats ) ? $formats : array();
	}

	public function should_keep_original_backup(): bool {
		return (bool) get_option( 'aiseo_opt_keep_original_backup', 1 );
	}

	public function get_batch_chunk_size(): int {
		$size = (int) get_option( 'aiseo_opt_batch_chunk_size', 5 );
		return max( 1, min( 50, $size ) );
	}

	public function should_remove_data_on_uninstall(): bool {
		return (bool) get_option( 'aiseo_remove_data_on_uninstall', 0 );
	}

	// -------------------------------------------------------------------
	// ماژول سئو (فاز ۴)
	// -------------------------------------------------------------------

	public function should_auto_generate_on_upload(): bool {
		return (bool) get_option( 'aiseo_seo_auto_generate_on_upload', 1 );
	}

	public function should_overwrite_existing_seo(): bool {
		return (bool) get_option( 'aiseo_seo_overwrite_existing', 0 );
	}

	public function get_seo_alt_template(): string {
		return (string) get_option( 'aiseo_seo_alt_template', '{filename} - {site_name}' );
	}

	public function get_seo_title_template(): string {
		return (string) get_option( 'aiseo_seo_title_template', '{filename}' );
	}

	public function get_seo_caption_template(): string {
		return (string) get_option( 'aiseo_seo_caption_template', '{filename}' );
	}

	public function get_seo_description_template(): string {
		return (string) get_option( 'aiseo_seo_description_template', '{filename} - {parent_title}' );
	}

	// -------------------------------------------------------------------
	// ماژول واترمارک (فاز ۵)
	// -------------------------------------------------------------------

	public function get_watermark_type(): string {
		$type = get_option( 'aiseo_watermark_type', 'text' );
		return in_array( $type, array( 'text', 'image' ), true ) ? $type : 'text';
	}

	public function get_watermark_text(): string {
		return (string) get_option( 'aiseo_watermark_text', '{site_name}' );
	}

	public function get_watermark_text_color(): string {
		return (string) get_option( 'aiseo_watermark_text_color', '#ffffff' );
	}

	public function get_watermark_font_size(): int {
		return (int) get_option( 'aiseo_watermark_font_size', 16 );
	}

	public function get_watermark_image_id(): int {
		return (int) get_option( 'aiseo_watermark_image_id', 0 );
	}

	public function get_watermark_position(): string {
		$position = get_option( 'aiseo_watermark_position', 'bottom-right' );
		$allowed  = array( 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center' );
		return in_array( $position, $allowed, true ) ? $position : 'bottom-right';
	}

	public function get_watermark_opacity(): int {
		return (int) get_option( 'aiseo_watermark_opacity', 60 );
	}

	public function get_watermark_margin(): int {
		return (int) get_option( 'aiseo_watermark_margin', 16 );
	}

	public function get_watermark_scale(): int {
		return (int) get_option( 'aiseo_watermark_scale', 20 );
	}

	public function get_watermark_min_width(): int {
		return (int) get_option( 'aiseo_watermark_min_width', 400 );
	}

	public function should_apply_watermark_on_upload(): bool {
		return (bool) get_option( 'aiseo_watermark_apply_on_upload', 0 );
	}

	public function should_keep_watermark_backup(): bool {
		return (bool) get_option( 'aiseo_watermark_keep_backup', 1 );
	}

	public function get_watermark_target_sizes(): array {
		$sizes = get_option( 'aiseo_watermark_target_sizes', array() );
		return is_array( $sizes ) ? $sizes : array();
	}

	// -------------------------------------------------------------------
	// ماژول ویرایشگر تصویر (فاز ۶)
	// -------------------------------------------------------------------

	/**
	 * حداکثر تعداد مراحل Undo نگه‌داری‌شده برای هر تصویر (نسخه‌ی اصلی جدا و همیشه حفظ می‌شود).
	 */
	public function get_editor_max_history(): int {
		$value = (int) get_option( 'aiseo_editor_max_history', 10 );
		return max( 1, min( 50, $value ) );
	}

	public function get_editor_jpeg_quality(): int {
		return (int) get_option( 'aiseo_editor_jpeg_quality', 90 );
	}

	public function get_editor_batch_operation(): string {
		$value   = (string) get_option( 'aiseo_editor_batch_operation', 'rotate_cw' );
		$allowed = array( 'rotate_cw', 'rotate_ccw', 'rotate_180', 'flip_h', 'flip_v', 'grayscale', 'bw' );
		return in_array( $value, $allowed, true ) ? $value : 'rotate_cw';
	}

	// -------------------------------------------------------------------
	// ماژول مدیریت کتابخانه‌ی رسانه (فاز ۷)
	// -------------------------------------------------------------------

	/**
	 * اگر روشن باشد، وقتی اسکن سلامت کتابخانه سایز گم‌شده‌ای پیدا کند، بلافاصله
	 * تلاش می‌کند آن را از روی فایل اصلی بازسازی کند؛ پیش‌فرض خاموش تا کاربر
	 * آگاهانه این رفتار را فعال کند (طبق اصل کلی افزونه: هیچ تغییری بدون تأیید کاربر).
	 */
	public function should_auto_rebuild_thumbnails(): bool {
		return (bool) get_option( 'aiseo_ml_auto_rebuild_thumbnails', 0 );
	}
}
