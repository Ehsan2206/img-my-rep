<?php
namespace AISEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * هسته‌ی افزونه (Singleton).
 * مسئولیت: بارگذاری زبان، مقداردهی سرویس‌های پایه (Logger, Settings, Capabilities,
 * Server_Capabilities, Queue_Manager) و بوت هر ماژول طبق فعال/غیرفعال بودن آن.
 * هیچ منطق تجاری اینجا نیست؛ فقط orchestration.
 */
final class Plugin {

	/** @var Plugin|null */
	private static $instance = null;

	/** @var Logger */
	public $logger;

	/** @var Settings */
	public $settings;

	/** @var Server_Capabilities */
	public $server_capabilities;

	/** @var Queue_Manager */
	public $queue_manager;

	/** @var Stats_Recorder */
	public $stats_recorder;

	/** @var array<string, object> ماژول‌های بوت‌شده، کلید = نام ماژول */
	private $modules = array();

	private function __construct() {}

	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * اجرای افزونه: باید فقط یک بار روی هوک plugins_loaded فراخوانی شود.
	 */
	public function run(): void {
		( new I18n() )->load();

		// بررسی سبک نسخه‌ی طرح DB روی هر بارگذاری؛ اگر جدولی جا افتاده باشد
		// (مثلاً بعد از آپدیت فایل‌های افزونه بدون غیرفعال/فعال‌سازی مجدد)، اینجا ساخته می‌شود.
		Activator::maybe_upgrade();

		$this->logger              = new Logger();
		$this->settings             = new Settings();
		$this->server_capabilities  = new Server_Capabilities();
		$this->queue_manager        = new Queue_Manager( $this->logger );
		$this->stats_recorder       = new Stats_Recorder();

		// پنل مدیریت فقط در ادمین بارگذاری می‌شود.
		if ( is_admin() ) {
			$admin = new \AISEO\Admin\Admin( $this->settings, $this->logger, $this->server_capabilities, $this->stats_recorder );
			$admin->boot();
		}

		$this->boot_modules();
	}

	/**
	 * بوت هر ماژول طبق تنظیم فعال/غیرفعال بودن آن.
	 * هر ماژول کاملاً خودبسنده است: غیرفعال شدن یک ماژول تأثیری روی بقیه ندارد.
	 */
	private function boot_modules(): void {
		$enabled = $this->settings->get_enabled_modules();

		if ( ! empty( $enabled['optimization'] ) ) {
			try {
				$engine = new Modules\Optimization\Optimization_Engine(
					$this->settings,
					$this->logger,
					$this->server_capabilities,
					$this->queue_manager,
					$this->stats_recorder
				);
				$engine->boot();
				$this->modules['optimization'] = $engine;
			} catch ( \Throwable $e ) {
				$this->logger->error( 'plugin', 'خطا در بوت ماژول بهینه‌سازی: ' . $e->getMessage() );
			}
		}

		// ماژول‌های سئو/واترمارک/ویرایشگر/مدیریت کتابخانه در فازهای ۴ تا ۷ کامل شدند؛
		// هر کدام مستقل بوت می‌شود و خطای یکی مانع بقیه نمی‌شود.
		if ( ! empty( $enabled['seo'] ) && class_exists( Modules\Seo\Seo_Engine::class ) ) {
			try {
				$this->modules['seo'] = new Modules\Seo\Seo_Engine( $this->settings, $this->logger, $this->queue_manager );
				$this->modules['seo']->boot();
			} catch ( \Throwable $e ) {
				$this->logger->error( 'plugin', 'خطا در بوت ماژول سئو: ' . $e->getMessage() );
			}
		}

		if ( ! empty( $enabled['watermark'] ) && class_exists( Modules\Watermark\Watermark_Engine::class ) ) {
			try {
				$this->modules['watermark'] = new Modules\Watermark\Watermark_Engine(
					$this->settings,
					$this->logger,
					$this->server_capabilities,
					$this->queue_manager
				);
				$this->modules['watermark']->boot();
			} catch ( \Throwable $e ) {
				$this->logger->error( 'plugin', 'خطا در بوت ماژول واترمارک: ' . $e->getMessage() );
			}
		}

		if ( ! empty( $enabled['editor'] ) && class_exists( Modules\Editor\Editor_Engine::class ) ) {
			try {
				$this->modules['editor'] = new Modules\Editor\Editor_Engine(
					$this->settings,
					$this->logger,
					$this->server_capabilities,
					$this->queue_manager
				);
				$this->modules['editor']->boot();
			} catch ( \Throwable $e ) {
				$this->logger->error( 'plugin', 'خطا در بوت ماژول ویرایشگر: ' . $e->getMessage() );
			}
		}

		if ( ! empty( $enabled['media_library'] ) && class_exists( Modules\Media_Library\Library_Scanner::class ) ) {
			try {
				$this->modules['media_library'] = new Modules\Media_Library\Library_Scanner(
					$this->settings,
					$this->logger,
					$this->queue_manager
				);
				$this->modules['media_library']->boot();
			} catch ( \Throwable $e ) {
				$this->logger->error( 'plugin', 'خطا در بوت ماژول مدیریت کتابخانه: ' . $e->getMessage() );
			}
		}
	}

	public function get_module( string $name ) {
		return $this->modules[ $name ] ?? null;
	}
}
