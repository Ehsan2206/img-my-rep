<?php
namespace AISEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تشخیص قابلیت‌های واقعی سرور: GD، Imagick، پشتیبانی WebP/AVIF، محدودیت حافظه و زمان اجرا.
 * نتیجه در طول یک request کش می‌شود تا فراخوانی‌های سنگین (queryFormats و ...) تکرار نشوند.
 */
class Server_Capabilities {

	private ?array $cache = null;

	public function detect(): array {
		if ( null !== $this->cache ) {
			return $this->cache;
		}

		$gd_available      = function_exists( 'gd_info' );
		$gd_info            = $gd_available ? gd_info() : array();
		$imagick_available  = class_exists( '\Imagick' );
		$imagick_formats    = array();

		if ( $imagick_available ) {
			try {
				$imagick_formats = ( new \Imagick() )->queryFormats();
			} catch ( \Throwable $e ) {
				$imagick_available = false;
			}
		}

		$this->cache = array(
			'gd' => array(
				'available'  => $gd_available,
				'version'    => $gd_info['GD Version'] ?? null,
				'gif'        => function_exists( 'imagecreatefromgif' ),
				'bmp'        => function_exists( 'imagecreatefrombmp' ),
				'webp'       => function_exists( 'imagewebp' ),
				'avif'       => function_exists( 'imageavif' ),
			),
			'imagick' => array(
				'available' => $imagick_available,
				'svg'       => in_array( 'SVG', $imagick_formats, true ),
				'tiff'      => in_array( 'TIFF', $imagick_formats, true ),
				'avif'      => in_array( 'AVIF', $imagick_formats, true ),
				'webp'      => in_array( 'WEBP', $imagick_formats, true ),
				'gif'       => in_array( 'GIF', $imagick_formats, true ),
			),
			'memory_limit'       => ini_get( 'memory_limit' ),
			'max_execution_time' => ini_get( 'max_execution_time' ),
		);

		return $this->cache;
	}

	public function has_any_converter(): bool {
		$caps = $this->detect();
		return $caps['imagick']['available'] || $caps['gd']['available'];
	}

	/**
	 * انتخاب بهترین استراتژی موجود برای یک mime/format مشخص.
	 * اولویت با Imagick است چون قابلیت‌های بیشتری (SVG، AVIF، GIF متحرک) دارد؛
	 * اگر Imagick قابلیت لازم را نداشت یا نصب نبود، به GD سقوط می‌کنیم.
	 *
	 * @return string 'imagick' | 'gd' | ''
	 */
	public function best_strategy_for( string $mime_type, string $output_format ): string {
		$caps = $this->detect();

		$needs_imagick_only = in_array( $mime_type, array( 'image/svg+xml', 'image/tiff' ), true )
			|| 'avif' === $output_format;

		if ( $caps['imagick']['available'] ) {
			if ( 'avif' === $output_format && ! $caps['imagick']['avif'] ) {
				// Imagick هست اما AVIF را پشتیبانی نمی‌کند؛ اگر GD بتواند AVIF بسازد از آن استفاده کن.
				if ( $caps['gd']['available'] && $caps['gd']['avif'] ) {
					return 'gd';
				}
				return '';
			}
			return 'imagick';
		}

		if ( $needs_imagick_only ) {
			return ''; // این فرمت‌ها بدون Imagick قابل پردازش نیستند.
		}

		if ( $caps['gd']['available'] ) {
			return 'gd';
		}

		return '';
	}
}
