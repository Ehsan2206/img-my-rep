<?php
namespace AISEO\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * عملیات امن روی مسیر فایل. هدف اصلی: جلوگیری از Path Traversal طبق نکات امنیتی فاز ۱.
 * هیچ عملیات فایلی در ماژول‌های دیگر نباید مستقیماً روی مسیر خام کاربر/دیتابیس انجام شود؛
 * همیشه باید از این کلاس عبور کند.
 */
class File_Helper {

	/**
	 * بررسی می‌کند که مسیر داده‌شده واقعاً داخل پوشه‌ی uploads وردپرس است
	 * (جلوگیری از ../../ یا symlink خارج از محدوده‌ی مجاز).
	 */
	public static function is_within_uploads( string $path ): bool {
		$upload_dir = wp_get_upload_dir();
		$real_base  = realpath( $upload_dir['basedir'] );
		$real_path  = realpath( $path );

		if ( false === $real_base || false === $real_path ) {
			return false;
		}

		return 0 === strpos( $real_path, $real_base );
	}

	/**
	 * ساخت مسیر خروجی امن با همان نام پایه اما پسوند جدید، در همان پوشه‌ی فایل اصلی.
	 */
	public static function build_sibling_path( string $original_path, string $new_extension ): string {
		$info      = pathinfo( $original_path );
		$extension = preg_replace( '/[^a-z0-9]/i', '', $new_extension );
		return trailingslashit( $info['dirname'] ) . $info['filename'] . '.' . strtolower( $extension );
	}

	/**
	 * مسیر امن پوشه‌ی بکاپ نسخه‌ی اصلی تصاویر (خارج از مسیر عمومی رسانه، اما داخل uploads).
	 */
	public static function get_backup_dir( int $attachment_id ): string {
		$upload_dir = wp_get_upload_dir();
		$dir        = trailingslashit( $upload_dir['basedir'] ) . 'aiseo-backups/' . absint( $attachment_id ) . '/';

		if ( ! file_exists( $dir ) ) {
			wp_mkdir_p( $dir );
			// جلوگیری از دسترسی مستقیم مرورگر به پوشه‌ی بکاپ
			$htaccess = $dir . '.htaccess';
			if ( ! file_exists( $htaccess ) ) {
				@file_put_contents( $htaccess, "Deny from all\n" );
			}
			$index = $dir . 'index.php';
			if ( ! file_exists( $index ) ) {
				@file_put_contents( $index, "<?php\n// Silence is golden.\n" );
			}
		}

		return $dir;
	}

	/**
	 * جابه‌جایی امن فایل با بررسی مبدا/مقصد داخل uploads بودن.
	 */
	/**
	 * محاسبه‌ی بازگشتی حجم یک پوشه (مثلاً aiseo-backups) برای نمایش در داشبورد آماری.
	 * فقط داخل uploads اجازه دارد اجرا شود، طبق همان اصل جلوگیری از Path Traversal.
	 */
	public static function get_directory_size( string $dir ): int {
		if ( ! is_dir( $dir ) || ! self::is_within_uploads( $dir ) ) {
			return 0;
		}

		$size = 0;

		try {
			$iterator = new \RecursiveIteratorIterator(
				new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
				\RecursiveIteratorIterator::LEAVES_ONLY
			);

			foreach ( $iterator as $file ) {
				if ( $file->isFile() ) {
					$size += $file->getSize();
				}
			}
		} catch ( \Throwable $e ) {
			return $size;
		}

		return $size;
	}

	public static function safe_move( string $from, string $to ): bool {
		if ( ! file_exists( $from ) ) {
			return false;
		}
		if ( ! self::is_within_uploads( $from ) ) {
			return false;
		}

		$dest_dir = dirname( $to );
		if ( ! file_exists( $dest_dir ) ) {
			wp_mkdir_p( $dest_dir );
		}

		if ( ! self::is_within_uploads( $dest_dir ) ) {
			return false;
		}

		return @rename( $from, $to );
	}
}
