<?php
namespace AISEO\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * نقطه‌ی مرکزی sanitize/validate برای همه‌ی ورودی‌های افزونه.
 * هدف: یک منبع واحد حقیقت برای قوانین اعتبارسنجی، به‌جای پخش‌شدن منطق در فرم‌ها.
 */
class Sanitizer {

	public function sanitize_bool( $value ): int {
		return ! empty( $value ) ? 1 : 0;
	}

	public function sanitize_output_format( $value ): string {
		$value = is_string( $value ) ? strtolower( trim( $value ) ) : '';
		return in_array( $value, array( 'webp', 'avif' ), true ) ? $value : 'webp';
	}

	public function sanitize_quality( $value ): int {
		$value = (int) $value;
		return max( 1, min( 100, $value ) );
	}

	public function sanitize_positive_int( $value ): int {
		$value = (int) $value;
		return max( 1, $value );
	}

	public function sanitize_non_negative_int( $value ): int {
		$value = (int) $value;
		return max( 0, $value );
	}

	public function sanitize_batch_chunk( $value ): int {
		$value = (int) $value;
		return max( 1, min( 50, $value ) );
	}

	public function sanitize_format_list( $value ): array {
		$allowed = array( 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'svg', 'avif' );
		$clean   = array();

		if ( ! is_array( $value ) ) {
			$value = array();
		}

		foreach ( $allowed as $key ) {
			$clean[ $key ] = ! empty( $value[ $key ] ) ? 1 : 0;
		}

		return $clean;
	}

	/**
	 * اعتبارسنجی شناسه‌ی attachment وردپرس.
	 */
	public function sanitize_attachment_id( $value ): int {
		$id = absint( $value );
		return $id > 0 ? $id : 0;
	}

	/**
	 * پاک‌سازی متن آزاد ورودی (برای فیلدهای متنی آینده مثل قوانین متادیتا).
	 */
	public function sanitize_text( $value ): string {
		return sanitize_text_field( (string) $value );
	}

	/**
	 * پاک‌سازی قالب‌های متنی سئو (مثل "{filename} - {site_name}").
	 * آکولاد {} برای placeholder ها مجاز است؛ بقیه از طریق sanitize_text_field تمیز می‌شود.
	 */
	public function sanitize_template( $value ): string {
		$value = sanitize_text_field( (string) $value );
		return substr( $value, 0, 200 );
	}

	// -------------------------------------------------------------------
	// ماژول واترمارک (فاز ۵)
	// -------------------------------------------------------------------

	public function sanitize_watermark_type( $value ): string {
		$value = is_string( $value ) ? strtolower( trim( $value ) ) : '';
		return in_array( $value, array( 'text', 'image' ), true ) ? $value : 'text';
	}

	/**
	 * از تابع هسته‌ی وردپرس sanitize_hex_color() استفاده می‌کند؛ اگر ورودی نامعتبر بود
	 * (خروجی خالی)، به رنگ پیش‌فرض سفید بازمی‌گردیم تا هیچ‌وقت option خالی ذخیره نشود.
	 */
	public function sanitize_hex_color( $value ): string {
		$clean = sanitize_hex_color( (string) $value );
		return $clean ? $clean : '#ffffff';
	}

	public function sanitize_watermark_font_size( $value ): int {
		$value = (int) $value;
		return max( 8, min( 96, $value ) );
	}

	public function sanitize_watermark_position( $value ): string {
		$allowed = array( 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center' );
		$value   = is_string( $value ) ? strtolower( trim( $value ) ) : '';
		return in_array( $value, $allowed, true ) ? $value : 'bottom-right';
	}

	public function sanitize_percentage( $value ): int {
		$value = (int) $value;
		return max( 0, min( 100, $value ) );
	}

	public function sanitize_watermark_scale( $value ): int {
		$value = (int) $value;
		return max( 5, min( 100, $value ) );
	}

	/**
	 * لیست سایزهای هدف واترمارک (checkbox ها). طبق ریسک‌های فنی سند معماری، سایزهای
	 * غیرمتعارف (thumbnail خیلی کوچک) به‌عمد در پیش‌فرض خاموش‌اند، نه اینجا حذف می‌شوند؛
	 * کاربر می‌تواند صریحاً روشن کند.
	 */
	public function sanitize_watermark_size_list( $value ): array {
		$allowed = array( 'full', 'large', 'medium', 'thumbnail' );
		$clean   = array();

		if ( ! is_array( $value ) ) {
			$value = array();
		}

		foreach ( $allowed as $key ) {
			$clean[ $key ] = ! empty( $value[ $key ] ) ? 1 : 0;
		}

		return $clean;
	}

	// -------------------------------------------------------------------
	// ماژول ویرایشگر تصویر (فاز ۶)
	// -------------------------------------------------------------------

	public function sanitize_editor_max_history( $value ): int {
		$value = (int) $value;
		return max( 1, min( 50, $value ) );
	}

	public function sanitize_editor_batch_operation( $value ): string {
		$allowed = array( 'rotate_cw', 'rotate_ccw', 'rotate_180', 'flip_h', 'flip_v', 'grayscale', 'bw' );
		$value   = is_string( $value ) ? strtolower( trim( $value ) ) : '';
		return in_array( $value, $allowed, true ) ? $value : 'rotate_cw';
	}
}
