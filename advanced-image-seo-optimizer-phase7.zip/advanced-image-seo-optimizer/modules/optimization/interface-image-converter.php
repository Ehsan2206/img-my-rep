<?php
namespace AISEO\Modules\Optimization;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * قرارداد مشترک هر پیاده‌سازی تبدیل تصویر (Strategy Pattern).
 * پیاده‌سازی‌های فعلی: Converter_GD و Converter_Imagick.
 */
interface Image_Converter_Interface {

	/**
	 * تبدیل یک فایل تصویر به فرمت خروجی مشخص.
	 *
	 * @param string $file_path مسیر مطلق فایل مبدا (باید قبلاً validate شده باشد).
	 * @param string $mime_type نوع MIME تشخیص داده‌شده‌ی فایل مبدا.
	 * @param array  $args {
	 *     @type string $output_format   'webp' یا 'avif'
	 *     @type int    $quality         0-100
	 *     @type bool   $lossless
	 *     @type bool   $enable_resize
	 *     @type int    $max_size        بزرگ‌ترین ضلع مجاز به پیکسل
	 *     @type bool   $strip_metadata
	 *     @type int    $max_file_size_bytes  0 = بدون محدودیت
	 * }
	 * @return string|\WP_Error مسیر مطلق فایل خروجی یا WP_Error در صورت خطا.
	 */
	public function convert( string $file_path, string $mime_type, array $args );

	/**
	 * آیا این استراتژی از این mime type پشتیبانی می‌کند؟
	 */
	public function supports( string $mime_type ): bool;
}
