<?php
namespace AISEO\Modules\Optimization;

use AISEO\Settings;
use AISEO\Logger;
use AISEO\Server_Capabilities;
use AISEO\Queue_Manager;
use AISEO\Stats_Recorder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * نقطه‌ی ورود ماژول بهینه‌سازی. مسئولیت: ساخت و سیم‌کشی (wiring) همه‌ی سرویس‌های
 * داخلی ماژول (Converter، Backup، Conversion_Service، Upload_Handler، Batch_Processor)
 * و ثبت هوک‌ها در متد boot(). طبق اصل معماری «هر ماژول خودبسنده».
 */
class Optimization_Engine {

	private Settings $settings;
	private Logger $logger;
	private Server_Capabilities $server_capabilities;
	private Queue_Manager $queue_manager;
	private Stats_Recorder $stats_recorder;

	private Image_Converter $converter;
	private Backup_Manager $backup_manager;
	private Conversion_Service $conversion_service;
	private Upload_Handler $upload_handler;
	private Batch_Processor $batch_processor;

	public function __construct( Settings $settings, Logger $logger, Server_Capabilities $server_capabilities, Queue_Manager $queue_manager, Stats_Recorder $stats_recorder ) {
		$this->settings            = $settings;
		$this->logger               = $logger;
		$this->server_capabilities  = $server_capabilities;
		$this->queue_manager        = $queue_manager;
		$this->stats_recorder       = $stats_recorder;

		$this->converter          = new Image_Converter( $server_capabilities );
		$this->backup_manager     = new Backup_Manager( $logger );
		$this->conversion_service = new Conversion_Service( $settings, $logger, $this->converter, $this->backup_manager, $stats_recorder );
		$this->upload_handler     = new Upload_Handler( $settings, $logger, $this->conversion_service );
		$this->batch_processor    = new Batch_Processor( $queue_manager, $settings, $logger, $this->conversion_service );
	}

	public function boot(): void {
		if ( ! $this->server_capabilities->has_any_converter() ) {
			add_action( 'admin_notices', array( $this, 'render_missing_library_notice' ) );
			$this->logger->warning( 'optimization', 'نه GD و نه Imagick روی این سرور در دسترس نیست؛ ماژول بهینه‌سازی غیرفعال است.' );
			return;
		}

		$this->upload_handler->register();
	}

	public function render_missing_library_notice(): void {
		echo '<div class="notice notice-error"><p>' .
			esc_html__( 'برای فعالیت ماژول بهینه‌سازی تصویر، حداقل یکی از کتابخانه‌های GD یا Imagick باید روی سرور نصب باشد.', 'advanced-image-seo-optimizer' ) .
			'</p></div>';
	}

	public function get_batch_processor(): Batch_Processor {
		return $this->batch_processor;
	}

	public function get_conversion_service(): Conversion_Service {
		return $this->conversion_service;
	}

	public function get_stats_recorder(): Stats_Recorder {
		return $this->stats_recorder;
	}
}
