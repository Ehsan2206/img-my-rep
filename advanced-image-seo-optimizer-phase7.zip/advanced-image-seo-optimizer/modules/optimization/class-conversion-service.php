<?php
namespace AISEO\Modules\Optimization;

use AISEO\Settings;
use AISEO\Logger;
use AISEO\Stats_Recorder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * منطق مشترک تبدیل یک attachment، مستقل از این‌که از کجا فراخوانی می‌شود
 * (هوک آپلود جدید یا پردازش دسته‌ای تصاویر قدیمی). طبق اصل «پرهیز از کد تکراری».
 */
class Conversion_Service {

	private Settings $settings;
	private Logger $logger;
	private Image_Converter $converter;
	private Backup_Manager $backup_manager;
	private Stats_Recorder $stats_recorder;

	private const FORMAT_MAP = array(
		'image/jpeg'    => 'jpeg',
		'image/png'     => 'png',
		'image/gif'     => 'gif',
		'image/bmp'     => 'bmp',
		'image/tiff'    => 'tiff',
		'image/svg+xml' => 'svg',
		'image/avif'    => 'avif',
	);

	public function __construct( Settings $settings, Logger $logger, Image_Converter $converter, Backup_Manager $backup_manager, Stats_Recorder $stats_recorder ) {
		$this->settings       = $settings;
		$this->logger         = $logger;
		$this->converter      = $converter;
		$this->backup_manager = $backup_manager;
		$this->stats_recorder = $stats_recorder;
	}

	/**
	 * @return array{status:string, output_path:?string, error:?\WP_Error, bytes_before:int, bytes_after:int}
	 *         status یکی از: 'converted' | 'skipped' | 'error'.
	 *         bytes_before/bytes_after فقط برای status = 'converted' مقدار واقعی دارند؛ در غیر این صورت صفر است.
	 */
	public function convert_attachment( int $attachment_id ): array {
		$file_path = get_attached_file( $attachment_id );

		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return $this->skip( 'فایل روی دیسک یافت نشد.' );
		}

		$mime_type = mime_content_type( $file_path );
		if ( ! $mime_type || ! isset( self::FORMAT_MAP[ $mime_type ] ) ) {
			return $this->skip( 'نوع فایل پشتیبانی نمی‌شود.' );
		}

		$output_format = $this->resolve_output_format( $mime_type );

		if ( 'image/' . $output_format === $mime_type ) {
			return $this->skip( 'فایل از قبل در فرمت مقصد است.' );
		}

		if ( ! $this->format_enabled_for_mime( $mime_type ) ) {
			return $this->skip( 'این فرمت در تنظیمات غیرفعال است.' );
		}

		// اندازه‌ی فایل اصلی پیش از تبدیل، برای محاسبه‌ی «حجم کاهش‌یافته» در گزارش.
		$bytes_before = (int) filesize( $file_path );

		$result = $this->converter->convert(
			$file_path,
			$mime_type,
			array(
				'output_format'       => $output_format,
				'quality'             => $this->settings->get_quality(),
				'lossless'            => $this->settings->is_lossless(),
				'enable_resize'       => $this->settings->is_resize_enabled(),
				'max_size'            => $this->settings->get_max_size(),
				'strip_metadata'      => $this->settings->should_strip_metadata(),
				'max_file_size_bytes' => $this->settings->get_max_file_size_bytes(),
			)
		);

		if ( is_wp_error( $result ) ) {
			$this->logger->error( 'optimization', "تبدیل ناموفق برای attachment #{$attachment_id}: " . $result->get_error_message() );
			return array(
				'status'       => 'error',
				'output_path'  => null,
				'error'        => $result,
				'bytes_before' => 0,
				'bytes_after'  => 0,
			);
		}

		$output_path = $result;

		$this->backup_manager->handle_original( $attachment_id, $file_path, $this->settings->should_keep_original_backup() );

		$upload_dir           = wp_get_upload_dir();
		$relative_output_path = str_replace( trailingslashit( $upload_dir['basedir'] ), '', $output_path );

		update_attached_file( $attachment_id, $relative_output_path );

		wp_update_post(
			array(
				'ID'             => $attachment_id,
				'post_mime_type' => 'image/' . $output_format,
			)
		);

		// regenerate metadata/thumbnails برای فایل جدید. remove_filter موقت جلوی بازگشت
		// این متد از داخل هوک wp_generate_attachment_metadata را می‌گیرد (برای فراخوانی از Batch_Processor بی‌خطر است،
		// و Upload_Handler خودش قبل از فراخوانی این سرویس محافظ mime را بررسی کرده).
		$metadata = wp_generate_attachment_metadata( $attachment_id, $output_path );
		wp_update_attachment_metadata( $attachment_id, $metadata );

		$bytes_after = file_exists( $output_path ) ? (int) filesize( $output_path ) : 0;

		if ( $bytes_after > 0 ) {
			$this->stats_recorder->record_conversion( $bytes_before, $bytes_after );
		}

		$this->logger->info( 'optimization', "attachment #{$attachment_id} با موفقیت به {$output_format} تبدیل شد." );

		return array(
			'status'       => 'converted',
			'output_path'  => $output_path,
			'error'        => null,
			'bytes_before' => $bytes_before,
			'bytes_after'  => $bytes_after,
		);
	}

	public function resolve_output_format( string $mime_type ): string {
		if ( 'image/gif' === $mime_type ) {
			return 'webp';
		}
		return $this->settings->get_output_format();
	}

	public function format_enabled_for_mime( string $mime_type ): bool {
		if ( ! isset( self::FORMAT_MAP[ $mime_type ] ) ) {
			return false;
		}
		$formats = $this->settings->get_convert_formats();
		return ! empty( $formats[ self::FORMAT_MAP[ $mime_type ] ] );
	}

	public static function get_eligible_mime_types(): array {
		return array_keys( self::FORMAT_MAP );
	}

	private function skip( string $reason ): array {
		return array(
			'status'       => 'skipped',
			'output_path'  => null,
			'error'        => null,
			'reason'       => $reason,
			'bytes_before' => 0,
			'bytes_after'  => 0,
		);
	}
}
