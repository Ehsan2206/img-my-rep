<?php
namespace AISEO\Modules\Optimization;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پیاده‌سازی تبدیل تصویر با کتابخانه‌ی Imagick.
 * برگرفته و بازنویسی‌شده از منطق تبدیل افزونه‌ی قبلی webp-converter.php.
 * برخلاف GD، از SVG، TIFF و GIF متحرک (با حفظ انیمیشن) پشتیبانی می‌کند.
 */
class Converter_Imagick implements Image_Converter_Interface {

	private const SUPPORTED_MIMES = array(
		'image/jpeg'    => true,
		'image/png'     => true,
		'image/gif'     => true,
		'image/bmp'     => true,
		'image/tiff'    => true,
		'image/svg+xml' => true,
		'image/avif'    => true,
	);

	public function supports( string $mime_type ): bool {
		return class_exists( '\Imagick' ) && isset( self::SUPPORTED_MIMES[ $mime_type ] );
	}

	public function convert( string $file_path, string $mime_type, array $args ) {
		if ( ! $this->supports( $mime_type ) ) {
			return new \WP_Error( 'aiseo_unsupported_mime', 'نوع فایل توسط Imagick پشتیبانی نمی‌شود: ' . $mime_type );
		}

		$output_format  = $args['output_format'] ?? 'webp';
		$quality        = max( 0, min( 100, (int) ( $args['quality'] ?? 80 ) ) );
		$lossless       = ! empty( $args['lossless'] );
		$enable_resize  = ! empty( $args['enable_resize'] );
		$max_size       = (int) ( $args['max_size'] ?? 0 );
		$strip_metadata = ! empty( $args['strip_metadata'] );
		$max_bytes      = (int) ( $args['max_file_size_bytes'] ?? 0 );

		$image_info  = @getimagesize( $file_path );
		$orig_width  = $image_info ? (int) $image_info[0] : 0;
		$orig_height = $image_info ? (int) $image_info[1] : 0;

		list( $new_width, $new_height ) = $this->calculate_dimensions( $orig_width, $orig_height, $enable_resize, $max_size );

		$output_path = \AISEO\Helpers\File_Helper::build_sibling_path( $file_path, $output_format );

		try {
			$image = new \Imagick();

			// برای SVG باید رزولوشن و رنگ پس‌زمینه *قبل* از readImage() تنظیم شوند،
			// چون رندر وکتور به بیت‌مپ همان لحظه‌ی خواندن فایل انجام می‌شود.
			if ( 'image/svg+xml' === $mime_type ) {
				$image->setBackgroundColor( new \ImagickPixel( 'transparent' ) );
				$image->setResolution( 150, 150 );
			}

			$image->readImage( $file_path );

			$is_animated_gif = ( 'image/gif' === $mime_type && $image->getNumberImages() > 1 );

			if ( $is_animated_gif ) {
				$this->convert_animated_gif( $image, $output_path, $output_format, $quality, $lossless, $enable_resize, $new_width, $new_height, $strip_metadata );
			} else {
				$this->convert_static_image( $image, $mime_type, $output_path, $output_format, $quality, $lossless, $enable_resize, $new_width, $new_height, $strip_metadata );
			}

			$image->clear();
			$image->destroy();
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'aiseo_imagick_failed', 'پردازش Imagick شکست خورد: ' . $e->getMessage() );
		}

		if ( ! file_exists( $output_path ) ) {
			return new \WP_Error( 'aiseo_write_failed', 'فایل خروجی Imagick ساخته نشد.' );
		}

		if ( $max_bytes > 0 && filesize( $output_path ) > $max_bytes ) {
			@unlink( $output_path );
			return new \WP_Error( 'aiseo_exceeds_max_size', 'حجم فایل خروجی از سقف مجاز بیشتر شد.' );
		}

		return $output_path;
	}

	private function convert_animated_gif( \Imagick $image, string $output_path, string $output_format, int $quality, bool $lossless, bool $enable_resize, int $new_width, int $new_height, bool $strip_metadata ): void {
		$image = $image->coalesceImages();
		$image->setFormat( $output_format );
		$image->setOption( $output_format . ':quality', (string) $quality );
		$image->setOption( $output_format . ':lossless', $lossless ? 'true' : 'false' );

		if ( $enable_resize && $new_width > 0 && $new_height > 0 ) {
			foreach ( $image as $frame ) {
				$frame->resizeImage( $new_width, $new_height, \Imagick::FILTER_LANCZOS, 1 );
			}
		}

		if ( $strip_metadata ) {
			foreach ( $image as $frame ) {
				$frame->stripImage();
			}
		}

		$image->writeImages( $output_path, true );
	}

	private function convert_static_image( \Imagick $image, string $mime_type, string $output_path, string $output_format, int $quality, bool $lossless, bool $enable_resize, int $new_width, int $new_height, bool $strip_metadata ): void {
		$image->setImageFormat( $output_format );

		if ( 'avif' === $output_format ) {
			$image->setOption( 'avif:lossless', $lossless ? 'true' : 'false' );
			$image->setOption( 'avif:quality', (string) $quality );
		} else {
			$image->setOption( 'webp:lossless', $lossless ? 'true' : 'false' );
			$image->setOption( 'webp:quality', (string) $quality );
		}

		if ( $enable_resize && $new_width > 0 && $new_height > 0 ) {
			$image->resizeImage( $new_width, $new_height, \Imagick::FILTER_LANCZOS, 1 );
		}

		if ( $strip_metadata ) {
			$image->stripImage();
		}

		$image->writeImage( $output_path );
	}

	private function calculate_dimensions( int $orig_width, int $orig_height, bool $enable_resize, int $max_size ): array {
		if ( ! $enable_resize || $max_size <= 0 || $orig_width <= 0 || $orig_height <= 0 ) {
			return array( $orig_width, $orig_height );
		}

		if ( $orig_width <= $max_size && $orig_height <= $max_size ) {
			return array( $orig_width, $orig_height );
		}

		$ratio = $orig_width / $orig_height;
		if ( $ratio > 1 ) {
			$new_width  = $max_size;
			$new_height = (int) round( $max_size / $ratio );
		} else {
			$new_height = $max_size;
			$new_width  = (int) round( $max_size * $ratio );
		}

		return array( $new_width, $new_height );
	}
}
