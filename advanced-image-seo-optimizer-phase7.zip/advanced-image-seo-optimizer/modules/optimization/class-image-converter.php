<?php
namespace AISEO\Modules\Optimization;

use AISEO\Server_Capabilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاس Context الگوی Strategy: بین Converter_GD و Converter_Imagick
 * بر اساس قابلیت‌های واقعی سرور (Server_Capabilities) و نوع فایل انتخاب می‌کند.
 * ماژول‌های دیگر فقط با همین کلاس کار می‌کنند و از جزئیات GD/Imagick بی‌خبرند.
 */
class Image_Converter {

	private Server_Capabilities $server_capabilities;
	private array $strategies = array();

	public function __construct( Server_Capabilities $server_capabilities ) {
		$this->server_capabilities = $server_capabilities;
		$this->strategies          = array(
			'imagick' => new Converter_Imagick(),
			'gd'      => new Converter_GD(),
		);
	}

	/**
	 * @return string|\WP_Error
	 */
	public function convert( string $file_path, string $mime_type, array $args ) {
		$output_format = $args['output_format'] ?? 'webp';

		// GIF متحرک همیشه به Imagick نیاز دارد تا انیمیشن حفظ شود؛ در غیر این صورت GD فقط فریم اول را نگه می‌دارد.
		if ( 'image/gif' === $mime_type && $this->is_animated_gif( $file_path ) && $this->strategies['imagick']->supports( $mime_type ) ) {
			$strategy_name = 'imagick';
		} else {
			$strategy_name = $this->server_capabilities->best_strategy_for( $mime_type, $output_format );
		}

		if ( '' === $strategy_name || ! isset( $this->strategies[ $strategy_name ] ) ) {
			return new \WP_Error(
				'aiseo_no_strategy',
				sprintf(
					/* translators: %1$s mime type, %2$s output format */
					__( 'هیچ کتابخانه‌ی تصویری مناسبی برای تبدیل %1$s به %2$s روی این سرور یافت نشد.', 'advanced-image-seo-optimizer' ),
					$mime_type,
					strtoupper( $output_format )
				)
			);
		}

		return $this->strategies[ $strategy_name ]->convert( $file_path, $mime_type, $args );
	}

	private function is_animated_gif( string $file_path ): bool {
		$contents = @file_get_contents( $file_path, false, null, 0, 1_000_000 );
		if ( false === $contents ) {
			return false;
		}
		// شمارش تعداد بلوک‌های تصویر GIF؛ بیش از یکی یعنی انیمیشن است.
		return preg_match_all( '/\x00\x21\xF9\x04.{4}\x00[\x2C\x21]/s', $contents ) > 1;
	}
}
