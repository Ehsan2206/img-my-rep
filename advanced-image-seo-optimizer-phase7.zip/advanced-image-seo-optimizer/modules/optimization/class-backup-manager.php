<?php
namespace AISEO\Modules\Optimization;

use AISEO\Logger;
use AISEO\Helpers\File_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * مدیریت نسخه‌ی اصلی فایل قبل از تبدیل.
 *
 * تفاوت مهم با افزونه‌ی قبلی webp-converter.php:
 * آن نسخه فایل اصلی را بلافاصله با unlink() حذف می‌کرد. طبق تصمیم معماری فاز ۱
 * («Non-destructive editing») و نیازمندی صریح محصول («عدم حذف ناخواسته فایل اصلی»)،
 * این کلاس به‌جای حذف، فایل اصلی را به پوشه‌ی محافظت‌شده‌ی aiseo-backups منتقل می‌کند
 * و امکان بازگردانی کامل را فراهم می‌کند. حذف قطعی فقط وقتی کاربر صراحتاً
 * گزینه‌ی «حفظ نسخه‌ی اصلی» را خاموش کرده باشد رخ می‌دهد.
 */
class Backup_Manager {

	private const META_KEY = '_aiseo_original_backup';

	private Logger $logger;

	public function __construct( Logger $logger ) {
		$this->logger = $logger;
	}

	/**
	 * قبل از جایگزینی فایل attachment، نسخه‌ی اصلی را طبق تنظیمات کاربر نگه می‌دارد یا حذف می‌کند.
	 */
	public function handle_original( int $attachment_id, string $original_path, bool $keep_backup ): void {
		if ( ! $keep_backup ) {
			if ( file_exists( $original_path ) ) {
				@unlink( $original_path );
				$this->logger->info( 'optimization', "فایل اصلی حذف شد (بکاپ غیرفعال بود): {$original_path}" );
			}
			return;
		}

		$backup_dir  = File_Helper::get_backup_dir( $attachment_id );
		$backup_path = $backup_dir . basename( $original_path );

		if ( File_Helper::safe_move( $original_path, $backup_path ) ) {
			update_post_meta( $attachment_id, self::META_KEY, $backup_path );
			$this->logger->info( 'optimization', "نسخه‌ی اصلی نگه‌داری شد: {$backup_path}" );
		} else {
			$this->logger->warning( 'optimization', "انتقال فایل اصلی به بکاپ ناموفق بود: {$original_path}" );
		}
	}

	public function has_backup( int $attachment_id ): bool {
		$path = get_post_meta( $attachment_id, self::META_KEY, true );
		return ! empty( $path ) && file_exists( $path );
	}

	public function get_backup_path( int $attachment_id ): string {
		$path = get_post_meta( $attachment_id, self::META_KEY, true );
		return is_string( $path ) ? $path : '';
	}

	/**
	 * بازگردانی فایل اصلی به‌عنوان فایل فعال attachment.
	 * فراخوانی wp_generate_attachment_metadata و به‌روزرسانی mime type بر عهده‌ی فراخواننده است
	 * (معمولاً Batch_Processor یا اکشن ادمین)، چون به context متفاوتی نیاز دارد.
	 */
	public function restore( int $attachment_id ): bool {
		$backup_path = $this->get_backup_path( $attachment_id );
		if ( '' === $backup_path || ! file_exists( $backup_path ) ) {
			return false;
		}

		$current_file = get_attached_file( $attachment_id );
		$upload_dir   = wp_get_upload_dir();
		$restore_to   = trailingslashit( dirname( $current_file ) ) . basename( $backup_path );

		if ( ! copy( $backup_path, $restore_to ) ) {
			return false;
		}

		update_attached_file( $attachment_id, str_replace( trailingslashit( $upload_dir['basedir'] ), '', $restore_to ) );
		delete_post_meta( $attachment_id, self::META_KEY );

		$this->logger->info( 'optimization', "نسخه‌ی اصلی attachment #{$attachment_id} بازگردانی شد." );

		return true;
	}
}
