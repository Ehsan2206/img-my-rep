<?php
namespace AISEO\Modules\Optimization;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پیاده‌سازی تبدیل تصویر با کتابخانه‌ی GD.
 * برگرفته و بازنویسی‌شده از منطق تبدیل افزونه‌ی قبلی webp-converter.php،
 * اما بدون حذف فایل مبدا (Backup_Manager این کار را جداگانه و به‌صورت non-destructive انجام می‌دهد).
 * GD انیمیشن GIF یا SVG/TIFF را پشتیبانی نمی‌کند؛ برای این‌ها Converter_Imagick لازم است.
 */
class Converter_GD implements Image_Converter_Interface {

	private const SUPPORTED_MIMES = array(
		'image/jpeg' => 'imagecreatefromjpeg',
		'image/png'  => 'imagecreatefrompng',
		'image/gif'  => 'imagecreatefromgif',
		'image/bmp'  => 'imagecreatefrombmp',
	);

	public function supports( string $mime_type ): bool {
		if ( ! array_key_exists( $mime_type, self::SUPPORTED_MIMES ) ) {
			return false;
		}
		return function_exists( self::SUPPORTED_MIMES[ $mime_type ] );
	}

	public function convert( string $file_path, string $mime_type, array $args ) {
		if ( ! $this->supports( $mime_type ) ) {
			return new \WP_Error( 'aiseo_unsupported_mime', 'نوع فایل توسط GD پشتیبانی نمی‌شود: ' . $mime_type );
		}

		$output_format = $args['output_format'] ?? 'webp';

		if ( 'webp' === $output_format && ! function_exists( 'imagewebp' ) ) {
			return new \WP_Error( 'aiseo_no_webp_support', 'GD نصب‌شده روی این سرور از خروجی WebP پشتیبانی نمی‌کند.' );
		}
		if ( 'avif' === $output_format && ! function_exists( 'imageavif' ) ) {
			return new \WP_Error( 'aiseo_no_avif_support', 'GD نصب‌شده روی این سرور از خروجی AVIF پشتیبانی نمی‌کند.' );
		}

		$image_info = @getimagesize( $file_path );
		if ( ! $image_info ) {
			return new \WP_Error( 'aiseo_read_failed', 'خواندن اطلاعات تصویر ممکن نشد: ' . basename( $file_path ) );
		}

		[ $orig_width, $orig_height ] = $image_info;

		$loader = self::SUPPORTED_MIMES[ $mime_type ];
		$image  = @$loader( $file_path );

		if ( false === $image ) {
			return new \WP_Error( 'aiseo_load_failed', 'بارگذاری تصویر با GD شکست خورد: ' . basename( $file_path ) );
		}

		// GIF متحرک با GD فقط به‌صورت فریم اول (استاتیک) تبدیل می‌شود؛ این یک محدودیت شناخته‌شده‌ی GD است.
		if ( 'image/gif' === $mime_type ) {
			// اگر Imagick موجود بود، Server_Capabilities باید از قبل آن را برای GIF انتخاب کرده باشد.
			// اینجا فقط برای اطمینان لاگ می‌شود، منطق انتخاب استراتژی در Image_Converter (context) است.
		}

		list( $new_width, $new_height ) = $this->calculate_dimensions(
			$orig_width,
			$orig_height,
			! empty( $args['enable_resize'] ),
			(int) ( $args['max_size'] ?? 0 )
		);

		if ( ( $new_width !== $orig_width || $new_height !== $orig_height ) && $new_width > 0 && $new_height > 0 ) {
			$resized = imagescale( $image, $new_width, $new_height );
			if ( $resized ) {
				imagedestroy( $image );
				$image = $resized;
			}
		}

		// حفظ شفافیت PNG/GIF هنگام تبدیل
		imagepalettetotruecolor( $image );
		imagealphablending( $image, true );
		imagesavealpha( $image, true );

		$output_path = \AISEO\Helpers\File_Helper::build_sibling_path( $file_path, $output_format );
		$quality     = max( 0, min( 100, (int) ( $args['quality'] ?? 80 ) ) );

		$write_ok = false;
		if ( 'avif' === $output_format ) {
			// امضای imageavif: (image, file, quality, speed) - quality در بازه‌ی 0-100
			$write_ok = imageavif( $image, $output_path, $quality );
		} else {
			$write_ok = imagewebp( $image, $output_path, $quality );
		}

		imagedestroy( $image );

		if ( ! $write_ok || ! file_exists( $output_path ) ) {
			return new \WP_Error( 'aiseo_write_failed', 'نوشتن فایل خروجی با GD شکست خورد.' );
		}

		$max_bytes = (int) ( $args['max_file_size_bytes'] ?? 0 );
		if ( $max_bytes > 0 && filesize( $output_path ) > $max_bytes ) {
			@unlink( $output_path );
			return new \WP_Error( 'aiseo_exceeds_max_size', 'حجم فایل خروجی از سقف مجاز بیشتر شد.' );
		}

		// توجه: GD متادیتا (EXIF) را در خروجی WebP/AVIF درج نمی‌کند؛ گزینه‌ی strip_metadata
		// برای GD همیشه عملاً برقرار است.
		return $output_path;
	}

	private function calculate_dimensions( int $orig_width, int $orig_height, bool $enable_resize, int $max_size ): array {
		if ( ! $enable_resize || $max_size <= 0 || ( $orig_width <= $max_size && $orig_height <= $max_size ) ) {
			return array( $orig_width, $orig_height );
		}

		if ( $orig_width <= 0 || $orig_height <= 0 ) {
			return array( $orig_width, $orig_height );
		}

		$ratio = $orig_width / $orig_height;
		if ( $ratio > 1 ) {
			$new_width  = $max_size;
			$new_height = (int) round( $max_size / $ratio );
		} else {
			$new_height = $max_size;
			$new_width  = (int) round( $max_size * $ratio );
		}

		return array( $new_width, $new_height );
	}
}
