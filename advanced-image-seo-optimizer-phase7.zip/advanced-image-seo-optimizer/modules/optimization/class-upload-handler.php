<?php
namespace AISEO\Modules\Optimization;

use AISEO\Settings;
use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * قلاب روی آپلود جدید (wp_generate_attachment_metadata).
 * منطق اصلی از webp_converter_convert_new_images() در webp-converter.php گرفته شده،
 * اما منطق تبدیل به Conversion_Service مشترک منتقل شده تا با Batch_Processor تکراری نباشد.
 */
class Upload_Handler {

	private Settings $settings;
	private Logger $logger;
	private Conversion_Service $conversion_service;

	public function __construct( Settings $settings, Logger $logger, Conversion_Service $conversion_service ) {
		$this->settings           = $settings;
		$this->logger             = $logger;
		$this->conversion_service = $conversion_service;
	}

	public function register(): void {
		add_filter( 'wp_generate_attachment_metadata', array( $this, 'maybe_convert' ), 10, 2 );
		add_filter( 'upload_mimes', array( $this, 'register_mime_types' ) );
	}

	/**
	 * افزودن پسوندهای موردنیاز به لیست mime مجاز وردپرس.
	 * توجه امنیتی: افزودن SVG به upload_mimes ریسک شناخته‌شده‌ی XSS دارد؛ وردپرس همچنان
	 * بررسی امضای واقعی فایل را انجام می‌دهد و آپلود انواع فایل حساس به‌طور پیش‌فرض به مدیران محدود است.
	 */
	public function register_mime_types( array $mimes ): array {
		$mimes['webp'] = 'image/webp';
		$mimes['avif'] = 'image/avif';
		$mimes['bmp']  = 'image/bmp';
		$mimes['tiff'] = 'image/tiff';
		$mimes['tif']  = 'image/tiff';
		return $mimes;
	}

	/**
	 * @param array $metadata
	 * @param int   $attachment_id
	 * @return array
	 */
	public function maybe_convert( $metadata, $attachment_id ) {
		if ( ! $this->settings->is_conversion_enabled() ) {
			return $metadata;
		}

		$attachment_id = (int) $attachment_id;

		// محافظ بازگشت بی‌نهایت: Conversion_Service در پایان یک تبدیل موفق دوباره
		// wp_generate_attachment_metadata را برای ساخت thumbnail های جدید صدا می‌زند،
		// که همین هوک را دوباره فعال می‌کند. در دور دوم، mime فایل از قبل فرمت مقصد است
		// پس convert_attachment() آن را 'skipped' برمی‌گرداند و بازگشتی رخ نمی‌دهد.
		$result = $this->conversion_service->convert_attachment( $attachment_id );

		if ( 'converted' === $result['status'] ) {
			// metadata جدید از قبل توسط Conversion_Service ساخته و ذخیره شده؛
			// آن را برای هماهنگی با فراخوانی‌کننده‌ی اصلی این فیلتر هم برمی‌گردانیم.
			$fresh = wp_get_attachment_metadata( $attachment_id );
			return is_array( $fresh ) ? $fresh : $metadata;
		}

		return $metadata;
	}
}
