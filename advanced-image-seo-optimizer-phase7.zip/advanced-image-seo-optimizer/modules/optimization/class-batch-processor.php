<?php
namespace AISEO\Modules\Optimization;

use AISEO\Queue_Manager;
use AISEO\Settings;
use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پردازش دسته‌ای تصاویر قدیمی کتابخانه‌ی رسانه.
 * جایگزین webp_converter_convert_old_images() که همه‌چیز را در یک درخواست synchronous
 * انجام می‌داد (ریسک تایم‌اوت روی هاست ضعیف). اینجا از Queue_Manager استفاده می‌شود:
 * ابتدا صف پر می‌شود (enqueue_eligible)، سپس هر بار یک تکه‌ی کوچک پردازش می‌شود (process_tick)
 * که از طریق AJAX پشت‌سرهم توسط جاوااسکریپت ادمین صدا زده می‌شود.
 */
class Batch_Processor {

	public const ITEM_TYPE = 'optimize_image';

	private Queue_Manager $queue_manager;
	private Settings $settings;
	private Logger $logger;
	private Conversion_Service $conversion_service;

	public function __construct( Queue_Manager $queue_manager, Settings $settings, Logger $logger, Conversion_Service $conversion_service ) {
		$this->queue_manager      = $queue_manager;
		$this->settings           = $settings;
		$this->logger             = $logger;
		$this->conversion_service = $conversion_service;
	}

	/**
	 * اسکن کتابخانه‌ی رسانه و افزودن تصاویر واجد شرایط به صف.
	 * (نسخه‌ی سبک اسکن؛ نسخه‌ی کامل و قابل فیلتر در ماژول Media_Library، فاز ۷، اضافه می‌شود.)
	 *
	 * @return int تعداد آیتم‌های جدید اضافه‌شده به صف
	 */
	public function enqueue_eligible( int $limit = 0 ): int {
		$args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => Conversion_Service::get_eligible_mime_types(),
			'post_status'    => 'inherit',
			'posts_per_page' => $limit > 0 ? $limit : -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		);

		$attachment_ids = get_posts( $args );
		$added          = 0;

		foreach ( $attachment_ids as $attachment_id ) {
			if ( $this->queue_manager->enqueue( self::ITEM_TYPE, (int) $attachment_id ) ) {
				++$added;
			}
		}

		$this->logger->info( 'optimization', "اسکن کتابخانه انجام شد؛ {$added} تصویر جدید به صف اضافه شد." );

		return $added;
	}

	/**
	 * پردازش یک تکه (chunk) از صف. طراحی‌شده برای فراخوانی پشت‌سرهم از طریق AJAX
	 * تا هرگز یک درخواست HTTP طولانی نداشته باشیم.
	 *
	 * @return array{processed:int, converted:int, skipped:int, failed:int, remaining:int, locked:bool, bytes_before:int, bytes_after:int}
	 *         bytes_before/bytes_after فقط مجموع همین تکه هستند (نه کل عمر افزونه)؛
	 *         برای گزارش زنده‌ی «این اجرای پردازش دسته‌ای» در سمت جاوااسکریپت جمع زده می‌شوند.
	 */
	public function process_tick(): array {
		if ( ! $this->queue_manager->acquire_lock( self::ITEM_TYPE, 55 ) ) {
			return array(
				'processed'    => 0,
				'converted'    => 0,
				'skipped'      => 0,
				'failed'       => 0,
				'remaining'    => $this->get_stats()['pending'],
				'locked'       => true,
				'bytes_before' => 0,
				'bytes_after'  => 0,
			);
		}

		$chunk_size = $this->settings->get_batch_chunk_size();
		$items      = $this->queue_manager->claim_batch( self::ITEM_TYPE, $chunk_size );

		$converted    = 0;
		$skipped      = 0;
		$failed       = 0;
		$bytes_before = 0;
		$bytes_after  = 0;

		foreach ( $items as $item ) {
			$result = $this->conversion_service->convert_attachment( (int) $item->object_id );

			switch ( $result['status'] ) {
				case 'converted':
					$this->queue_manager->mark_done( (int) $item->id );
					++$converted;
					$bytes_before += (int) $result['bytes_before'];
					$bytes_after  += (int) $result['bytes_after'];
					break;
				case 'skipped':
					$this->queue_manager->mark_done( (int) $item->id );
					++$skipped;
					break;
				default:
					$message = $result['error'] instanceof \WP_Error ? $result['error']->get_error_message() : 'خطای نامشخص';
					$this->queue_manager->mark_failed( (int) $item->id, $message );
					++$failed;
					break;
			}
		}

		$this->queue_manager->release_lock( self::ITEM_TYPE );

		return array(
			'processed'    => count( $items ),
			'converted'    => $converted,
			'skipped'      => $skipped,
			'failed'       => $failed,
			'remaining'    => $this->get_stats()['pending'],
			'locked'       => false,
			'bytes_before' => $bytes_before,
			'bytes_after'  => $bytes_after,
		);
	}

	public function get_stats(): array {
		return $this->queue_manager->get_stats( self::ITEM_TYPE );
	}

	public function reset_completed(): void {
		$this->queue_manager->clear_completed( self::ITEM_TYPE );
	}

	/**
	 * برگرداندن آیتم‌های ناموفق به صف (pending) برای یک تلاش دوباره،
	 * مثلاً بعد از رفع مشکل هاست (کمبود حافظه، تایم‌اوت موقت و…).
	 *
	 * @return int تعداد آیتم‌هایی که برای تلاش مجدد صف‌بندی شدند
	 */
	public function retry_failed(): int {
		return $this->queue_manager->retry_failed( self::ITEM_TYPE );
	}
}
