<?php
namespace AISEO\Modules\Watermark;

use AISEO\Settings;
use AISEO\Logger;
use AISEO\Server_Capabilities;
use AISEO\Queue_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * نقطه‌ی ورود ماژول واترمارک (فاز ۵).
 * مسئولیت: ساخت و سیم‌کشی سرویس‌های داخلی (Watermark_Rules، Watermark_Renderer،
 * Watermark_Batch_Processor) و ثبت هوک آپلود؛ دقیقاً هم‌الگوی Seo_Engine فاز ۴.
 * طبق اصل «هر ماژول خودبسنده»: غیرفعال بودن این ماژول تأثیری روی بهینه‌سازی/سئو/ویرایشگر ندارد.
 */
class Watermark_Engine {

	private Settings $settings;
	private Logger $logger;

	private Watermark_Rules $rules;
	private Watermark_Renderer $renderer;
	private ?Watermark_Batch_Processor $batch_processor = null;

	public function __construct( Settings $settings, Logger $logger, Server_Capabilities $server_capabilities, ?Queue_Manager $queue_manager = null ) {
		$this->settings = $settings;
		$this->logger   = $logger;

		$this->rules    = new Watermark_Rules( $settings );
		$this->renderer = new Watermark_Renderer( $server_capabilities, $settings, $logger );

		if ( null !== $queue_manager ) {
			$this->batch_processor = new Watermark_Batch_Processor( $queue_manager, $settings, $logger, $this->rules, $this->renderer );
		}
	}

	public function boot(): void {
		// اولویت ۱۵: بعد از تبدیل فرمت ماژول بهینه‌سازی (اولویت ۱۰، تا واترمارک روی خروجی
		// نهایی WebP/AVIF هم اعمال شود) و قبل از تولید متادیتای سئوی ماژول سئو (اولویت ۲۰).
		add_filter( 'wp_generate_attachment_metadata', array( $this, 'on_attachment_metadata_generated' ), 15, 2 );

		$this->logger->info( 'watermark', 'ماژول واترمارک فعال شد (فاز ۵).' );
	}

	/**
	 * هوک روی wp_generate_attachment_metadata: طبق تنظیم «اعمال حین آپلود»، سایزهای واجد شرایط
	 * را واترمارک می‌کند. خود متادیتا دست‌نخورده برمی‌گردد (رندر روی فایل انجام می‌شود، نه متادیتا).
	 */
	public function on_attachment_metadata_generated( $metadata, $attachment_id ) {
		if ( ! $this->settings->should_apply_watermark_on_upload() ) {
			return $metadata;
		}

		$attachment_id = (int) $attachment_id;

		try {
			if ( ! $this->rules->is_attachment_eligible( $attachment_id ) ) {
				return $metadata;
			}

			foreach ( $this->rules->get_eligible_sizes_for_attachment( $attachment_id ) as $size_key => $file_path ) {
				$this->renderer->apply_to_size( $attachment_id, $size_key, $file_path );
			}
		} catch ( \Throwable $e ) {
			$this->logger->error( 'watermark', 'خطا در اعمال خودکار واترمارک حین آپلود: ' . $e->getMessage() );
		}

		return $metadata;
	}

	public function get_rules(): Watermark_Rules {
		return $this->rules;
	}

	public function get_renderer(): Watermark_Renderer {
		return $this->renderer;
	}

	public function get_batch_processor(): ?Watermark_Batch_Processor {
		return $this->batch_processor;
	}
}
