<?php
namespace AISEO\Modules\Watermark;

use AISEO\Queue_Manager;
use AISEO\Settings;
use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پردازش دسته‌ای اعمال واترمارک روی تصاویر قدیمی کتابخانه‌ی رسانه.
 * دقیقاً همان الگوی Seo_Batch_Processor فاز ۴ (که خودش از Batch_Processor فاز ۳ گرفته شده)
 * را دنبال می‌کند: همان Queue_Manager مشترک، این‌بار با item_type='watermark'.
 */
class Watermark_Batch_Processor {

	public const ITEM_TYPE = 'watermark';

	private Queue_Manager $queue_manager;
	private Settings $settings;
	private Logger $logger;
	private Watermark_Rules $rules;
	private Watermark_Renderer $renderer;

	public function __construct( Queue_Manager $queue_manager, Settings $settings, Logger $logger, Watermark_Rules $rules, Watermark_Renderer $renderer ) {
		$this->queue_manager = $queue_manager;
		$this->settings      = $settings;
		$this->logger        = $logger;
		$this->rules         = $rules;
		$this->renderer      = $renderer;
	}

	public function enqueue_eligible( int $limit = 0 ): int {
		$args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'posts_per_page' => $limit > 0 ? $limit : -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		);

		$attachment_ids = get_posts( $args );
		$added          = 0;

		foreach ( $attachment_ids as $attachment_id ) {
			if ( ! $this->rules->is_attachment_eligible( (int) $attachment_id ) ) {
				continue;
			}
			if ( $this->queue_manager->enqueue( self::ITEM_TYPE, (int) $attachment_id ) ) {
				++$added;
			}
		}

		$this->logger->info( 'watermark', "اسکن کتابخانه برای واترمارک انجام شد؛ {$added} تصویر جدید به صف اضافه شد." );

		return $added;
	}

	/**
	 * @return array{processed:int, applied:int, skipped:int, failed:int, remaining:int, locked:bool}
	 */
	public function process_tick(): array {
		if ( ! $this->queue_manager->acquire_lock( self::ITEM_TYPE, 55 ) ) {
			return array(
				'processed' => 0,
				'applied'   => 0,
				'skipped'   => 0,
				'failed'    => 0,
				'remaining' => $this->get_stats()['pending'],
				'locked'    => true,
			);
		}

		$chunk_size = $this->settings->get_batch_chunk_size();
		$items      = $this->queue_manager->claim_batch( self::ITEM_TYPE, $chunk_size );

		$applied = 0;
		$skipped = 0;
		$failed  = 0;

		foreach ( $items as $item ) {
			$attachment_id = (int) $item->object_id;

			try {
				$sizes = $this->rules->get_eligible_sizes_for_attachment( $attachment_id );

				if ( empty( $sizes ) ) {
					$this->queue_manager->mark_done( (int) $item->id );
					++$skipped;
					continue;
				}

				$had_failure = false;
				foreach ( $sizes as $size_key => $file_path ) {
					$result = $this->renderer->apply_to_size( $attachment_id, $size_key, $file_path );
					if ( 'failed' === $result['status'] ) {
						$had_failure = true;
					}
				}

				if ( $had_failure ) {
					$this->queue_manager->mark_failed( (int) $item->id, 'حداقل یک سایز واترمارک نشد.' );
					++$failed;
				} else {
					$this->queue_manager->mark_done( (int) $item->id );
					++$applied;
				}
			} catch ( \Throwable $e ) {
				$this->queue_manager->mark_failed( (int) $item->id, $e->getMessage() );
				++$failed;
			}
		}

		$this->queue_manager->release_lock( self::ITEM_TYPE );

		return array(
			'processed' => count( $items ),
			'applied'   => $applied,
			'skipped'   => $skipped,
			'failed'    => $failed,
			'remaining' => $this->get_stats()['pending'],
			'locked'    => false,
		);
	}

	public function get_stats(): array {
		return $this->queue_manager->get_stats( self::ITEM_TYPE );
	}

	public function reset_completed(): void {
		$this->queue_manager->clear_completed( self::ITEM_TYPE );
	}

	public function retry_failed(): int {
		return $this->queue_manager->retry_failed( self::ITEM_TYPE );
	}
}
