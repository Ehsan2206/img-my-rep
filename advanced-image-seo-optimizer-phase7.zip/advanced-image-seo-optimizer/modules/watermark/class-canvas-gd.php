<?php
namespace AISEO\Modules\Watermark;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پیاده‌سازی رندر واترمارک با GD.
 * برای متن از فونت داخلی GD (imagestring/imagettftext بدون نیاز به فایل TTF) استفاده می‌شود
 * تا هیچ وابستگی فونت بیرونی لازم نباشد. برای لوگو، ترکیب شفافیت با imagecopymerge انجام می‌شود
 * (محدودیت شناخته‌شده‌ی GD: کیفیت ترکیب آلفا نسبت به Imagick پایین‌تر است، اما بدون کتابخانه‌ی
 * اضافه کار می‌کند).
 */
class Canvas_GD implements Watermark_Canvas_Interface {

	private const LOADERS = array(
		'image/jpeg' => 'imagecreatefromjpeg',
		'image/png'  => 'imagecreatefrompng',
		'image/gif'  => 'imagecreatefromgif',
		'image/bmp'  => 'imagecreatefrombmp',
		'image/webp' => 'imagecreatefromwebp',
	);

	private const WRITERS = array(
		'image/jpeg' => 'imagejpeg',
		'image/png'  => 'imagepng',
		'image/gif'  => 'imagegif',
		'image/bmp'  => 'imagebmp',
		'image/webp' => 'imagewebp',
	);

	public function supports(): bool {
		return function_exists( 'gd_info' );
	}

	public function apply( string $file_path, array $args ) {
		$mime = $this->detect_mime( $file_path );
		if ( '' === $mime || ! isset( self::LOADERS[ $mime ] ) || ! function_exists( self::LOADERS[ $mime ] ) ) {
			return new \WP_Error( 'aiseo_watermark_unsupported_mime', 'نوع فایل توسط GD برای واترمارک پشتیبانی نمی‌شود: ' . $mime );
		}

		$loader = self::LOADERS[ $mime ];
		$image  = @$loader( $file_path );
		if ( false === $image ) {
			return new \WP_Error( 'aiseo_watermark_load_failed', 'بارگذاری تصویر با GD شکست خورد: ' . basename( $file_path ) );
		}

		imagepalettetotruecolor( $image );
		imagealphablending( $image, true );
		imagesavealpha( $image, true );

		if ( 'image' === ( $args['type'] ?? 'text' ) && ! empty( $args['logo_path'] ) ) {
			$this->draw_logo( $image, $args );
		} else {
			$this->draw_text( $image, $args );
		}

		$writer = self::WRITERS[ $mime ] ?? null;
		$ok     = false;

		if ( 'image/jpeg' === $mime && $writer ) {
			$ok = imagejpeg( $image, $file_path, 90 );
		} elseif ( $writer && function_exists( $writer ) ) {
			$ok = 'image/webp' === $mime ? imagewebp( $image, $file_path, 90 ) : $writer( $image, $file_path );
		}

		imagedestroy( $image );

		if ( ! $ok ) {
			return new \WP_Error( 'aiseo_watermark_write_failed', 'نوشتن فایل واترمارک‌شده با GD شکست خورد.' );
		}

		return true;
	}

	private function draw_text( $image, array $args ): void {
		$text  = (string) ( $args['text'] ?? '' );
		if ( '' === trim( $text ) ) {
			return;
		}

		$font_index  = 5; // بزرگ‌ترین فونت داخلی GD (بدون نیاز به فایل TTF).
		$char_width  = imagefontwidth( $font_index );
		$char_height = imagefontheight( $font_index );
		$text_width  = $char_width * strlen( $text );
		$text_height = $char_height;

		list( $x, $y ) = $this->calculate_position(
			imagesx( $image ),
			imagesy( $image ),
			$text_width,
			$text_height,
			(string) ( $args['position'] ?? 'bottom-right' ),
			(int) ( $args['margin'] ?? 16 )
		);

		$rgb     = $this->hex_to_rgb( (string) ( $args['text_color'] ?? '#ffffff' ) );
		$opacity = max( 0, min( 100, (int) ( $args['opacity'] ?? 60 ) ) );
		$alpha   = (int) round( 127 - ( $opacity / 100 * 127 ) ); // GD: 0=مات، 127=کاملاً شفاف

		$color = imagecolorallocatealpha( $image, $rgb[0], $rgb[1], $rgb[2], $alpha );

		// یک سایه‌ی تیره‌ی ملایم پشت متن برای خوانایی روی هر پس‌زمینه‌ای.
		$shadow = imagecolorallocatealpha( $image, 0, 0, 0, min( 127, $alpha + 40 ) );
		imagestring( $image, $font_index, $x + 1, $y + 1, $text, $shadow );
		imagestring( $image, $font_index, $x, $y, $text, $color );
	}

	private function draw_logo( $image, array $args ): void {
		$logo_path = (string) $args['logo_path'];
		$logo_mime = $this->detect_mime( $logo_path );
		if ( ! isset( self::LOADERS[ $logo_mime ] ) || ! function_exists( self::LOADERS[ $logo_mime ] ) ) {
			return;
		}

		$logo = @self::LOADERS[ $logo_mime ]( $logo_path );
		if ( false === $logo ) {
			return;
		}

		imagepalettetotruecolor( $logo );
		imagealphablending( $logo, true );
		imagesavealpha( $logo, true );

		$base_w    = imagesx( $image );
		$base_h    = imagesy( $image );
		$scale_pct = max( 5, min( 100, (int) ( $args['scale'] ?? 20 ) ) );
		$target_w  = (int) round( $base_w * ( $scale_pct / 100 ) );
		$ratio     = imagesy( $logo ) > 0 ? imagesx( $logo ) / imagesy( $logo ) : 1;
		$target_h  = $ratio > 0 ? (int) round( $target_w / $ratio ) : $target_w;

		if ( $target_w > 0 && $target_h > 0 && ( $target_w !== imagesx( $logo ) || $target_h !== imagesy( $logo ) ) ) {
			$resized = imagescale( $logo, $target_w, $target_h );
			if ( $resized ) {
				imagedestroy( $logo );
				$logo = $resized;
			}
		}

		list( $x, $y ) = $this->calculate_position(
			$base_w,
			$base_h,
			imagesx( $logo ),
			imagesy( $logo ),
			(string) ( $args['position'] ?? 'bottom-right' ),
			(int) ( $args['margin'] ?? 16 )
		);

		$opacity = max( 0, min( 100, (int) ( $args['opacity'] ?? 60 ) ) );
		imagecopymerge( $image, $logo, $x, $y, 0, 0, imagesx( $logo ), imagesy( $logo ), $opacity );

		imagedestroy( $logo );
	}

	private function calculate_position( int $base_w, int $base_h, int $w, int $h, string $position, int $margin ): array {
		switch ( $position ) {
			case 'top-left':
				return array( $margin, $margin );
			case 'top-right':
				return array( max( $margin, $base_w - $w - $margin ), $margin );
			case 'bottom-left':
				return array( $margin, max( $margin, $base_h - $h - $margin ) );
			case 'center':
				return array( max( 0, (int) ( ( $base_w - $w ) / 2 ) ), max( 0, (int) ( ( $base_h - $h ) / 2 ) ) );
			case 'bottom-right':
			default:
				return array( max( $margin, $base_w - $w - $margin ), max( $margin, $base_h - $h - $margin ) );
		}
	}

	private function hex_to_rgb( string $hex ): array {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return array( 255, 255, 255 );
		}
		return array(
			hexdec( substr( $hex, 0, 2 ) ),
			hexdec( substr( $hex, 2, 2 ) ),
			hexdec( substr( $hex, 4, 2 ) ),
		);
	}

	/**
	 * تشخیص mime واقعی فایل (نه فقط پسوند) طبق نکته‌ی امنیتی فاز ۱: هیچ فایلی صرفاً
	 * بر اساس پسوند به GD/Imagick سپرده نمی‌شود.
	 */
	private function detect_mime( string $file_path ): string {
		$info = @getimagesize( $file_path );
		return is_array( $info ) && isset( $info['mime'] ) ? $info['mime'] : '';
	}
}
