<?php
namespace AISEO\Modules\Watermark;

use AISEO\Server_Capabilities;
use AISEO\Settings;
use AISEO\Logger;
use AISEO\Helpers\File_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاس Context الگوی Strategy: بین Canvas_GD و Canvas_Imagick بر اساس Server_Capabilities
 * انتخاب می‌کند (دقیقاً هم‌الگوی Image_Converter در ماژول بهینه‌سازی فاز ۳).
 * همچنین قبل از رندر، طبق اصل Non-destructive فاز ۱، نسخه‌ی پیش از واترمارک هر سایز را
 * در پوشه‌ی محافظت‌شده‌ی aiseo-backups بکاپ می‌گیرد.
 */
class Watermark_Renderer {

	private const META_KEY = '_aiseo_watermark_backup';

	private Server_Capabilities $server_capabilities;
	private Settings $settings;
	private Logger $logger;
	private array $strategies;

	public function __construct( Server_Capabilities $server_capabilities, Settings $settings, Logger $logger ) {
		$this->server_capabilities = $server_capabilities;
		$this->settings             = $settings;
		$this->logger               = $logger;
		$this->strategies           = array(
			'imagick' => new Canvas_Imagick(),
			'gd'      => new Canvas_GD(),
		);
	}

	/**
	 * اعمال واترمارک روی یک سایز مشخص از attachment، با بکاپ‌گیری پیش از تغییر.
	 *
	 * @return array{status:string, message?:string}
	 */
	public function apply_to_size( int $attachment_id, string $size_key, string $file_path ): array {
		if ( ! file_exists( $file_path ) ) {
			return array( 'status' => 'failed', 'message' => 'فایل یافت نشد: ' . $file_path );
		}

		if ( ! File_Helper::is_within_uploads( $file_path ) ) {
			return array( 'status' => 'failed', 'message' => 'مسیر فایل خارج از پوشه‌ی uploads است.' );
		}

		$strategy = $this->pick_strategy();
		if ( null === $strategy ) {
			return array( 'status' => 'failed', 'message' => 'هیچ کتابخانه‌ی تصویری (GD/Imagick) برای واترمارک در دسترس نیست.' );
		}

		if ( $this->settings->should_keep_watermark_backup() ) {
			$this->backup_before_watermark( $attachment_id, $size_key, $file_path );
		}

		$args = $this->build_render_args( $attachment_id );

		$result = $strategy->apply( $file_path, $args );

		if ( is_wp_error( $result ) ) {
			$this->logger->error( 'watermark', "خطا در اعمال واترمارک روی attachment #{$attachment_id} ({$size_key}): " . $result->get_error_message() );
			return array( 'status' => 'failed', 'message' => $result->get_error_message() );
		}

		$this->logger->info( 'watermark', "واترمارک روی attachment #{$attachment_id} ({$size_key}) اعمال شد." );
		return array( 'status' => 'applied' );
	}

	private function pick_strategy(): ?Watermark_Canvas_Interface {
		$caps = $this->server_capabilities->detect();

		if ( ! empty( $caps['imagick']['available'] ) && $this->strategies['imagick']->supports() ) {
			return $this->strategies['imagick'];
		}
		if ( ! empty( $caps['gd']['available'] ) && $this->strategies['gd']->supports() ) {
			return $this->strategies['gd'];
		}
		return null;
	}

	private function build_render_args( int $attachment_id ): array {
		$type = $this->settings->get_watermark_type();

		$args = array(
			'type'       => $type,
			'position'   => $this->settings->get_watermark_position(),
			'opacity'    => $this->settings->get_watermark_opacity(),
			'margin'     => $this->settings->get_watermark_margin(),
			'scale'      => $this->settings->get_watermark_scale(),
			'text_color' => $this->settings->get_watermark_text_color(),
			'font_size'  => $this->settings->get_watermark_font_size(),
		);

		if ( 'image' === $type ) {
			$logo_id = $this->settings->get_watermark_image_id();
			$logo_path = $logo_id > 0 ? get_attached_file( $logo_id ) : '';
			$args['logo_path'] = is_string( $logo_path ) ? $logo_path : '';
		} else {
			$args['text'] = $this->resolve_text_template( $this->settings->get_watermark_text(), $attachment_id );
		}

		return $args;
	}

	/**
	 * جایگزینی placeholder های ساده در قالب متن واترمارک، هم‌الگوی Metadata_Generator فاز ۴.
	 */
	private function resolve_text_template( string $template, int $attachment_id ): string {
		$replacements = array(
			'{site_name}' => get_bloginfo( 'name' ),
			'{date}'      => date_i18n( get_option( 'date_format' ) ),
		);
		return strtr( $template, $replacements );
	}

	private function backup_before_watermark( int $attachment_id, string $size_key, string $file_path ): void {
		$existing = get_post_meta( $attachment_id, self::META_KEY, true );
		$existing = is_array( $existing ) ? $existing : array();

		// اگر قبلاً برای همین سایز بکاپ گرفته شده (مثلاً واترمارک قبلی)، دوباره گرفته نمی‌شود
		// تا نسخه‌ی واقعاً «بدون واترمارک» جایگزین نشود.
		if ( isset( $existing[ $size_key ] ) && file_exists( $existing[ $size_key ] ) ) {
			return;
		}

		$backup_dir  = File_Helper::get_backup_dir( $attachment_id );
		$backup_path = $backup_dir . 'wm-' . $size_key . '-' . basename( $file_path );

		if ( @copy( $file_path, $backup_path ) ) {
			$existing[ $size_key ] = $backup_path;
			update_post_meta( $attachment_id, self::META_KEY, $existing );
		} else {
			$this->logger->warning( 'watermark', "بکاپ‌گیری پیش از واترمارک ناموفق بود: {$file_path}" );
		}
	}

	public function has_backup( int $attachment_id, string $size_key ): bool {
		$existing = get_post_meta( $attachment_id, self::META_KEY, true );
		return is_array( $existing ) && isset( $existing[ $size_key ] ) && file_exists( $existing[ $size_key ] );
	}
}
