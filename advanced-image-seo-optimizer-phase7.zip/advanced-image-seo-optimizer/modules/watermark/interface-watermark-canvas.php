<?php
namespace AISEO\Modules\Watermark;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * قرارداد مشترک هر پیاده‌سازی رندر واترمارک (Strategy Pattern)،
 * دقیقاً هم‌خانواده‌ی Image_Converter_Interface در ماژول بهینه‌سازی.
 * پیاده‌سازی‌های فعلی: Canvas_GD و Canvas_Imagick.
 */
interface Watermark_Canvas_Interface {

	/**
	 * آیا این استراتژی روی سرور فعلی قابل استفاده است؟
	 */
	public function supports(): bool;

	/**
	 * اعمال واترمارک روی فایل تصویر، درجا (فایل مقصد جایگزین فایل مبدا می‌شود).
	 * بکاپ‌گیری از فایل پیش از این متد بر عهده‌ی Watermark_Renderer است؛
	 * این کلاس فقط مسئول رندر است.
	 *
	 * @param string $file_path مسیر مطلق فایل تصویر (jpeg/png/gif/webp/bmp).
	 * @param array  $args {
	 *     @type string $type       'text' یا 'image'
	 *     @type string $text       متن واترمارک (برای type=text)
	 *     @type string $text_color کد hex مثل #ffffff
	 *     @type int    $font_size  اندازه‌ی فونت به پیکسل
	 *     @type string $logo_path  مسیر مطلق فایل لوگو (برای type=image)
	 *     @type int    $opacity    0-100
	 *     @type string $position   top-left|top-right|bottom-left|bottom-right|center
	 *     @type int    $margin     فاصله از لبه به پیکسل
	 *     @type int    $scale      درصد عرض تصویر برای عرض لوگو (فقط type=image)
	 * }
	 * @return true|\WP_Error
	 */
	public function apply( string $file_path, array $args );
}
