<?php
namespace AISEO\Modules\Watermark;

use AISEO\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * شرط‌گذاری اعمال واترمارک: کدام تصاویر و کدام سایزها واجد شرایط‌اند.
 * عمداً از Watermark_Renderer جدا نگه داشته شده (همان جدایی Image_Converter از
 * Conversion_Service در فاز ۳) تا منطق «چه چیزی واترمارک شود» از «چطور رندر شود» مستقل بماند.
 */
class Watermark_Rules {

	// SVG به‌عمد پشتیبانی نمی‌شود: رندر واترمارک روی canvas بیت‌مپی (GD/Imagick) برای
	// تصویر برداری معنا/کیفیت درستی ندارد و از دامنه‌ی فاز ۵ خارج است.
	private const UNSUPPORTED_MIMES = array( 'image/svg+xml' );

	private Settings $settings;

	public function __construct( Settings $settings ) {
		$this->settings = $settings;
	}

	public function is_attachment_eligible( int $attachment_id ): bool {
		if ( 'attachment' !== get_post_type( $attachment_id ) ) {
			return false;
		}

		$mime = get_post_mime_type( $attachment_id );
		if ( ! is_string( $mime ) || 0 !== strpos( $mime, 'image/' ) ) {
			return false;
		}

		if ( in_array( $mime, self::UNSUPPORTED_MIMES, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * لیست سایزهایی از یک attachment که طبق تنظیمات باید واترمارک شوند، همراه با مسیر فایل هرکدام.
	 * حداقل اندازه (min_width) رعایت می‌شود تا thumbnail های خیلی کوچک واترمارک نشوند.
	 *
	 * @return array<string, string> نگاشت size_key => مسیر مطلق فایل
	 */
	public function get_eligible_sizes_for_attachment( int $attachment_id ): array {
		$targets   = array_keys( array_filter( $this->settings->get_watermark_target_sizes() ) );
		$min_width = $this->settings->get_watermark_min_width();
		$result    = array();

		if ( empty( $targets ) ) {
			return $result;
		}

		$upload_dir  = wp_get_upload_dir();
		$full_path   = get_attached_file( $attachment_id );
		$metadata    = wp_get_attachment_metadata( $attachment_id );

		if ( in_array( 'full', $targets, true ) && $full_path && file_exists( $full_path ) ) {
			$full_width = is_array( $metadata ) ? (int) ( $metadata['width'] ?? 0 ) : 0;
			if ( 0 === $full_width || $full_width >= $min_width ) {
				$result['full'] = $full_path;
			}
		}

		if ( is_array( $metadata ) && ! empty( $metadata['sizes'] ) && $full_path ) {
			$base_dir = trailingslashit( dirname( $full_path ) );

			foreach ( $metadata['sizes'] as $size_key => $size_data ) {
				if ( ! in_array( $size_key, $targets, true ) ) {
					continue;
				}
				if ( empty( $size_data['file'] ) ) {
					continue;
				}
				$width = (int) ( $size_data['width'] ?? 0 );
				if ( $width > 0 && $width < $min_width ) {
					continue;
				}
				$path = $base_dir . $size_data['file'];
				if ( file_exists( $path ) ) {
					$result[ $size_key ] = $path;
				}
			}
		}

		return $result;
	}
}
