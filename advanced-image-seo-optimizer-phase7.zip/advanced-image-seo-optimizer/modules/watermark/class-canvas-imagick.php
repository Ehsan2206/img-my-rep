<?php
namespace AISEO\Modules\Watermark;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پیاده‌سازی رندر واترمارک با Imagick.
 * کیفیت ترکیب آلفا (composite) و متن به‌مراتب بهتر از GD است؛ طبق Server_Capabilities
 * این استراتژی وقتی Imagick موجود باشد در اولویت قرار می‌گیرد.
 */
class Canvas_Imagick implements Watermark_Canvas_Interface {

	public function supports(): bool {
		return class_exists( '\Imagick' );
	}

	public function apply( string $file_path, array $args ) {
		if ( ! $this->supports() ) {
			return new \WP_Error( 'aiseo_watermark_no_imagick', 'Imagick روی این سرور در دسترس نیست.' );
		}

		try {
			$image = new \Imagick( $file_path );

			if ( 'image' === ( $args['type'] ?? 'text' ) && ! empty( $args['logo_path'] ) ) {
				$this->draw_logo( $image, $args );
			} else {
				$this->draw_text( $image, $args );
			}

			$image->writeImage( $file_path );
			$image->clear();
			$image->destroy();
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'aiseo_watermark_imagick_failed', 'اعمال واترمارک با Imagick شکست خورد: ' . $e->getMessage() );
		}

		return true;
	}

	private function draw_text( \Imagick $image, array $args ): void {
		$text = (string) ( $args['text'] ?? '' );
		if ( '' === trim( $text ) ) {
			return;
		}

		$draw = new \ImagickDraw();
		$draw->setFontSize( max( 6, (int) ( $args['font_size'] ?? 16 ) ) );

		$opacity = max( 0, min( 100, (int) ( $args['opacity'] ?? 60 ) ) ) / 100;
		$color   = new \ImagickPixel( (string) ( $args['text_color'] ?? '#ffffff' ) );
		$color->setColorValue( \Imagick::COLOR_ALPHA, $opacity );
		$draw->setFillColor( $color );

		$shadow = new \ImagickPixel( '#000000' );
		$shadow->setColorValue( \Imagick::COLOR_ALPHA, min( 1, $opacity + 0.25 ) );

		$metrics    = $image->queryFontMetrics( $draw, $text );
		$text_width = (int) ( $metrics['textWidth'] ?? ( strlen( $text ) * 10 ) );
		$text_height = (int) ( $metrics['textHeight'] ?? 20 );

		list( $x, $y ) = $this->calculate_position(
			$image->getImageWidth(),
			$image->getImageHeight(),
			$text_width,
			$text_height,
			(string) ( $args['position'] ?? 'bottom-right' ),
			(int) ( $args['margin'] ?? 16 )
		);

		// مبدأ annotateImage پایه‌ی خط متن است، نه گوشه‌ی بالا؛ ارتفاع تقریبی اضافه می‌شود.
		$baseline_y = $y + $text_height;

		$draw->setFillColor( $shadow );
		$image->annotateImage( $draw, $x + 1, $baseline_y + 1, 0, $text );

		$draw->setFillColor( $color );
		$image->annotateImage( $draw, $x, $baseline_y, 0, $text );
	}

	private function draw_logo( \Imagick $image, array $args ): void {
		$logo_path = (string) $args['logo_path'];
		if ( ! file_exists( $logo_path ) ) {
			return;
		}

		try {
			$logo = new \Imagick( $logo_path );
		} catch ( \Throwable $e ) {
			return;
		}

		$base_w    = $image->getImageWidth();
		$base_h    = $image->getImageHeight();
		$scale_pct = max( 5, min( 100, (int) ( $args['scale'] ?? 20 ) ) );
		$target_w  = (int) round( $base_w * ( $scale_pct / 100 ) );
		$ratio     = $logo->getImageHeight() > 0 ? $logo->getImageWidth() / $logo->getImageHeight() : 1;
		$target_h  = $ratio > 0 ? (int) round( $target_w / $ratio ) : $target_w;

		if ( $target_w > 0 && $target_h > 0 ) {
			$logo->resizeImage( $target_w, $target_h, \Imagick::FILTER_LANCZOS, 1 );
		}

		$opacity = max( 0, min( 100, (int) ( $args['opacity'] ?? 60 ) ) ) / 100;
		if ( $opacity < 1 ) {
			$logo->evaluateImage( \Imagick::EVALUATE_MULTIPLY, $opacity, \Imagick::CHANNEL_ALPHA );
		}

		list( $x, $y ) = $this->calculate_position(
			$base_w,
			$base_h,
			$logo->getImageWidth(),
			$logo->getImageHeight(),
			(string) ( $args['position'] ?? 'bottom-right' ),
			(int) ( $args['margin'] ?? 16 )
		);

		$image->compositeImage( $logo, \Imagick::COMPOSITE_OVER, $x, $y );

		$logo->clear();
		$logo->destroy();
	}

	private function calculate_position( int $base_w, int $base_h, int $w, int $h, string $position, int $margin ): array {
		switch ( $position ) {
			case 'top-left':
				return array( $margin, $margin );
			case 'top-right':
				return array( max( $margin, $base_w - $w - $margin ), $margin );
			case 'bottom-left':
				return array( $margin, max( $margin, $base_h - $h - $margin ) );
			case 'center':
				return array( max( 0, (int) ( ( $base_w - $w ) / 2 ) ), max( 0, (int) ( ( $base_h - $h ) / 2 ) ) );
			case 'bottom-right':
			default:
				return array( max( $margin, $base_w - $w - $margin ), max( $margin, $base_h - $h - $margin ) );
		}
	}
}
