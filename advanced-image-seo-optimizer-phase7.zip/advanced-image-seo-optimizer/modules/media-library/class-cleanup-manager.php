<?php
namespace AISEO\Modules\Media_Library;

use AISEO\Settings;
use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تشخیص و رفع مشکلات فایل کتابخانه‌ی رسانه:
 * - فایل اصلی گم‌شده (attachment یتیم از فایل واقعی)
 * - سایزهای thumbnail گم‌شده (مثلاً بعد از انتقال دستی/ناقص هاست)
 *
 * بررسی هر تصویر شامل چند فراخوانی file_exists() است (I/O)، پس طبق همان اصل
 * فاز ۱ («گالری‌های چند هزار تصویری نیاز به batch کوچک دارند») این کار مستقیم
 * روی کل کتابخانه اجرا نمی‌شود؛ Cleanup_Batch_Processor آن را تکه‌تکه انجام می‌دهد
 * و نتیجه‌ی هر تصویر در postmeta ذخیره می‌شود تا گزارش نهایی یک کوئری SQL سبک باشد.
 */
class Cleanup_Manager {

	public const META_STATUS  = '_aiseo_ml_scan_status'; // ok | fixed | missing_sizes | missing_file
	public const META_DETAILS = '_aiseo_ml_scan_details'; // JSON: لیست سایزهای گم‌شده
	public const META_SIZE    = '_aiseo_ml_file_size';
	public const META_TIME    = '_aiseo_ml_scan_time';

	private Settings $settings;
	private Logger $logger;

	public function __construct( Settings $settings, Logger $logger ) {
		$this->settings = $settings;
		$this->logger   = $logger;
	}

	/**
	 * بررسی یک attachment: وجود فایل اصلی + وجود همه‌ی سایزهای ثبت‌شده در متادیتا.
	 * در صورت گم بودن سایزها و روشن بودن «بازسازی خودکار»، بلافاصله تلاش برای بازسازی
	 * می‌کند و نتیجه‌ی نهایی (بعد از تلاش) ذخیره می‌شود.
	 *
	 * @return array{status:string, missing_sizes:array<int,string>, file_size:int}
	 */
	public function scan_attachment( int $attachment_id ): array {
		$file_path = get_attached_file( $attachment_id );

		if ( ! is_string( $file_path ) || '' === $file_path || ! file_exists( $file_path ) ) {
			$result = array( 'status' => 'missing_file', 'missing_sizes' => array(), 'file_size' => 0 );
			$this->store_result( $attachment_id, $result );
			return $result;
		}

		$file_size     = (int) filesize( $file_path );
		$missing_sizes = $this->find_missing_sizes( $attachment_id, $file_path );

		if ( empty( $missing_sizes ) ) {
			$result = array( 'status' => 'ok', 'missing_sizes' => array(), 'file_size' => $file_size );
			$this->store_result( $attachment_id, $result );
			return $result;
		}

		if ( $this->settings->should_auto_rebuild_thumbnails() ) {
			if ( $this->rebuild( $attachment_id ) ) {
				$still_missing = $this->find_missing_sizes( $attachment_id, $file_path );
				if ( empty( $still_missing ) ) {
					$result = array( 'status' => 'fixed', 'missing_sizes' => array(), 'file_size' => $file_size );
					$this->store_result( $attachment_id, $result );
					return $result;
				}
				$missing_sizes = $still_missing;
			}
		}

		$result = array( 'status' => 'missing_sizes', 'missing_sizes' => $missing_sizes, 'file_size' => $file_size );
		$this->store_result( $attachment_id, $result );
		return $result;
	}

	/**
	 * @return array<int,string> کلیدهای سایزهایی که در متادیتا ثبت شده‌اند اما فایل‌شان روی دیسک نیست.
	 */
	private function find_missing_sizes( int $attachment_id, string $original_path ): array {
		$metadata = wp_get_attachment_metadata( $attachment_id );

		if ( ! is_array( $metadata ) || empty( $metadata['sizes'] ) || ! is_array( $metadata['sizes'] ) ) {
			return array();
		}

		$dir     = trailingslashit( dirname( $original_path ) );
		$missing = array();

		foreach ( $metadata['sizes'] as $size_key => $size_data ) {
			if ( empty( $size_data['file'] ) ) {
				continue;
			}
			if ( ! file_exists( $dir . $size_data['file'] ) ) {
				$missing[] = (string) $size_key;
			}
		}

		return $missing;
	}

	/**
	 * بازسازی کامل thumbnail های یک attachment از روی فایل اصلی (که سالم است).
	 * از توابع هسته‌ی وردپرس استفاده می‌کند؛ هیچ منطق رمزگشایی تصویر سفارشی اینجا نیست.
	 */
	public function rebuild( int $attachment_id ): bool {
		$file_path = get_attached_file( $attachment_id );

		if ( ! is_string( $file_path ) || '' === $file_path || ! file_exists( $file_path ) ) {
			return false;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';

		$metadata = wp_generate_attachment_metadata( $attachment_id, $file_path );

		if ( ! is_array( $metadata ) || empty( $metadata ) ) {
			$this->logger->warning( 'media_library', "بازسازی thumbnail ها ناموفق بود: attachment #{$attachment_id}" );
			return false;
		}

		wp_update_attachment_metadata( $attachment_id, $metadata );
		$this->logger->info( 'media_library', "thumbnail های attachment #{$attachment_id} بازسازی شد." );

		return true;
	}

	private function store_result( int $attachment_id, array $result ): void {
		update_post_meta( $attachment_id, self::META_STATUS, $result['status'] );
		update_post_meta( $attachment_id, self::META_DETAILS, wp_json_encode( $result['missing_sizes'] ) );
		update_post_meta( $attachment_id, self::META_SIZE, $result['file_size'] );
		update_post_meta( $attachment_id, self::META_TIME, current_time( 'mysql' ) );
	}

	/**
	 * خلاصه‌ی آماری کل کتابخانه، صرفاً با کوئری‌های SQL سبک روی نتایج ذخیره‌شده
	 * (بدون هیچ فراخوانی file_exists در این متد).
	 *
	 * @return array{total:int, scanned:int, ok:int, fixed:int, missing_sizes:int, missing_file:int, total_size:int}
	 */
	public function get_summary(): array {
		global $wpdb;

		$total = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_status = 'inherit' AND post_mime_type LIKE 'image/%'"
		);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT meta_value AS status, COUNT(*) AS cnt FROM {$wpdb->postmeta} WHERE meta_key = %s GROUP BY meta_value",
				self::META_STATUS
			),
			ARRAY_A
		);

		$counts = array(
			'ok'            => 0,
			'fixed'         => 0,
			'missing_sizes' => 0,
			'missing_file'  => 0,
		);

		foreach ( (array) $rows as $row ) {
			if ( isset( $counts[ $row['status'] ] ) ) {
				$counts[ $row['status'] ] = (int) $row['cnt'];
			}
		}

		$scanned = array_sum( $counts );

		$total_size = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COALESCE(SUM(CAST(meta_value AS UNSIGNED)), 0) FROM {$wpdb->postmeta} WHERE meta_key = %s",
				self::META_SIZE
			)
		);

		return array(
			'total'         => $total,
			'scanned'       => $scanned,
			'ok'            => $counts['ok'],
			'fixed'         => $counts['fixed'],
			'missing_sizes' => $counts['missing_sizes'],
			'missing_file'  => $counts['missing_file'],
			'total_size'    => $total_size,
		);
	}

	/**
	 * لیست محدود آیتم‌های مشکل‌دار برای نمایش در پنل ادمین.
	 *
	 * @return array<int,array{id:int,title:string,status:string,missing_sizes:array<int,string>,edit_link:string}>
	 */
	public function get_problem_items( int $limit = 50 ): array {
		global $wpdb;

		$limit = max( 1, min( 200, $limit ) );

		$attachment_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IN ('missing_sizes','missing_file') LIMIT %d",
				self::META_STATUS,
				$limit
			)
		);

		$items = array();
		foreach ( $attachment_ids as $attachment_id ) {
			$attachment_id = (int) $attachment_id;
			$status        = (string) get_post_meta( $attachment_id, self::META_STATUS, true );
			$details_raw   = (string) get_post_meta( $attachment_id, self::META_DETAILS, true );
			$missing_sizes = json_decode( $details_raw, true );

			$items[] = array(
				'id'            => $attachment_id,
				'title'         => get_the_title( $attachment_id ),
				'status'        => $status,
				'missing_sizes' => is_array( $missing_sizes ) ? $missing_sizes : array(),
				'edit_link'     => (string) ( get_edit_post_link( $attachment_id, 'raw' ) ?: '' ),
			);
		}

		return $items;
	}
}
