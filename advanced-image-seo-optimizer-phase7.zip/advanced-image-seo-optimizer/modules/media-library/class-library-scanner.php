<?php
namespace AISEO\Modules\Media_Library;

use AISEO\Settings;
use AISEO\Logger;
use AISEO\Queue_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * نقطه‌ی ورود ماژول مدیریت کتابخانه‌ی رسانه (فاز ۷).
 * مسئولیت: ساخت و سیم‌کشی سرویس‌های داخلی (Duplicate_Detector، Cleanup_Manager،
 * پردازشگرهای دسته‌ای مربوطه، Stats_Dashboard) و ثبت هوک آپلود؛ دقیقاً هم‌الگوی
 * Watermark_Engine فاز ۵ و Editor_Engine فاز ۶.
 *
 * طبق اصل «هر ماژول خودبسنده»: غیرفعال بودن این ماژول تأثیری روی بهینه‌سازی/سئو/
 * واترمارک/ویرایشگر ندارد و برعکس.
 */
class Library_Scanner {

	private Settings $settings;
	private Logger $logger;

	private Duplicate_Detector $duplicate_detector;
	private Cleanup_Manager $cleanup_manager;
	private Stats_Dashboard $stats_dashboard;

	private ?Duplicate_Batch_Processor $duplicate_batch_processor = null;
	private ?Cleanup_Batch_Processor $cleanup_batch_processor    = null;

	public function __construct( Settings $settings, Logger $logger, ?Queue_Manager $queue_manager = null ) {
		$this->settings = $settings;
		$this->logger   = $logger;

		$this->duplicate_detector = new Duplicate_Detector( $logger );
		$this->cleanup_manager    = new Cleanup_Manager( $settings, $logger );
		$this->stats_dashboard    = new Stats_Dashboard( $this->duplicate_detector, $this->cleanup_manager );

		if ( null !== $queue_manager ) {
			$this->duplicate_batch_processor = new Duplicate_Batch_Processor( $queue_manager, $settings, $logger, $this->duplicate_detector );
			$this->cleanup_batch_processor    = new Cleanup_Batch_Processor( $queue_manager, $settings, $logger, $this->cleanup_manager );
		}
	}

	public function boot(): void {
		// اولویت ۳۰: بعد از بهینه‌سازی/واترمارک/سئو، تا هش روی فایل نهایی واقعی محاسبه شود
		// نه نسخه‌ی میانی پیش از تبدیل فرمت.
		add_filter( 'wp_generate_attachment_metadata', array( $this, 'on_attachment_metadata_generated' ), 30, 2 );

		// وقتی یک attachment حذف می‌شود، postmeta های این ماژول هم پاک شوند تا آماری
		// که بعداً محاسبه می‌شود گمراه‌کننده نباشد (تصویر حذف‌شده در گروه تکراری نماند).
		add_action( 'delete_attachment', array( $this, 'on_attachment_deleted' ) );

		$this->logger->info( 'media_library', 'ماژول مدیریت کتابخانه‌ی رسانه فعال شد (فاز ۷).' );
	}

	/**
	 * محاسبه‌ی خودکار هش محتوا برای تصاویر تازه آپلودشده، تا نیازی به اجرای دستی
	 * batch برای شناسایی تکراری‌های جدید نباشد. خطا در این مرحله هرگز آپلود را
	 * متوقف نمی‌کند (فقط لاگ می‌شود).
	 */
	public function on_attachment_metadata_generated( $metadata, $attachment_id ) {
		try {
			$this->duplicate_detector->compute_and_store( (int) $attachment_id );
		} catch ( \Throwable $e ) {
			$this->logger->error( 'media_library', 'خطا در محاسبه‌ی خودکار هش محتوا: ' . $e->getMessage() );
		}

		return $metadata;
	}

	public function on_attachment_deleted( $attachment_id ): void {
		$attachment_id = (int) $attachment_id;
		delete_post_meta( $attachment_id, Duplicate_Detector::META_HASH );
		delete_post_meta( $attachment_id, Cleanup_Manager::META_STATUS );
		delete_post_meta( $attachment_id, Cleanup_Manager::META_DETAILS );
		delete_post_meta( $attachment_id, Cleanup_Manager::META_SIZE );
		delete_post_meta( $attachment_id, Cleanup_Manager::META_TIME );
	}

	public function get_duplicate_detector(): Duplicate_Detector {
		return $this->duplicate_detector;
	}

	public function get_cleanup_manager(): Cleanup_Manager {
		return $this->cleanup_manager;
	}

	public function get_stats_dashboard(): Stats_Dashboard {
		return $this->stats_dashboard;
	}

	public function get_duplicate_batch_processor(): ?Duplicate_Batch_Processor {
		return $this->duplicate_batch_processor;
	}

	public function get_cleanup_batch_processor(): ?Cleanup_Batch_Processor {
		return $this->cleanup_batch_processor;
	}
}
