<?php
namespace AISEO\Modules\Media_Library;

use AISEO\Helpers\File_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * جمع‌بندی آماری کل کتابخانه‌ی رسانه برای داشبورد ماژول: تعداد و حجم تصاویر،
 * تفکیک فرمت، وضعیت تکراری‌ها، وضعیت سلامت فایل، و حجم پوشه‌ی بکاپ‌های
 * غیرمخرب (aiseo-backups) که بین ماژول‌های بهینه‌سازی/واترمارک/ویرایشگر مشترک است.
 *
 * تمام مقادیر یا از کوئری‌های SQL سبک می‌آیند یا از نتایج از‌پیش‌ذخیره‌شده‌ی
 * Cleanup_Manager/Duplicate_Detector؛ هیچ حلقه‌ی file_exists روی کل کتابخانه اینجا اجرا نمی‌شود.
 */
class Stats_Dashboard {

	private Duplicate_Detector $duplicate_detector;
	private Cleanup_Manager $cleanup_manager;

	public function __construct( Duplicate_Detector $duplicate_detector, Cleanup_Manager $cleanup_manager ) {
		$this->duplicate_detector = $duplicate_detector;
		$this->cleanup_manager    = $cleanup_manager;
	}

	/**
	 * @return array{
	 *   total_images:int,
	 *   format_breakdown:array<string,int>,
	 *   duplicates:array{groups:int, files:int},
	 *   unhashed:int,
	 *   health:array{total:int, scanned:int, ok:int, fixed:int, missing_sizes:int, missing_file:int, total_size:int},
	 *   backup_size:int
	 * }
	 */
	public function get_summary(): array {
		return array(
			'total_images'     => $this->get_total_images(),
			'format_breakdown' => $this->get_format_breakdown(),
			'duplicates'       => $this->duplicate_detector->get_stats(),
			'unhashed'         => $this->duplicate_detector->get_unhashed_count(),
			'health'           => $this->cleanup_manager->get_summary(),
			'backup_size'      => $this->get_backup_size(),
		);
	}

	private function get_total_images(): int {
		global $wpdb;

		return (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_status = 'inherit' AND post_mime_type LIKE 'image/%'"
		);
	}

	/**
	 * تفکیک تعداد تصاویر بر اساس mime_type واقعی ثبت‌شده در جدول posts
	 * (نه پسوند فایل، که می‌تواند گمراه‌کننده باشد).
	 *
	 * @return array<string,int>
	 */
	private function get_format_breakdown(): array {
		global $wpdb;

		$rows = $wpdb->get_results(
			"SELECT post_mime_type AS mime, COUNT(*) AS cnt
			FROM {$wpdb->posts}
			WHERE post_type = 'attachment' AND post_status = 'inherit' AND post_mime_type LIKE 'image/%'
			GROUP BY post_mime_type
			ORDER BY cnt DESC",
			ARRAY_A
		);

		$breakdown = array();
		foreach ( (array) $rows as $row ) {
			$ext               = strtoupper( str_replace( 'image/', '', (string) $row['mime'] ) );
			$breakdown[ $ext ] = (int) $row['cnt'];
		}

		return $breakdown;
	}

	/**
	 * حجم پوشه‌ی بکاپ نسخه‌های اصلی (مشترک بین ماژول‌های بهینه‌سازی/واترمارک/ویرایشگر).
	 */
	private function get_backup_size(): int {
		$upload_dir = wp_get_upload_dir();
		$backup_dir = trailingslashit( $upload_dir['basedir'] ) . 'aiseo-backups/';

		return File_Helper::get_directory_size( $backup_dir );
	}
}
