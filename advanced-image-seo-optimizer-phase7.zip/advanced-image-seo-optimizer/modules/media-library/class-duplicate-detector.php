<?php
namespace AISEO\Modules\Media_Library;

use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تشخیص تصاویر تکراری بر اساس هش محتوای فایل (نه نام یا متادیتا).
 *
 * محاسبه‌ی هش (md5_file) عملیات I/O سنگینی است، پس هرگز به‌صورت مستقیم و همزمان
 * روی کل کتابخانه اجرا نمی‌شود؛ Duplicate_Batch_Processor آن را طبق همان الگوی
 * Queue_Manager فازهای قبل، تکه‌تکه انجام می‌دهد. این کلاس فقط منطق محاسبه/گروه‌بندی
 * را نگه می‌دارد و هیچ وابستگی مستقیمی به صف ندارد (Single Responsibility).
 *
 * هش هر تصویر در postmeta ذخیره می‌شود تا SELECT ... GROUP BY بعدی یک کوئری سبک SQL
 * باشد، نه یک حلقه‌ی سنگین PHP روی کل کتابخانه.
 */
class Duplicate_Detector {

	public const META_HASH = '_aiseo_content_hash';

	private Logger $logger;

	public function __construct( Logger $logger ) {
		$this->logger = $logger;
	}

	public function has_hash( int $attachment_id ): bool {
		return '' !== (string) get_post_meta( $attachment_id, self::META_HASH, true );
	}

	/**
	 * محاسبه و ذخیره‌ی هش محتوای فایل اصلی attachment.
	 * در صورت نبود فایل یا خطا، هش قبلی (اگر وجود دارد) حذف می‌شود تا در گروه‌بندی
	 * گمراه‌کننده نباشد.
	 */
	public function compute_and_store( int $attachment_id ): ?string {
		$file_path = get_attached_file( $attachment_id );

		if ( ! is_string( $file_path ) || '' === $file_path || ! file_exists( $file_path ) ) {
			delete_post_meta( $attachment_id, self::META_HASH );
			return null;
		}

		$hash = md5_file( $file_path );

		if ( false === $hash ) {
			$this->logger->warning( 'media_library', "محاسبه‌ی هش محتوا ناموفق بود: {$file_path}" );
			return null;
		}

		update_post_meta( $attachment_id, self::META_HASH, $hash );

		return $hash;
	}

	/**
	 * تعداد گروه‌های تکراری و مجموع فایل‌های درگیر، فقط با یک کوئری SQL سبک
	 * (بدون بارگذاری خود فایل‌ها).
	 *
	 * @return array{groups:int, files:int}
	 */
	public function get_stats(): array {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS groups_count, COALESCE(SUM(cnt), 0) AS files_count FROM (
					SELECT meta_value, COUNT(*) AS cnt
					FROM {$wpdb->postmeta}
					WHERE meta_key = %s AND meta_value != ''
					GROUP BY meta_value
					HAVING cnt > 1
				) AS grouped",
				self::META_HASH
			),
			ARRAY_A
		);

		return array(
			'groups' => (int) ( $row['groups_count'] ?? 0 ),
			'files'  => (int) ( $row['files_count'] ?? 0 ),
		);
	}

	/**
	 * تعداد تصاویری که هنوز هش نشده‌اند (برای نمایش پیشرفت اسکن).
	 */
	public function get_unhashed_count(): int {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p
				WHERE p.post_type = 'attachment' AND p.post_status = 'inherit' AND p.post_mime_type LIKE %s
				AND NOT EXISTS (
					SELECT 1 FROM {$wpdb->postmeta} pm
					WHERE pm.post_id = p.ID AND pm.meta_key = %s
				)",
				'image/%',
				self::META_HASH
			)
		);
	}

	/**
	 * گروه‌های تکراری به همراه جزئیات نمایشی هر عضو، برای رندر در پنل ادمین.
	 *
	 * @return array<int, array{hash:string, count:int, items:array<int,array>}>
	 */
	public function get_duplicate_groups( int $limit_groups = 30 ): array {
		global $wpdb;

		$limit_groups = max( 1, min( 100, $limit_groups ) );

		$hashes = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT meta_value
				FROM {$wpdb->postmeta}
				WHERE meta_key = %s AND meta_value != ''
				GROUP BY meta_value
				HAVING COUNT(*) > 1
				ORDER BY COUNT(*) DESC
				LIMIT %d",
				self::META_HASH,
				$limit_groups
			)
		);

		$groups = array();

		foreach ( $hashes as $hash ) {
			$attachment_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s",
					self::META_HASH,
					$hash
				)
			);

			$items = array();
			foreach ( $attachment_ids as $attachment_id ) {
				$items[] = $this->to_item( (int) $attachment_id );
			}

			$groups[] = array(
				'hash'  => $hash,
				'count' => count( $items ),
				'items' => $items,
			);
		}

		return $groups;
	}

	private function to_item( int $attachment_id ): array {
		$file_path = get_attached_file( $attachment_id );
		$filesize  = ( is_string( $file_path ) && file_exists( $file_path ) ) ? filesize( $file_path ) : 0;

		return array(
			'id'        => $attachment_id,
			'title'     => get_the_title( $attachment_id ),
			'filename'  => is_string( $file_path ) ? basename( $file_path ) : '',
			'filesize'  => (int) $filesize,
			'url'       => (string) wp_get_attachment_url( $attachment_id ),
			'thumb'     => (string) ( wp_get_attachment_image_url( $attachment_id, 'thumbnail' ) ?: wp_get_attachment_url( $attachment_id ) ),
			'edit_link' => (string) ( get_edit_post_link( $attachment_id, 'raw' ) ?: '' ),
		);
	}
}
