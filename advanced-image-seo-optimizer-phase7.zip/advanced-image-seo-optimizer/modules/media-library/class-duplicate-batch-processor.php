<?php
namespace AISEO\Modules\Media_Library;

use AISEO\Queue_Manager;
use AISEO\Settings;
use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پردازش دسته‌ای محاسبه‌ی هش محتوای کل کتابخانه، برای تغذیه‌ی Duplicate_Detector.
 * دقیقاً هم‌الگوی Watermark_Batch_Processor فاز ۵ / Editor_Batch_Processor فاز ۶:
 * همان Queue_Manager مشترک، این‌بار با item_type='ml_duplicate'.
 */
class Duplicate_Batch_Processor {

	public const ITEM_TYPE = 'ml_duplicate';

	private Queue_Manager $queue_manager;
	private Settings $settings;
	private Logger $logger;
	private Duplicate_Detector $detector;

	public function __construct( Queue_Manager $queue_manager, Settings $settings, Logger $logger, Duplicate_Detector $detector ) {
		$this->queue_manager = $queue_manager;
		$this->settings      = $settings;
		$this->logger        = $logger;
		$this->detector       = $detector;
	}

	/**
	 * فقط تصاویری که هنوز هش نشده‌اند به صف اضافه می‌شوند (نه کل کتابخانه در هر اجرا)،
	 * چون هش‌های موجود پایدارند مگر فایل تغییر کند.
	 */
	public function enqueue_eligible( int $limit = 0 ): int {
		global $wpdb;

		$sql = "SELECT p.ID FROM {$wpdb->posts} p
			WHERE p.post_type = 'attachment' AND p.post_status = 'inherit' AND p.post_mime_type LIKE %s
			AND NOT EXISTS (
				SELECT 1 FROM {$wpdb->postmeta} pm
				WHERE pm.post_id = p.ID AND pm.meta_key = %s
			)
			ORDER BY p.ID ASC";

		$params = array( 'image/%', Duplicate_Detector::META_HASH );

		if ( $limit > 0 ) {
			$sql     .= ' LIMIT %d';
			$params[] = $limit;
		}

		$attachment_ids = $wpdb->get_col( $wpdb->prepare( $sql, $params ) );

		$added = 0;
		foreach ( $attachment_ids as $attachment_id ) {
			if ( $this->queue_manager->enqueue( self::ITEM_TYPE, (int) $attachment_id ) ) {
				++$added;
			}
		}

		$this->logger->info( 'media_library', "اسکن کتابخانه برای هش محتوا انجام شد؛ {$added} تصویر جدید به صف اضافه شد." );

		return $added;
	}

	/**
	 * @return array{processed:int, hashed:int, failed:int, remaining:int, locked:bool}
	 */
	public function process_tick(): array {
		if ( ! $this->queue_manager->acquire_lock( self::ITEM_TYPE, 55 ) ) {
			return array(
				'processed' => 0,
				'hashed'    => 0,
				'failed'    => 0,
				'remaining' => $this->get_stats()['pending'],
				'locked'    => true,
			);
		}

		$chunk_size = $this->settings->get_batch_chunk_size();
		$items      = $this->queue_manager->claim_batch( self::ITEM_TYPE, $chunk_size );

		$hashed = 0;
		$failed = 0;

		foreach ( $items as $item ) {
			$attachment_id = (int) $item->object_id;

			try {
				$hash = $this->detector->compute_and_store( $attachment_id );

				if ( null === $hash ) {
					$this->queue_manager->mark_failed( (int) $item->id, 'فایل یافت نشد یا هش ناموفق بود.' );
					++$failed;
				} else {
					$this->queue_manager->mark_done( (int) $item->id );
					++$hashed;
				}
			} catch ( \Throwable $e ) {
				$this->queue_manager->mark_failed( (int) $item->id, $e->getMessage() );
				++$failed;
			}
		}

		$this->queue_manager->release_lock( self::ITEM_TYPE );

		return array(
			'processed' => count( $items ),
			'hashed'    => $hashed,
			'failed'    => $failed,
			'remaining' => $this->get_stats()['pending'],
			'locked'    => false,
		);
	}

	public function get_stats(): array {
		return $this->queue_manager->get_stats( self::ITEM_TYPE );
	}

	public function reset_completed(): void {
		$this->queue_manager->clear_completed( self::ITEM_TYPE );
	}

	public function retry_failed(): int {
		return $this->queue_manager->retry_failed( self::ITEM_TYPE );
	}
}
