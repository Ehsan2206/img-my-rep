<?php
namespace AISEO\Modules\Media_Library;

use AISEO\Queue_Manager;
use AISEO\Settings;
use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پردازش دسته‌ای اسکن سلامت فایل کتابخانه (فایل گم‌شده / سایز گم‌شده)، طبق همان
 * الگوی Duplicate_Batch_Processor و Watermark_Batch_Processor.
 */
class Cleanup_Batch_Processor {

	public const ITEM_TYPE = 'ml_cleanup';

	private Queue_Manager $queue_manager;
	private Settings $settings;
	private Logger $logger;
	private Cleanup_Manager $cleanup_manager;

	public function __construct( Queue_Manager $queue_manager, Settings $settings, Logger $logger, Cleanup_Manager $cleanup_manager ) {
		$this->queue_manager   = $queue_manager;
		$this->settings        = $settings;
		$this->logger          = $logger;
		$this->cleanup_manager = $cleanup_manager;
	}

	/**
	 * کل کتابخانه به صف اضافه می‌شود (برخلاف هش تکراری، اسکن سلامت باید دوره‌ای دوباره
	 * اجرا شود چون فایل‌ها می‌توانند بعداً به‌خاطر مشکلات هاست/کش گم شوند)؛ Queue_Manager
	 * خودش از اضافه‌شدن دوباره‌ی آیتم‌های در حال انتظار جلوگیری می‌کند.
	 */
	public function enqueue_eligible( int $limit = 0 ): int {
		$args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'posts_per_page' => $limit > 0 ? $limit : -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		);

		$attachment_ids = get_posts( $args );
		$added          = 0;

		foreach ( $attachment_ids as $attachment_id ) {
			if ( $this->queue_manager->enqueue( self::ITEM_TYPE, (int) $attachment_id ) ) {
				++$added;
			}
		}

		$this->logger->info( 'media_library', "اسکن سلامت کتابخانه انجام شد؛ {$added} تصویر به صف اضافه شد." );

		return $added;
	}

	/**
	 * @return array{processed:int, ok:int, fixed:int, missing_sizes:int, missing_file:int, failed:int, remaining:int, locked:bool}
	 */
	public function process_tick(): array {
		if ( ! $this->queue_manager->acquire_lock( self::ITEM_TYPE, 55 ) ) {
			return array(
				'processed'     => 0,
				'ok'            => 0,
				'fixed'         => 0,
				'missing_sizes' => 0,
				'missing_file'  => 0,
				'failed'        => 0,
				'remaining'     => $this->get_stats()['pending'],
				'locked'        => true,
			);
		}

		$chunk_size = $this->settings->get_batch_chunk_size();
		$items      = $this->queue_manager->claim_batch( self::ITEM_TYPE, $chunk_size );

		$counts = array(
			'ok'            => 0,
			'fixed'         => 0,
			'missing_sizes' => 0,
			'missing_file'  => 0,
		);
		$failed = 0;

		foreach ( $items as $item ) {
			$attachment_id = (int) $item->object_id;

			try {
				$result = $this->cleanup_manager->scan_attachment( $attachment_id );
				++$counts[ $result['status'] ];
				$this->queue_manager->mark_done( (int) $item->id );
			} catch ( \Throwable $e ) {
				$this->queue_manager->mark_failed( (int) $item->id, $e->getMessage() );
				++$failed;
			}
		}

		$this->queue_manager->release_lock( self::ITEM_TYPE );

		return array(
			'processed'     => count( $items ),
			'ok'            => $counts['ok'],
			'fixed'         => $counts['fixed'],
			'missing_sizes' => $counts['missing_sizes'],
			'missing_file'  => $counts['missing_file'],
			'failed'        => $failed,
			'remaining'     => $this->get_stats()['pending'],
			'locked'        => false,
		);
	}

	public function get_stats(): array {
		return $this->queue_manager->get_stats( self::ITEM_TYPE );
	}

	public function reset_completed(): void {
		$this->queue_manager->clear_completed( self::ITEM_TYPE );
	}

	public function retry_failed(): int {
		return $this->queue_manager->retry_failed( self::ITEM_TYPE );
	}
}
