<?php
namespace AISEO\Modules\Seo;

use AISEO\Queue_Manager;
use AISEO\Settings;
use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پردازش دسته‌ای تولید متادیتای سئو برای تصاویر قدیمی کتابخانه‌ی رسانه.
 * دقیقاً همان الگوی Modules\Optimization\Batch_Processor فاز ۳ را دنبال می‌کند
 * (صف تکه‌ای + قفل transient) تا از یک موتور Queue مشترک استفاده شود.
 */
class Seo_Batch_Processor {

	public const ITEM_TYPE = 'seo_metadata';

	private Queue_Manager $queue_manager;
	private Settings $settings;
	private Logger $logger;
	private Metadata_Generator $metadata_generator;

	public function __construct( Queue_Manager $queue_manager, Settings $settings, Logger $logger, Metadata_Generator $metadata_generator ) {
		$this->queue_manager      = $queue_manager;
		$this->settings           = $settings;
		$this->logger             = $logger;
		$this->metadata_generator = $metadata_generator;
	}

	public function enqueue_eligible( int $limit = 0 ): int {
		$args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'posts_per_page' => $limit > 0 ? $limit : -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		);

		$attachment_ids = get_posts( $args );
		$added          = 0;

		foreach ( $attachment_ids as $attachment_id ) {
			if ( $this->queue_manager->enqueue( self::ITEM_TYPE, (int) $attachment_id ) ) {
				++$added;
			}
		}

		$this->logger->info( 'seo', "اسکن کتابخانه برای متادیتای سئو انجام شد؛ {$added} تصویر جدید به صف اضافه شد." );

		return $added;
	}

	/**
	 * @return array{processed:int, generated:int, skipped:int, failed:int, remaining:int, locked:bool}
	 */
	public function process_tick( bool $overwrite = false ): array {
		if ( ! $this->queue_manager->acquire_lock( self::ITEM_TYPE, 55 ) ) {
			return array(
				'processed' => 0,
				'generated' => 0,
				'skipped'   => 0,
				'failed'    => 0,
				'remaining' => $this->get_stats()['pending'],
				'locked'    => true,
			);
		}

		$chunk_size = $this->settings->get_batch_chunk_size();
		$items      = $this->queue_manager->claim_batch( self::ITEM_TYPE, $chunk_size );

		$generated = 0;
		$skipped   = 0;
		$failed    = 0;

		foreach ( $items as $item ) {
			try {
				$result = $this->metadata_generator->generate_for_attachment( (int) $item->object_id, $overwrite );
				$this->queue_manager->mark_done( (int) $item->id );

				if ( 'generated' === $result['status'] ) {
					++$generated;
				} else {
					++$skipped;
				}
			} catch ( \Throwable $e ) {
				$this->queue_manager->mark_failed( (int) $item->id, $e->getMessage() );
				++$failed;
			}
		}

		$this->queue_manager->release_lock( self::ITEM_TYPE );

		return array(
			'processed' => count( $items ),
			'generated' => $generated,
			'skipped'   => $skipped,
			'failed'    => $failed,
			'remaining' => $this->get_stats()['pending'],
			'locked'    => false,
		);
	}

	public function get_stats(): array {
		return $this->queue_manager->get_stats( self::ITEM_TYPE );
	}

	public function reset_completed(): void {
		$this->queue_manager->clear_completed( self::ITEM_TYPE );
	}

	public function retry_failed(): int {
		return $this->queue_manager->retry_failed( self::ITEM_TYPE );
	}
}
