<?php
namespace AISEO\Modules\Seo;

use AISEO\Settings;
use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تولید Alt/Title/Caption/Description به‌صورت rule-based (بدون AI/API؛ طبق تصمیم
 * معماری فاز ۱: هسته‌ی سئو کاملاً rule-based است و AI فقط در آینده به‌صورت
 * Strategy جایگزین و opt-in اضافه می‌شود).
 *
 * منبع اطلاعات: نام فایل تمیزشده، عنوان پست والد (اگر تصویر به پستی متصل باشد)،
 * نام سایت، و قالب‌های قابل‌تنظیم کاربر در تنظیمات.
 */
class Metadata_Generator {

	private Settings $settings;
	private Logger $logger;

	public function __construct( Settings $settings, Logger $logger ) {
		$this->settings = $settings;
		$this->logger   = $logger;
	}

	/**
	 * فقط در صورت فعال بودن «تولید خودکار حین آپلود» و بودن attachment از نوع تصویر اجرا می‌شود.
	 * هرگز فیلد از قبل پرشده را بازنویسی نمی‌کند (رفتار پیش‌فرض امن).
	 */
	public function maybe_generate_for_attachment( int $attachment_id ): void {
		if ( ! $this->settings->should_auto_generate_on_upload() ) {
			return;
		}

		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return;
		}

		$this->generate_for_attachment( $attachment_id, false );
	}

	/**
	 * تولید و ذخیره‌ی متادیتا برای یک attachment.
	 *
	 * @param bool $overwrite اگر true باشد، فیلدهای از قبل پرشده هم بازنویسی می‌شوند.
	 * @return array{status:string, fields_updated:string[]}
	 */
	public function generate_for_attachment( int $attachment_id, bool $overwrite = false ): array {
		$post = get_post( $attachment_id );

		if ( ! $post || 'attachment' !== $post->post_type ) {
			return array(
				'status'         => 'skipped',
				'fields_updated' => array(),
			);
		}

		$context        = $this->build_context( $post );
		$fields_updated = array();

		$new_title = $this->render_template( $this->settings->get_seo_title_template(), $context );
		if ( $overwrite || '' === trim( (string) $post->post_title ) || $this->is_raw_filename_title( $post->post_title ) ) {
			if ( '' !== $new_title && $new_title !== $post->post_title ) {
				wp_update_post(
					array(
						'ID'         => $attachment_id,
						'post_title' => $new_title,
					)
				);
				$fields_updated[] = 'title';
			}
		}

		$current_alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
		if ( $overwrite || '' === trim( (string) $current_alt ) ) {
			$new_alt = $this->render_template( $this->settings->get_seo_alt_template(), $context );
			if ( '' !== $new_alt && $new_alt !== $current_alt ) {
				update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $new_alt ) );
				$fields_updated[] = 'alt';
			}
		}

		if ( $overwrite || '' === trim( (string) $post->post_excerpt ) ) {
			$new_caption = $this->render_template( $this->settings->get_seo_caption_template(), $context );
			if ( '' !== $new_caption && $new_caption !== $post->post_excerpt ) {
				wp_update_post(
					array(
						'ID'           => $attachment_id,
						'post_excerpt' => $new_caption,
					)
				);
				$fields_updated[] = 'caption';
			}
		}

		if ( $overwrite || '' === trim( (string) $post->post_content ) ) {
			$new_description = $this->render_template( $this->settings->get_seo_description_template(), $context );
			if ( '' !== $new_description && $new_description !== $post->post_content ) {
				wp_update_post(
					array(
						'ID'           => $attachment_id,
						'post_content' => $new_description,
					)
				);
				$fields_updated[] = 'description';
			}
		}

		if ( ! empty( $fields_updated ) ) {
			$this->logger->info( 'seo', "متادیتای تصویر #{$attachment_id} تولید شد: " . implode( ', ', $fields_updated ) );
		}

		return array(
			'status'         => empty( $fields_updated ) ? 'skipped' : 'generated',
			'fields_updated' => $fields_updated,
		);
	}

	/**
	 * تشخیص عنوانی که همان نام خام فایل است (مثلاً "img-20240101-123456")
	 * تا حتی وقتی «بازنویسی» خاموش است، این نوع عنوان‌های بی‌فایده جایگزین شوند.
	 */
	private function is_raw_filename_title( string $title ): bool {
		$slug_like = (bool) preg_match( '/^[a-z0-9\-_]+$/i', trim( $title ) );
		$looks_like_code = (bool) preg_match( '/(img|dsc|photo|image|screenshot)[\-_]?\d+/i', $title ) || (bool) preg_match( '/^\d{4,}/', $title );
		return $slug_like && ( $looks_like_code || strlen( $title ) > 40 );
	}

	private function build_context( \WP_Post $attachment ): array {
		$filename       = basename( get_attached_file( $attachment->ID ) ?: $attachment->guid );
		$clean_filename = $this->clean_filename( $filename );

		$parent_title = '';
		if ( $attachment->post_parent ) {
			$parent = get_post( $attachment->post_parent );
			if ( $parent ) {
				$parent_title = $parent->post_title;
			}
		}

		return array(
			'filename'     => $clean_filename,
			'parent_title' => $parent_title,
			'site_name'    => get_bloginfo( 'name' ),
			'date'         => get_the_date( '', $attachment->ID ) ?: '',
		);
	}

	/**
	 * پاک‌سازی نام فایل به یک عبارت انسانی خوانا:
	 * حذف پسوند، تبدیل - و _ به فاصله، حذف اعداد/هش‌های بی‌معنی دوربین (IMG_1234, DSC00001)،
	 * حروف اول کلمات بزرگ.
	 */
	public function clean_filename( string $filename ): string {
		$name = pathinfo( $filename, PATHINFO_FILENAME );
		$name = preg_replace( '/-(scaled|\d+x\d+)$/', '', $name );
		$name = str_replace( array( '-', '_', '+' ), ' ', $name );
		$name = preg_replace( '/\b(img|image|dsc|photo|pic|screenshot)(?=\d|\s|$)/i', '', $name );
		$name = preg_replace( '/\b[a-f0-9]{6,}\b/i', '', $name ); // هش‌های آپلود
		$name = preg_replace( '/\b\d{4,}\b/', '', $name );        // اعداد طولانی بی‌معنی (تاریخ/شمارنده)
		$name = preg_replace( '/\s+/', ' ', $name );
		$name = trim( $name );

		if ( '' === $name ) {
			return __( 'تصویر', 'advanced-image-seo-optimizer' );
		}

		return mb_convert_case( $name, MB_CASE_TITLE, 'UTF-8' );
	}

	/**
	 * جایگزینی {placeholder}های قالب با مقادیر واقعی؛ عبارت‌های خالی حذف و فاصله‌های
	 * اضافی جمع می‌شوند تا مثلاً وقتی parent_title خالی است خروجی " - " باقی نماند.
	 */
	private function render_template( string $template, array $context ): string {
		$output = $template;
		foreach ( $context as $key => $value ) {
			$output = str_replace( '{' . $key . '}', $value, $output );
		}

		// حذف جداکننده‌های آویزان ناشی از placeholder خالی (مثلاً "فلان - ")
		$output = preg_replace( '/\s*[-–|]\s*(?=[-–|]|$)/u', '', $output );
		$output = trim( preg_replace( '/\s+/', ' ', $output ) );

		return sanitize_text_field( $output );
	}
}
