<?php
namespace AISEO\Modules\Seo;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * اسکن کتابخانه‌ی رسانه برای تصاویری با Alt خالی یا تکراری.
 * فقط خواندنی است (هیچ تغییری در دیتابیس اعمال نمی‌کند)؛ نتیجه برای نمایش در داشبورد
 * و به‌عنوان راهنما برای اجرای Metadata_Generator روی موارد مشکل‌دار استفاده می‌شود.
 */
class Alt_Checker {

	/**
	 * @return array{
	 *   total:int, missing:int, duplicate:int,
	 *   missing_items:array<int,array{id:int,title:string,edit_link:string}>,
	 *   duplicate_items:array<int,array{id:int,title:string,edit_link:string,alt:string}>
	 * }
	 */
	public function scan( int $limit_items = 200 ): array {
		$attachment_ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'post_status'    => 'inherit',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		$total           = count( $attachment_ids );
		$alt_by_id       = array();
		$missing_items   = array();
		$seen_alt_owners = array(); // alt متن (lowercase) => [attachment_id, ...]

		foreach ( $attachment_ids as $attachment_id ) {
			$alt = trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );
			$alt_by_id[ $attachment_id ] = $alt;

			if ( '' === $alt ) {
				if ( count( $missing_items ) < $limit_items ) {
					$missing_items[] = $this->to_item( $attachment_id, $alt );
				}
				continue;
			}

			$key                       = mb_strtolower( $alt );
			$seen_alt_owners[ $key ][] = $attachment_id;
		}

		$missing_count   = $total - count(
			array_filter(
				$alt_by_id,
				static function ( $alt ) {
					return '' !== $alt;
				}
			)
		);

		$duplicate_items = array();
		$duplicate_count = 0;

		foreach ( $seen_alt_owners as $ids ) {
			if ( count( $ids ) < 2 ) {
				continue;
			}
			$duplicate_count += count( $ids );
			foreach ( $ids as $attachment_id ) {
				if ( count( $duplicate_items ) < $limit_items ) {
					$duplicate_items[] = $this->to_item( $attachment_id, $alt_by_id[ $attachment_id ] );
				}
			}
		}

		return array(
			'total'           => $total,
			'missing'         => $missing_count,
			'duplicate'       => $duplicate_count,
			'missing_items'   => $missing_items,
			'duplicate_items' => $duplicate_items,
		);
	}

	private function to_item( int $attachment_id, string $alt ): array {
		return array(
			'id'        => $attachment_id,
			'title'     => get_the_title( $attachment_id ),
			'edit_link' => get_edit_post_link( $attachment_id, 'raw' ) ?: '',
			'alt'       => $alt,
		);
	}
}
