<?php
namespace AISEO\Modules\Seo;

use AISEO\Settings;
use AISEO\Logger;
use AISEO\Queue_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * نقطه‌ی ورود ماژول سئوی تصویر (فاز ۴).
 * مسئولیت: ساخت و سیم‌کشی سرویس‌های داخلی (Metadata_Generator، Alt_Checker،
 * Rename_Engine، Sitemap_Generator، Seo_Scorer، Seo_Batch_Processor) و ثبت هوک‌ها.
 * طبق اصل معماری «هر ماژول خودبسنده»: غیرفعال بودن این ماژول تأثیری روی
 * بهینه‌سازی/واترمارک/ویرایشگر ندارد.
 */
class Seo_Engine {

	private Settings $settings;
	private Logger $logger;

	private Metadata_Generator $metadata_generator;
	private Alt_Checker $alt_checker;
	private Rename_Engine $rename_engine;
	private Sitemap_Generator $sitemap_generator;
	private Seo_Scorer $scorer;
	private ?Seo_Batch_Processor $batch_processor = null;

	public function __construct( Settings $settings, Logger $logger, ?Queue_Manager $queue_manager = null ) {
		$this->settings = $settings;
		$this->logger   = $logger;

		$this->metadata_generator = new Metadata_Generator( $settings, $logger );
		$this->alt_checker        = new Alt_Checker();
		$this->rename_engine      = new Rename_Engine( $logger );
		$this->sitemap_generator  = new Sitemap_Generator( $logger );
		$this->scorer             = new Seo_Scorer();

		if ( null !== $queue_manager ) {
			$this->batch_processor = new Seo_Batch_Processor( $queue_manager, $settings, $logger, $this->metadata_generator );
		}
	}

	public function boot(): void {
		// تولید خودکار Alt/Title/Caption/Description بلافاصله بعد از این‌که سایزهای
		// تصویر ساخته شدند (یعنی وقتی متادیتای کامل و فایل نهایی آماده است).
		add_filter( 'wp_generate_attachment_metadata', array( $this, 'on_attachment_metadata_generated' ), 20, 2 );

		$this->logger->info( 'seo', 'ماژول سئوی تصویر فعال شد (فاز ۴).' );
	}

	/**
	 * هوک روی wp_generate_attachment_metadata: خود متادیتا را دست‌نخورده برمی‌گرداند
	 * (فیلتر فقط برای گرفتن نقطه‌ی امن بعد از آماده شدن تصویر استفاده شده)،
	 * تولید Alt/Title/... به‌صورت جانبی (side effect) انجام می‌شود.
	 */
	public function on_attachment_metadata_generated( $metadata, $attachment_id ) {
		try {
			$this->metadata_generator->maybe_generate_for_attachment( (int) $attachment_id );
		} catch ( \Throwable $e ) {
			$this->logger->error( 'seo', 'خطا در تولید خودکار متادیتای سئو: ' . $e->getMessage() );
		}

		return $metadata;
	}

	public function get_metadata_generator(): Metadata_Generator {
		return $this->metadata_generator;
	}

	public function get_alt_checker(): Alt_Checker {
		return $this->alt_checker;
	}

	public function get_rename_engine(): Rename_Engine {
		return $this->rename_engine;
	}

	public function get_sitemap_generator(): Sitemap_Generator {
		return $this->sitemap_generator;
	}

	public function get_scorer(): Seo_Scorer {
		return $this->scorer;
	}

	public function get_batch_processor(): ?Seo_Batch_Processor {
		return $this->batch_processor;
	}
}
