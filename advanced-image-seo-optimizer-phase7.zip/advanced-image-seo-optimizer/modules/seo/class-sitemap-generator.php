<?php
namespace AISEO\Modules\Seo;

use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تولید Sitemap تصویری استاندارد (پروتکل image sitemap گوگل) به‌صورت کاملاً محلی:
 * فایل XML مستقیماً در پوشه‌ی uploads نوشته می‌شود و از همان مسیر عمومی در دسترس است؛
 * بدون rewrite rule اضافه و بدون هیچ سرویس بیرونی، طبق اصل «بدون وابستگی خارجی» فاز ۱.
 */
class Sitemap_Generator {

	private const FILENAME = 'aiseo-image-sitemap.xml';
	private const MAX_IMAGES = 5000; // سقف ایمن برای جلوگیری از فایل غول‌پیکر/تایم‌اوت روی هاست ضعیف

	private Logger $logger;

	public function __construct( Logger $logger ) {
		$this->logger = $logger;
	}

	/**
	 * @return array{status:string, url?:string, images?:int, message?:string}
	 */
	public function generate(): array {
		$upload_dir = wp_get_upload_dir();

		if ( ! empty( $upload_dir['error'] ) ) {
			return array(
				'status'  => 'failed',
				'message' => __( 'پوشه‌ی uploads قابل دسترسی نیست.', 'advanced-image-seo-optimizer' ),
			);
		}

		$groups = $this->collect_groups();
		$xml    = $this->build_xml( $groups['entries'] );

		$path = trailingslashit( $upload_dir['basedir'] ) . self::FILENAME;

		if ( false === @file_put_contents( $path, $xml ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return array(
				'status'  => 'failed',
				'message' => __( 'نوشتن فایل sitemap ناموفق بود (بررسی دسترسی نوشتن در uploads).', 'advanced-image-seo-optimizer' ),
			);
		}

		update_option( 'aiseo_seo_sitemap_generated_at', current_time( 'mysql' ) );
		update_option( 'aiseo_seo_sitemap_image_count', $groups['image_count'] );

		$this->logger->info( 'seo', "نقشه سایت تصویری ساخته شد: {$groups['image_count']} تصویر." );

		return array(
			'status' => 'generated',
			'url'    => trailingslashit( $upload_dir['baseurl'] ) . self::FILENAME,
			'images' => $groups['image_count'],
		);
	}

	public function get_public_url(): string {
		$upload_dir = wp_get_upload_dir();
		$path       = trailingslashit( $upload_dir['basedir'] ) . self::FILENAME;

		if ( ! file_exists( $path ) ) {
			return '';
		}

		return trailingslashit( $upload_dir['baseurl'] ) . self::FILENAME;
	}

	public function get_last_generated(): string {
		return (string) get_option( 'aiseo_seo_sitemap_generated_at', '' );
	}

	public function get_last_image_count(): int {
		return (int) get_option( 'aiseo_seo_sitemap_image_count', 0 );
	}

	/**
	 * تصاویر را بر اساس صفحه‌ی میزبان (پست والد یا صفحه‌ی خود attachment) گروه‌بندی می‌کند
	 * چون پروتکل sitemap تصویری هر <url> را یک‌بار با چند <image:image> داخلش می‌خواهد.
	 *
	 * @return array{entries: array<string, array{loc:string, images: array<int,array{loc:string,title:string,caption:string}>}>, image_count:int}
	 */
	private function collect_groups(): array {
		$attachment_ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'post_status'    => 'inherit',
				'posts_per_page' => self::MAX_IMAGES,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		$entries      = array();
		$image_count  = 0;

		foreach ( $attachment_ids as $attachment_id ) {
			$image_url = wp_get_attachment_url( $attachment_id );
			if ( ! $image_url ) {
				continue;
			}

			$parent_id = (int) get_post_field( 'post_parent', $attachment_id );
			$page_url  = '';

			if ( $parent_id && 'publish' === get_post_status( $parent_id ) ) {
				$page_url = get_permalink( $parent_id );
			}

			if ( ! $page_url ) {
				$page_url = get_permalink( $attachment_id ) ?: $image_url;
			}

			$title   = get_the_title( $attachment_id );
			$caption = get_post_field( 'post_excerpt', $attachment_id );

			if ( ! isset( $entries[ $page_url ] ) ) {
				$entries[ $page_url ] = array(
					'loc'    => $page_url,
					'images' => array(),
				);
			}

			$entries[ $page_url ]['images'][] = array(
				'loc'     => $image_url,
				'title'   => $title,
				'caption' => is_string( $caption ) ? $caption : '',
			);
			++$image_count;
		}

		return array(
			'entries'     => $entries,
			'image_count' => $image_count,
		);
	}

	private function build_xml( array $entries ): string {
		$xml = new \XMLWriter();
		$xml->openMemory();
		$xml->setIndent( true );
		$xml->startDocument( '1.0', 'UTF-8' );
		$xml->startElement( 'urlset' );
		$xml->writeAttribute( 'xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9' );
		$xml->writeAttribute( 'xmlns:image', 'http://www.google.com/schemas/sitemap-image/1.1' );

		foreach ( $entries as $entry ) {
			$xml->startElement( 'url' );
			$xml->writeElement( 'loc', $entry['loc'] );

			foreach ( $entry['images'] as $image ) {
				$xml->startElement( 'image:image' );
				$xml->writeElement( 'image:loc', $image['loc'] );
				if ( '' !== $image['title'] ) {
					$xml->writeElement( 'image:title', $image['title'] );
				}
				if ( '' !== $image['caption'] ) {
					$xml->writeElement( 'image:caption', $image['caption'] );
				}
				$xml->endElement(); // image:image
			}

			$xml->endElement(); // url
		}

		$xml->endElement(); // urlset
		$xml->endDocument();

		return $xml->outputMemory();
	}
}
