<?php
namespace AISEO\Modules\Seo;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * امتیازدهی ۰ تا ۱۰۰ به وضعیت سئوی هر تصویر بر اساس معیارهای ساده و شفاف
 * (بدون هوش مصنوعی). هدف: نمایش سریع «کجای کتابخانه ضعیف است»، نه یک الگوریتم رتبه‌بندی دقیق گوگل.
 */
class Seo_Scorer {

	private const WEIGHTS = array(
		'alt'         => 35,
		'title'       => 15,
		'caption'     => 15,
		'description' => 15,
		'filename'    => 20,
	);

	public function score_attachment( int $attachment_id ): int {
		$post = get_post( $attachment_id );
		if ( ! $post ) {
			return 0;
		}

		$score = 0;

		$alt = trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );
		if ( '' !== $alt && mb_strlen( $alt ) >= 5 ) {
			$score += self::WEIGHTS['alt'];
		}

		if ( '' !== trim( (string) $post->post_title ) && ! $this->looks_like_raw_filename( $post->post_title ) ) {
			$score += self::WEIGHTS['title'];
		}

		if ( '' !== trim( (string) $post->post_excerpt ) ) {
			$score += self::WEIGHTS['caption'];
		}

		if ( '' !== trim( (string) $post->post_content ) ) {
			$score += self::WEIGHTS['description'];
		}

		$file = get_attached_file( $attachment_id );
		if ( $file ) {
			$basename = pathinfo( $file, PATHINFO_FILENAME );
			if ( ! $this->looks_like_raw_filename( $basename ) ) {
				$score += self::WEIGHTS['filename'];
			}
		}

		return (int) min( 100, $score );
	}

	private function looks_like_raw_filename( string $value ): bool {
		return (bool) preg_match( '/(img|dsc|photo|screenshot)[\-_]?\d+/i', $value )
			|| (bool) preg_match( '/^\d{4,}$/', trim( $value ) )
			|| (bool) preg_match( '/^[a-f0-9]{8,}$/i', trim( $value ) );
	}

	/**
	 * میانگین امتیاز کل کتابخانه + توزیع (ضعیف/متوسط/خوب) برای نمایش داشبورد.
	 * روی گالری‌های بزرگ، حداکثر روی $sample_limit تصویر (جدیدترین‌ها) محاسبه می‌شود
	 * تا این متد سنگین نشود؛ برای گزارش دقیق باید از پردازش دسته‌ای استفاده کرد.
	 *
	 * @return array{average:int, sampled:int, total:int, poor:int, fair:int, good:int}
	 */
	public function get_library_summary( int $sample_limit = 300 ): array {
		$total = (int) wp_count_posts( 'attachment' )->inherit;

		$ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'post_status'    => 'inherit',
				'posts_per_page' => $sample_limit,
				'orderby'        => 'ID',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		$sum  = 0;
		$poor = 0;
		$fair = 0;
		$good = 0;

		foreach ( $ids as $id ) {
			$s = $this->score_attachment( (int) $id );
			$sum += $s;

			if ( $s < 40 ) {
				++$poor;
			} elseif ( $s < 75 ) {
				++$fair;
			} else {
				++$good;
			}
		}

		$sampled = count( $ids );

		return array(
			'average' => $sampled > 0 ? (int) round( $sum / $sampled ) : 0,
			'sampled' => $sampled,
			'total'   => $total,
			'poor'    => $poor,
			'fair'    => $fair,
			'good'    => $good,
		);
	}
}
