<?php
namespace AISEO\Modules\Seo;

use AISEO\Logger;
use AISEO\Helpers\File_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تغییر نام فایل فیزیکی تصویر به یک نام دوستدار سئو (slug)، هم‌راستا با
 * نکته‌ی امنیتی فاز ۱ (sanitize مسیر، جلوگیری از Path Traversal) با عبور
 * تمام عملیات فایل از File_Helper.
 *
 * نسخه‌های thumbnail ثبت‌شده در _wp_attachment_metadata و فایل‌های خواهر
 * WebP/AVIF (ساخته‌شده توسط ماژول بهینه‌سازی) هم به‌صورت best-effort
 * هم‌نام‌سازی می‌شوند تا لینک شکسته ایجاد نشود.
 */
class Rename_Engine {

	private Logger $logger;

	public function __construct( Logger $logger ) {
		$this->logger = $logger;
	}

	/**
	 * ساخت slug پیشنهادی بر اساس Alt یا عنوان attachment (اولویت با Alt چون
	 * معمولاً توصیفی‌تر است)، با fallback به نام فعلی فایل.
	 */
	public function suggest_slug( int $attachment_id ): string {
		$alt = trim( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );
		$title = get_the_title( $attachment_id );

		$source = '' !== $alt ? $alt : $title;

		if ( '' === trim( (string) $source ) ) {
			$file   = get_attached_file( $attachment_id );
			$source = $file ? pathinfo( $file, PATHINFO_FILENAME ) : 'image';
		}

		$slug = sanitize_title( $source );
		return '' !== $slug ? $slug : 'image-' . $attachment_id;
	}

	/**
	 * @return array{status:string, old_url?:string, new_url?:string, message?:string}
	 */
	public function rename_attachment( int $attachment_id, string $desired_slug = '' ): array {
		$file = get_attached_file( $attachment_id );

		if ( ! $file || ! file_exists( $file ) ) {
			return array(
				'status'  => 'failed',
				'message' => __( 'فایل اصلی روی سرور پیدا نشد.', 'advanced-image-seo-optimizer' ),
			);
		}

		if ( ! File_Helper::is_within_uploads( $file ) ) {
			return array(
				'status'  => 'failed',
				'message' => __( 'مسیر فایل خارج از پوشه‌ی مجاز uploads است.', 'advanced-image-seo-optimizer' ),
			);
		}

		$slug = '' !== $desired_slug ? sanitize_title( $desired_slug ) : $this->suggest_slug( $attachment_id );
		$dir  = dirname( $file );
		$ext  = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
		$current_basename = pathinfo( $file, PATHINFO_FILENAME );

		if ( $slug === $current_basename ) {
			return array(
				'status'  => 'skipped',
				'message' => __( 'نام فایل از قبل بهینه است.', 'advanced-image-seo-optimizer' ),
			);
		}

		$new_basename = $this->make_unique_basename( $dir, $slug, $ext, $attachment_id );
		$new_file     = trailingslashit( $dir ) . $new_basename . '.' . $ext;

		if ( ! File_Helper::safe_move( $file, $new_file ) ) {
			return array(
				'status'  => 'failed',
				'message' => __( 'جابه‌جایی فایل ناموفق بود (بررسی دسترسی نوشتن در پوشه‌ی uploads).', 'advanced-image-seo-optimizer' ),
			);
		}

		$this->rename_sibling_formats( $dir, $current_basename, $new_basename );
		$this->rename_registered_sizes( $attachment_id, $dir, $current_basename, $new_basename );

		$upload_dir = wp_get_upload_dir();
		$relative   = ltrim( str_replace( $upload_dir['basedir'], '', $new_file ), '/\\' );
		update_post_meta( $attachment_id, '_wp_attached_file', $relative );

		$old_url = wp_get_attachment_url( $attachment_id );
		clean_post_cache( $attachment_id );
		$new_url = wp_get_attachment_url( $attachment_id );

		$this->logger->info( 'seo', "فایل تصویر #{$attachment_id} به «{$new_basename}.{$ext}» تغییر نام یافت." );

		return array(
			'status'  => 'renamed',
			'old_url' => $old_url,
			'new_url' => $new_url,
		);
	}

	/**
	 * فایل‌های WebP/AVIF خواهر (ساخته‌شده توسط ماژول بهینه‌سازی، هم‌نام با فایل اصلی
	 * ولی پسوند متفاوت) را هم‌نام می‌کند تا بعد از تغییر نام دچار ۴۰۴ نشوند.
	 * best-effort است: شکست در این مرحله باعث شکست کل عملیات نمی‌شود.
	 */
	private function rename_sibling_formats( string $dir, string $old_basename, string $new_basename ): void {
		foreach ( array( 'webp', 'avif' ) as $sibling_ext ) {
			$old_sibling = trailingslashit( $dir ) . $old_basename . '.' . $sibling_ext;
			if ( file_exists( $old_sibling ) ) {
				$new_sibling = trailingslashit( $dir ) . $new_basename . '.' . $sibling_ext;
				File_Helper::safe_move( $old_sibling, $new_sibling );
			}
		}
	}

	/**
	 * نسخه‌های thumbnail/medium/large ثبت‌شده در _wp_attachment_metadata را هم‌نام
	 * می‌کند و خود متادیتا را با نام‌های جدید به‌روزرسانی می‌کند.
	 */
	private function rename_registered_sizes( int $attachment_id, string $dir, string $old_basename, string $new_basename ): void {
		$metadata = wp_get_attachment_metadata( $attachment_id );

		if ( empty( $metadata['sizes'] ) || ! is_array( $metadata['sizes'] ) ) {
			return;
		}

		foreach ( $metadata['sizes'] as $size_key => &$size_data ) {
			if ( empty( $size_data['file'] ) ) {
				continue;
			}

			$old_size_file = $size_data['file'];
			// انتظار الگوی old-basename-{w}x{h}.ext را داریم؛ اگر تطبیق نداشت دست‌نخورده رد می‌شویم.
			if ( 0 !== strpos( $old_size_file, $old_basename . '-' ) ) {
				continue;
			}

			$new_size_file = $new_basename . substr( $old_size_file, strlen( $old_basename ) );
			$old_path      = trailingslashit( $dir ) . $old_size_file;
			$new_path      = trailingslashit( $dir ) . $new_size_file;

			if ( file_exists( $old_path ) && File_Helper::safe_move( $old_path, $new_path ) ) {
				$size_data['file'] = $new_size_file;
				$this->rename_sibling_formats( $dir, pathinfo( $old_size_file, PATHINFO_FILENAME ), pathinfo( $new_size_file, PATHINFO_FILENAME ) );
			}
		}
		unset( $size_data );

		if ( ! empty( $metadata['file'] ) ) {
			$metadata['file'] = preg_replace( '/' . preg_quote( $old_basename, '/' ) . '(?=\.[a-z0-9]+$)/i', $new_basename, $metadata['file'] );
		}

		wp_update_attachment_metadata( $attachment_id, $metadata );
	}

	/**
	 * جلوگیری از تداخل نام با فایل دیگری که همان slug را دارد (رقابت attachment های
	 * مختلف روی یک alt/title مشابه).
	 */
	private function make_unique_basename( string $dir, string $slug, string $ext, int $attachment_id ): string {
		$basename = $slug;
		$counter  = 2;

		while ( file_exists( trailingslashit( $dir ) . $basename . '.' . $ext ) ) {
			$basename = $slug . '-' . $counter;
			++$counter;

			if ( $counter > 200 ) { // محافظ در برابر حلقه‌ی بی‌پایان در حالت‌های غیرمنتظره
				$basename = $slug . '-' . $attachment_id;
				break;
			}
		}

		return $basename;
	}
}
