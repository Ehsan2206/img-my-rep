<?php
namespace AISEO\Modules\Editor;

use AISEO\Server_Capabilities;
use AISEO\Helpers\File_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلاس Context الگوی Strategy: بین Canvas_GD و Canvas_Imagick بر اساس Server_Capabilities
 * انتخاب می‌کند (دقیقاً هم‌الگوی Image_Converter فاز ۳ و Watermark_Renderer فاز ۵).
 *
 * این کلاس عمداً «کور» به مفهوم snapshot/undo است: فقط یک عملیات را روی یک فایل مشخص
 * اجرا می‌کند و ابعاد جدید را برمی‌گرداند. مدیریت نسخه‌ها بر عهده‌ی Editor_History است
 * (همان جدایی که در فاز ۵ بین Watermark_Renderer و Watermark_Rules دیده شده).
 */
class Editor_Renderer {

	private const ALLOWED_OPS = array( 'crop', 'resize', 'rotate', 'flip', 'filter' );

	private Server_Capabilities $server_capabilities;
	private array $strategies;

	public function __construct( Server_Capabilities $server_capabilities ) {
		$this->server_capabilities = $server_capabilities;
		$this->strategies          = array(
			'imagick' => new Canvas_Imagick(),
			'gd'      => new Canvas_GD(),
		);
	}

	/**
	 * @return array{width:int,height:int}|\WP_Error
	 */
	public function apply( string $file_path, string $op, array $args ) {
		if ( ! in_array( $op, self::ALLOWED_OPS, true ) ) {
			return new \WP_Error( 'aiseo_editor_unknown_op', 'عملیات ویرایش ناشناخته: ' . $op );
		}

		if ( ! file_exists( $file_path ) ) {
			return new \WP_Error( 'aiseo_editor_file_missing', 'فایل یافت نشد.' );
		}

		if ( ! File_Helper::is_within_uploads( $file_path ) ) {
			return new \WP_Error( 'aiseo_editor_path_invalid', 'مسیر فایل خارج از پوشه‌ی uploads است.' );
		}

		$strategy = $this->pick_strategy();
		if ( null === $strategy ) {
			return new \WP_Error( 'aiseo_editor_no_strategy', 'هیچ کتابخانه‌ی تصویری (GD/Imagick) برای ویرایش در دسترس نیست.' );
		}

		return $strategy->apply( $file_path, $op, $args );
	}

	private function pick_strategy(): ?Editor_Canvas_Interface {
		$caps = $this->server_capabilities->detect();

		if ( ! empty( $caps['imagick']['available'] ) && $this->strategies['imagick']->supports() ) {
			return $this->strategies['imagick'];
		}
		if ( ! empty( $caps['gd']['available'] ) && $this->strategies['gd']->supports() ) {
			return $this->strategies['gd'];
		}
		return null;
	}
}
