<?php
namespace AISEO\Modules\Editor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پیاده‌سازی عملیات ویرایش تصویر با Imagick.
 * کیفیت resize/rotate و فیلترها (به‌ویژه threshold سیاه‌وسفید و brightness/contrast واقعی)
 * به‌مراتب بهتر و سریع‌تر از GD است؛ طبق Server_Capabilities در اولویت است.
 */
class Canvas_Imagick implements Editor_Canvas_Interface {

	public function supports(): bool {
		return class_exists( '\Imagick' );
	}

	public function apply( string $file_path, string $op, array $args ) {
		if ( ! $this->supports() ) {
			return new \WP_Error( 'aiseo_editor_no_imagick', 'Imagick روی این سرور در دسترس نیست.' );
		}

		try {
			$image = new \Imagick( $file_path );

			switch ( $op ) {
				case 'crop':
					$this->do_crop( $image, $args );
					break;
				case 'resize':
					$this->do_resize( $image, $args );
					break;
				case 'rotate':
					$this->do_rotate( $image, $args );
					break;
				case 'flip':
					$this->do_flip( $image, $args );
					break;
				case 'filter':
					$this->do_filter( $image, $args );
					break;
				default:
					$image->clear();
					$image->destroy();
					return new \WP_Error( 'aiseo_editor_unknown_op', 'عملیات ویرایش ناشناخته: ' . $op );
			}

			$width  = $image->getImageWidth();
			$height = $image->getImageHeight();

			$quality = max( 1, min( 100, (int) ( $args['quality'] ?? 90 ) ) );
			if ( in_array( $image->getImageFormat(), array( 'JPEG', 'WEBP' ), true ) ) {
				$image->setImageCompressionQuality( $quality );
			}

			$image->writeImage( $file_path );
			$image->clear();
			$image->destroy();
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'aiseo_editor_imagick_failed', 'اجرای عملیات ویرایش (' . $op . ') با Imagick شکست خورد: ' . $e->getMessage() );
		}

		return array( 'width' => $width, 'height' => $height );
	}

	private function do_crop( \Imagick $image, array $args ): void {
		$x = max( 0, (int) ( $args['x'] ?? 0 ) );
		$y = max( 0, (int) ( $args['y'] ?? 0 ) );
		$w = max( 1, (int) ( $args['width'] ?? $image->getImageWidth() ) );
		$h = max( 1, (int) ( $args['height'] ?? $image->getImageHeight() ) );

		$image->cropImage( $w, $h, $x, $y );
		// بازنشانی مختصات صفحه‌ی مجازی؛ در غیر این صورت برخی فرمت‌ها آفست قدیمی را نگه می‌دارند.
		$image->setImagePage( $w, $h, 0, 0 );
	}

	private function do_resize( \Imagick $image, array $args ): void {
		$src_w = $image->getImageWidth();
		$src_h = $image->getImageHeight();

		$target_w    = (int) ( $args['width'] ?? $src_w );
		$target_h    = (int) ( $args['height'] ?? $src_h );
		$keep_aspect = ! empty( $args['keep_aspect'] );

		if ( $keep_aspect ) {
			$image->resizeImage( max( 1, $target_w ), max( 1, $target_h ), \Imagick::FILTER_LANCZOS, 1, true );
		} else {
			$image->resizeImage( max( 1, $target_w ), max( 1, $target_h ), \Imagick::FILTER_LANCZOS, 1, false );
		}
	}

	private function do_rotate( \Imagick $image, array $args ): void {
		$degrees = (float) ( $args['degrees'] ?? 0 );
		$transparent = new \ImagickPixel( 'transparent' );
		$image->rotateImage( $transparent, $degrees );
		// چرخش‌های غیر ۹۰/۱۸۰/۲۷۰ درجه صفحه‌ی مجازی را تغییر می‌دهند؛ صریحاً صاف می‌کنیم.
		$image->setImagePage( $image->getImageWidth(), $image->getImageHeight(), 0, 0 );
	}

	private function do_flip( \Imagick $image, array $args ): void {
		$axis = (string) ( $args['axis'] ?? 'horizontal' );
		if ( 'vertical' === $axis ) {
			$image->flipImage();
		} else {
			$image->flopImage();
		}
	}

	private function do_filter( \Imagick $image, array $args ): void {
		$filter = (string) ( $args['filter'] ?? '' );
		$amount = (int) ( $args['amount'] ?? 0 );

		switch ( $filter ) {
			case 'brightness':
				// brightnessContrastImage: هر دو آرگومان -100..100، صفر یعنی بدون تغییر.
				$image->brightnessContrastImage( max( -100, min( 100, $amount ) ), 0 );
				break;
			case 'contrast':
				$image->brightnessContrastImage( 0, max( -100, min( 100, $amount ) ) );
				break;
			case 'grayscale':
				$image->setImageColorspace( \Imagick::COLORSPACE_GRAY );
				break;
			case 'bw':
				$threshold = max( 0, min( 255, $amount > 0 ? $amount : 128 ) );
				$image->setImageColorspace( \Imagick::COLORSPACE_GRAY );
				// thresholdImage مقدار را به مقیاس QuantumRange واقعی این build از ImageMagick
				// (معمولاً Q8=255 یا Q16=65535) نیاز دارد؛ نسبت 0-255 ما به آن نگاشت می‌شود.
				$range = $image->getQuantumRange();
				$quantum_max = is_array( $range ) && ! empty( $range['quantumRangeLong'] ) ? (float) $range['quantumRangeLong'] : 255.0;
				$image->thresholdImage( ( $threshold / 255 ) * $quantum_max );
				break;
		}
	}
}
