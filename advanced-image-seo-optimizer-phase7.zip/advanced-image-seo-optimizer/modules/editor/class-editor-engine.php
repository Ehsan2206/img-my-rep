<?php
namespace AISEO\Modules\Editor;

use AISEO\Settings;
use AISEO\Logger;
use AISEO\Server_Capabilities;
use AISEO\Queue_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * نقطه‌ی ورود ماژول ویرایشگر تصویر پیشرفته (فاز ۶).
 * مسئولیت: ساخت و سیم‌کشی سرویس‌های داخلی (Editor_Renderer، Editor_History،
 * Editor_Batch_Processor) و افزودن دکمه‌ی «ویرایشگر» به کتابخانه‌ی رسانه؛
 * دقیقاً هم‌الگوی Watermark_Engine فاز ۵.
 * طبق اصل «هر ماژول خودبسنده»: غیرفعال بودن این ماژول تأثیری روی بقیه ندارد.
 *
 * برخلاف بهینه‌سازی/سئو/واترمارک، این ماژول روی هیچ هوک آپلودی سوار نمی‌شود (ویرایش
 * تصویر ذاتاً یک اقدام دستی و آگاهانه‌ی کاربر است، نه یک پردازش خودکار پس‌زمینه)؛
 * تنها راه ورودی، دکمه‌ی «ویرایشگر» در کتابخانه‌ی رسانه یا پردازش دسته‌ای اختیاری است.
 */
class Editor_Engine {

	private Settings $settings;
	private Logger $logger;

	private Editor_Renderer $renderer;
	private Editor_History $history;
	private ?Editor_Batch_Processor $batch_processor = null;

	public function __construct( Settings $settings, Logger $logger, Server_Capabilities $server_capabilities, ?Queue_Manager $queue_manager = null ) {
		$this->settings = $settings;
		$this->logger   = $logger;

		$this->renderer = new Editor_Renderer( $server_capabilities );
		$this->history  = new Editor_History( $settings, $logger, $this->renderer );

		if ( null !== $queue_manager ) {
			$this->batch_processor = new Editor_Batch_Processor( $queue_manager, $settings, $logger, $this->history );
		}
	}

	public function boot(): void {
		add_filter( 'attachment_fields_to_edit', array( $this, 'add_editor_field' ), 10, 2 );

		$this->logger->info( 'editor', 'ماژول ویرایشگر تصویر فعال شد (فاز ۶).' );
	}

	public function add_editor_field( array $form_fields, $post ): array {
		if ( ! isset( $post->post_mime_type ) || 0 !== strpos( (string) $post->post_mime_type, 'image/' ) ) {
			return $form_fields;
		}
		if ( 'image/svg+xml' === $post->post_mime_type ) {
			return $form_fields;
		}

		$form_fields['aiseo_editor'] = array(
			'label' => __( 'ویرایشگر تصویر', 'advanced-image-seo-optimizer' ),
			'input' => 'html',
			'html'  => sprintf(
				'<button type="button" class="button aiseo-editor-open" data-attachment-id="%1$d">%2$s</button>',
				(int) $post->ID,
				esc_html__( 'باز کردن ویرایشگر AISEO', 'advanced-image-seo-optimizer' )
			),
		);

		return $form_fields;
	}

	public function get_renderer(): Editor_Renderer {
		return $this->renderer;
	}

	public function get_history(): Editor_History {
		return $this->history;
	}

	public function get_batch_processor(): ?Editor_Batch_Processor {
		return $this->batch_processor;
	}
}
