<?php
namespace AISEO\Modules\Editor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * قرارداد مشترک هر پیاده‌سازی رندر عملیات ویرایش تصویر (Strategy Pattern)،
 * دقیقاً هم‌خانواده‌ی Image_Converter_Interface (فاز ۳) و Watermark_Canvas_Interface (فاز ۵).
 * پیاده‌سازی‌های فعلی: Canvas_GD و Canvas_Imagick.
 *
 * این کلاس فقط مسئول رندر «یک عملیات» روی یک فایل مشخص است؛ گرفتن بکاپ/snapshot
 * پیش از رندر و به‌روزرسانی متادیتای وردپرس پس از رندر بر عهده‌ی Editor_History است
 * (همان جدایی مسئولیتی که در Watermark_Renderer/Watermark_Rules دیده شده).
 */
interface Editor_Canvas_Interface {

	/**
	 * آیا این استراتژی روی سرور فعلی قابل استفاده است؟
	 */
	public function supports(): bool;

	/**
	 * اعمال یک عملیات ویرایش روی فایل تصویر، درجا (فایل مقصد جایگزین فایل مبدا می‌شود).
	 *
	 * @param string $file_path مسیر مطلق فایل تصویر.
	 * @param string $op        نوع عملیات: crop|resize|rotate|flip|filter
	 * @param array  $args      آرگومان‌های اختصاصی هر عملیات، به تفکیک:
	 * {
	 *     // crop
	 *     @type int    $x, $y, $width, $height
	 *     // resize
	 *     @type int    $width, $height
	 *     @type bool   $keep_aspect
	 *     // rotate
	 *     @type float  $degrees        90|180|270 یا زاویه‌ی دلخواه
	 *     // flip
	 *     @type string $axis           horizontal|vertical
	 *     // filter
	 *     @type string $filter         brightness|contrast|grayscale|bw
	 *     @type int    $amount         برای brightness/contrast: -100..100 ، برای bw: آستانه‌ی 0-255
	 *     // مشترک بین همه‌ی عملیات (توسط Editor_History تزریق می‌شود، نه ورودی مستقیم کاربر)
	 *     @type int    $quality        کیفیت خروجی JPEG/WebP، 1-100 (پیش‌فرض 90)
	 * }
	 * @return array{width:int,height:int}|\WP_Error ابعاد جدید تصویر در صورت موفقیت.
	 */
	public function apply( string $file_path, string $op, array $args );
}
