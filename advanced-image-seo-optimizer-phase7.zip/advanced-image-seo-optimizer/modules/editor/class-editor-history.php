<?php
namespace AISEO\Modules\Editor;

use AISEO\Settings;
use AISEO\Logger;
use AISEO\Helpers\File_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تاریخچه‌ی Undo/Redo غیرمخرب برای ویرایشگر تصویر (فاز ۶).
 *
 * طبق تصمیم معماری کلیدی #۴ («Non-destructive editing»): فایل اصلی هرگز مستقیم و
 * بدون قابلیت بازگشت بازنویسی نمی‌شود. برخلاف Backup_Manager فاز ۳ (که فقط یک نسخه‌ی
 * «قبل از تبدیل» نگه می‌دارد) این کلاس یک پشته‌ی کامل از نسخه‌های میانی نگه می‌دارد
 * تا کاربر بتواند هر تعداد Undo/Redo بین ویرایش‌های اخیر انجام دهد:
 *
 * - index 0 همیشه نسخه‌ی اصلی (پیش از اولین ویرایش) است و هرگز حذف نمی‌شود.
 * - هر عملیات موفق یک snapshot جدید بعد از pointer فعلی اضافه می‌کند و هر شاخه‌ی
 *   redo قدیمی (اگر کاربر بعد از چند Undo، ویرایش جدیدی انجام دهد) دور ریخته می‌شود.
 * - سقف تعداد مراحل (aiseo_editor_max_history) رعایت می‌شود؛ در صورت عبور، قدیمی‌ترین
 *   مرحله‌ی غیر از نسخه‌ی اصلی حذف می‌شود تا فضای پوشه‌ی بکاپ بی‌رویه رشد نکند.
 *
 * فایل‌های snapshot در پوشه‌ی محافظت‌شده‌ی همان Backup_Manager فاز ۳ (aiseo-backups/{id}/editor/)
 * نگه‌داری می‌شوند تا از مسیر امن File_Helper و .htaccess موجود بهره ببرند.
 */
class Editor_History {

	private const META_HISTORY = '_aiseo_editor_history';
	private const META_POINTER = '_aiseo_editor_pointer';

	private Settings $settings;
	private Logger $logger;
	private Editor_Renderer $renderer;

	public function __construct( Settings $settings, Logger $logger, Editor_Renderer $renderer ) {
		$this->settings = $settings;
		$this->logger   = $logger;
		$this->renderer = $renderer;
	}

	/**
	 * اجرای یک عملیات ویرایش روی attachment: رندر + ثبت مرحله‌ی جدید در تاریخچه +
	 * بازتولید متادیتا/thumbnail های وردپرس.
	 *
	 * @return array{status:string, message?:string, width?:int, height?:int, state?:array}
	 */
	public function apply_operation( int $attachment_id, string $op, array $args ): array {
		$file_path = get_attached_file( $attachment_id );
		if ( ! is_string( $file_path ) || '' === $file_path || ! file_exists( $file_path ) ) {
			return array( 'status' => 'failed', 'message' => 'فایل attachment یافت نشد.' );
		}

		$this->ensure_baseline( $attachment_id, $file_path );

		// کیفیت خروجی از تنظیمات ماژول تزریق می‌شود، نه از ورودی مستقیم کاربر.
		$args['quality'] = $this->settings->get_editor_jpeg_quality();

		$result = $this->renderer->apply( $file_path, $op, $args );

		if ( is_wp_error( $result ) ) {
			$this->logger->error( 'editor', "خطا در اعمال عملیات «{$op}» روی attachment #{$attachment_id}: " . $result->get_error_message() );
			return array( 'status' => 'failed', 'message' => $result->get_error_message() );
		}

		$this->record_step( $attachment_id, $file_path, $op );
		$this->finalize_metadata( $attachment_id, $file_path );

		$this->logger->info( 'editor', "عملیات «{$op}» روی attachment #{$attachment_id} اعمال شد." );

		return array(
			'status' => 'applied',
			'width'  => $result['width'],
			'height' => $result['height'],
			'state'  => $this->get_state( $attachment_id ),
		);
	}

	public function undo( int $attachment_id ): array {
		$history = $this->get_history( $attachment_id );
		$pointer = $this->get_pointer( $attachment_id );

		if ( $pointer <= 0 || empty( $history[ $pointer - 1 ] ) ) {
			return array( 'status' => 'failed', 'message' => 'مرحله‌ای برای بازگشت وجود ندارد.' );
		}

		return $this->jump_to( $attachment_id, $pointer - 1 );
	}

	public function redo( int $attachment_id ): array {
		$history = $this->get_history( $attachment_id );
		$pointer = $this->get_pointer( $attachment_id );

		if ( empty( $history[ $pointer + 1 ] ) ) {
			return array( 'status' => 'failed', 'message' => 'مرحله‌ای برای بازگشت به جلو وجود ندارد.' );
		}

		return $this->jump_to( $attachment_id, $pointer + 1 );
	}

	public function reset_to_original( int $attachment_id ): array {
		$history = $this->get_history( $attachment_id );

		if ( empty( $history[0]['path'] ) || ! file_exists( $history[0]['path'] ) ) {
			return array( 'status' => 'failed', 'message' => 'نسخه‌ی اصلی برای بازگردانی یافت نشد.' );
		}

		// حذف فایل snapshot تمام مراحل بعد از نسخه‌ی اصلی؛ فقط index 0 باقی می‌ماند.
		foreach ( $history as $index => $step ) {
			if ( 0 === $index ) {
				continue;
			}
			if ( ! empty( $step['path'] ) && file_exists( $step['path'] ) ) {
				@unlink( $step['path'] );
			}
		}

		update_post_meta( $attachment_id, self::META_HISTORY, array( $history[0] ) );
		update_post_meta( $attachment_id, self::META_POINTER, 0 );

		$this->restore_snapshot_to_live( $attachment_id, $history[0]['path'] );

		$this->logger->info( 'editor', "تصویر attachment #{$attachment_id} به نسخه‌ی اصلی بازگردانده شد." );

		return array( 'status' => 'applied', 'state' => $this->get_state( $attachment_id ) );
	}

	/**
	 * وضعیت فعلی تاریخچه برای نمایش در رابط کاربری (دکمه‌های Undo/Redo فعال/غیرفعال و ...).
	 */
	public function get_state( int $attachment_id ): array {
		$history = $this->get_history( $attachment_id );
		$pointer = $this->get_pointer( $attachment_id );
		$count   = count( $history );

		return array(
			'can_undo'    => $pointer > 0,
			'can_redo'    => isset( $history[ $pointer + 1 ] ),
			'steps'       => $count,
			'pointer'     => $pointer,
			'max_history' => $this->settings->get_editor_max_history(),
			'has_edits'   => $count > 1,
		);
	}

	// -------------------------------------------------------------------
	// داخلی
	// -------------------------------------------------------------------

	private function jump_to( int $attachment_id, int $new_pointer ): array {
		$history = $this->get_history( $attachment_id );

		if ( empty( $history[ $new_pointer ]['path'] ) || ! file_exists( $history[ $new_pointer ]['path'] ) ) {
			return array( 'status' => 'failed', 'message' => 'نسخه‌ی موردنظر یافت نشد.' );
		}

		update_post_meta( $attachment_id, self::META_POINTER, $new_pointer );
		$this->restore_snapshot_to_live( $attachment_id, $history[ $new_pointer ]['path'] );

		return array( 'status' => 'applied', 'state' => $this->get_state( $attachment_id ) );
	}

	private function restore_snapshot_to_live( int $attachment_id, string $snapshot_path ): void {
		$live_path = get_attached_file( $attachment_id );
		if ( ! is_string( $live_path ) || '' === $live_path ) {
			return;
		}

		if ( @copy( $snapshot_path, $live_path ) ) {
			$this->finalize_metadata( $attachment_id, $live_path );
		} else {
			$this->logger->warning( 'editor', "بازگردانی snapshot برای attachment #{$attachment_id} ناموفق بود." );
		}
	}

	/**
	 * اگر این اولین باری است که ویرایشگر روی این attachment استفاده می‌شود، نسخه‌ی فعلی
	 * (که هنوز دست‌نخورده است) را به‌عنوان index 0 (baseline) اسنپ‌شات می‌گیرد.
	 */
	private function ensure_baseline( int $attachment_id, string $file_path ): void {
		$history = $this->get_history( $attachment_id );
		if ( ! empty( $history ) ) {
			return;
		}

		$dir  = $this->get_editor_snapshot_dir( $attachment_id );
		$path = $dir . 'step-0-' . basename( $file_path );

		if ( @copy( $file_path, $path ) ) {
			update_post_meta(
				$attachment_id,
				self::META_HISTORY,
				array(
					array(
						'path'       => $path,
						'label'      => 'original',
						'created_at' => time(),
					),
				)
			);
			update_post_meta( $attachment_id, self::META_POINTER, 0 );
		} else {
			$this->logger->warning( 'editor', "گرفتن نسخه‌ی اصلی (baseline) برای attachment #{$attachment_id} ناموفق بود." );
		}
	}

	/**
	 * پس از اعمال موفق یک عملیات، وضعیت فعلی فایل را به‌عنوان مرحله‌ی جدید ثبت می‌کند.
	 * هر شاخه‌ی redo قدیمی (مراحل بعد از pointer فعلی) دور ریخته می‌شود.
	 */
	private function record_step( int $attachment_id, string $current_file_path, string $op_label ): void {
		$history = $this->get_history( $attachment_id );
		$pointer = $this->get_pointer( $attachment_id );

		// حذف فایل‌های شاخه‌ی redo که دیگر معتبر نیستند (کاربر بعد از Undo، ویرایش جدید کرده).
		for ( $i = $pointer + 1; $i < count( $history ); $i++ ) {
			if ( ! empty( $history[ $i ]['path'] ) && file_exists( $history[ $i ]['path'] ) ) {
				@unlink( $history[ $i ]['path'] );
			}
		}
		$history = array_slice( $history, 0, $pointer + 1 );

		$dir  = $this->get_editor_snapshot_dir( $attachment_id );
		$step_no = count( $history );
		$path = $dir . 'step-' . $step_no . '-' . time() . '-' . basename( $current_file_path );

		if ( ! @copy( $current_file_path, $path ) ) {
			$this->logger->warning( 'editor', "ثبت مرحله‌ی جدید تاریخچه برای attachment #{$attachment_id} ناموفق بود." );
			return;
		}

		$history[] = array(
			'path'       => $path,
			'label'      => $op_label,
			'created_at' => time(),
		);
		$pointer = count( $history ) - 1;

		$max_history = $this->settings->get_editor_max_history();
		// index 0 (نسخه‌ی اصلی) همیشه حفظ می‌شود؛ فقط تعداد مراحل بعد از آن به سقف محدود می‌شود.
		while ( count( $history ) - 1 > $max_history ) {
			if ( ! empty( $history[1]['path'] ) && file_exists( $history[1]['path'] ) ) {
				@unlink( $history[1]['path'] );
			}
			array_splice( $history, 1, 1 );
			--$pointer;
		}

		update_post_meta( $attachment_id, self::META_HISTORY, $history );
		update_post_meta( $attachment_id, self::META_POINTER, max( 0, $pointer ) );
	}

	private function finalize_metadata( int $attachment_id, string $file_path ): void {
		require_once ABSPATH . 'wp-admin/includes/image.php';

		clearstatcache( true, $file_path );

		$metadata = wp_generate_attachment_metadata( $attachment_id, $file_path );
		if ( is_array( $metadata ) ) {
			wp_update_attachment_metadata( $attachment_id, $metadata );
		}
	}

	private function get_history( int $attachment_id ): array {
		$history = get_post_meta( $attachment_id, self::META_HISTORY, true );
		return is_array( $history ) ? array_values( $history ) : array();
	}

	private function get_pointer( int $attachment_id ): int {
		return (int) get_post_meta( $attachment_id, self::META_POINTER, true );
	}

	private function get_editor_snapshot_dir( int $attachment_id ): string {
		$dir = File_Helper::get_backup_dir( $attachment_id ) . 'editor/';
		if ( ! file_exists( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		return $dir;
	}
}
