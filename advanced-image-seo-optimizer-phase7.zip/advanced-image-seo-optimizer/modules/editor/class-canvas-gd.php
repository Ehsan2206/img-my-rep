<?php
namespace AISEO\Modules\Editor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پیاده‌سازی عملیات ویرایش تصویر با GD.
 * فیلتر «سیاه‌وسفید» (bw) در GD معادل مستقیم ندارد؛ به‌صورت دستی با پیمایش پیکسل‌ها
 * پیاده‌سازی شده (imagefilter فقط GRAYSCALE دارد، نه threshold). روی تصاویر خیلی بزرگ
 * ممکن است کمی کند باشد؛ این محدودیت شناخته‌شده‌ی GD نسبت به Imagick است.
 */
class Canvas_GD implements Editor_Canvas_Interface {

	private const LOADERS = array(
		'image/jpeg' => 'imagecreatefromjpeg',
		'image/png'  => 'imagecreatefrompng',
		'image/gif'  => 'imagecreatefromgif',
		'image/bmp'  => 'imagecreatefrombmp',
		'image/webp' => 'imagecreatefromwebp',
	);

	public function supports(): bool {
		return function_exists( 'gd_info' );
	}

	public function apply( string $file_path, string $op, array $args ) {
		$mime = $this->detect_mime( $file_path );
		if ( '' === $mime || ! isset( self::LOADERS[ $mime ] ) || ! function_exists( self::LOADERS[ $mime ] ) ) {
			return new \WP_Error( 'aiseo_editor_unsupported_mime', 'نوع فایل توسط GD برای ویرایش پشتیبانی نمی‌شود: ' . $mime );
		}

		$loader = self::LOADERS[ $mime ];
		$image  = @$loader( $file_path );
		if ( false === $image ) {
			return new \WP_Error( 'aiseo_editor_load_failed', 'بارگذاری تصویر با GD شکست خورد: ' . basename( $file_path ) );
		}

		imagepalettetotruecolor( $image );
		imagealphablending( $image, true );
		imagesavealpha( $image, true );

		switch ( $op ) {
			case 'crop':
				$image = $this->do_crop( $image, $args );
				break;
			case 'resize':
				$image = $this->do_resize( $image, $args );
				break;
			case 'rotate':
				$image = $this->do_rotate( $image, $args );
				break;
			case 'flip':
				$this->do_flip( $image, $args );
				break;
			case 'filter':
				$this->do_filter( $image, $args );
				break;
			default:
				imagedestroy( $image );
				return new \WP_Error( 'aiseo_editor_unknown_op', 'عملیات ویرایش ناشناخته: ' . $op );
		}

		if ( false === $image || null === $image ) {
			return new \WP_Error( 'aiseo_editor_op_failed', 'اجرای عملیات ویرایش (' . $op . ') با GD شکست خورد.' );
		}

		$width  = imagesx( $image );
		$height = imagesy( $image );

		$quality = max( 1, min( 100, (int) ( $args['quality'] ?? 90 ) ) );
		$ok      = $this->write( $image, $mime, $file_path, $quality );
		imagedestroy( $image );

		if ( ! $ok ) {
			return new \WP_Error( 'aiseo_editor_write_failed', 'نوشتن فایل ویرایش‌شده با GD شکست خورد.' );
		}

		return array( 'width' => $width, 'height' => $height );
	}

	private function do_crop( $image, array $args ) {
		$rect = array(
			'x'      => max( 0, (int) ( $args['x'] ?? 0 ) ),
			'y'      => max( 0, (int) ( $args['y'] ?? 0 ) ),
			'width'  => max( 1, (int) ( $args['width'] ?? imagesx( $image ) ) ),
			'height' => max( 1, (int) ( $args['height'] ?? imagesy( $image ) ) ),
		);

		$cropped = imagecrop( $image, $rect );
		if ( false === $cropped ) {
			return $image;
		}
		imagedestroy( $image );
		imagesavealpha( $cropped, true );
		return $cropped;
	}

	private function do_resize( $image, array $args ) {
		$src_w = imagesx( $image );
		$src_h = imagesy( $image );

		$target_w = (int) ( $args['width'] ?? $src_w );
		$target_h = (int) ( $args['height'] ?? $src_h );
		$keep_aspect = ! empty( $args['keep_aspect'] );

		if ( $keep_aspect && $src_w > 0 && $src_h > 0 ) {
			$ratio = min( $target_w / $src_w, $target_h / $src_h );
			$target_w = max( 1, (int) round( $src_w * $ratio ) );
			$target_h = max( 1, (int) round( $src_h * $ratio ) );
		}

		$target_w = max( 1, $target_w );
		$target_h = max( 1, $target_h );

		$resized = imagescale( $image, $target_w, $target_h );
		if ( false === $resized ) {
			return $image;
		}
		imagedestroy( $image );
		imagesavealpha( $resized, true );
		return $resized;
	}

	private function do_rotate( $image, array $args ) {
		$degrees = (float) ( $args['degrees'] ?? 0 );
		// imagerotate در GD خلاف‌جهت‌عقربه‌ای می‌چرخاند؛ برای همسو شدن با انتظار کاربر
		// (چرخش ساعت‌گرد مثبت، مثل بقیه‌ی نرم‌افزارهای ویرایش تصویر) علامت را معکوس می‌کنیم.
		$transparent = imagecolorallocatealpha( $image, 0, 0, 0, 127 );
		$rotated     = imagerotate( $image, -$degrees, $transparent );
		if ( false === $rotated ) {
			return $image;
		}
		imagedestroy( $image );
		imagesavealpha( $rotated, true );
		return $rotated;
	}

	private function do_flip( $image, array $args ): void {
		$axis = (string) ( $args['axis'] ?? 'horizontal' );
		$mode = 'vertical' === $axis ? IMG_FLIP_VERTICAL : IMG_FLIP_HORIZONTAL;
		imageflip( $image, $mode );
	}

	private function do_filter( $image, array $args ): void {
		$filter = (string) ( $args['filter'] ?? '' );
		$amount = (int) ( $args['amount'] ?? 0 );

		switch ( $filter ) {
			case 'brightness':
				// GD: -255..255؛ ورودی ما -100..100 است، به مقیاس GD نگاشت می‌شود.
				imagefilter( $image, IMG_FILTER_BRIGHTNESS, (int) round( $amount * 2.55 ) );
				break;
			case 'contrast':
				// GD: مقیاس معکوس (منفی = بیشتر کنتراست)؛ ورودی ما مثبت = بیشتر کنتراست است.
				imagefilter( $image, IMG_FILTER_CONTRAST, (int) round( $amount * -1 ) );
				break;
			case 'grayscale':
				imagefilter( $image, IMG_FILTER_GRAYSCALE );
				break;
			case 'bw':
				$this->apply_threshold( $image, max( 0, min( 255, $amount > 0 ? $amount : 128 ) ) );
				break;
		}
	}

	/**
	 * تبدیل دستی به سیاه‌وسفید دو رنگ (threshold) با پیمایش پیکسل به پیکسل،
	 * چون GD تابع آماده‌ای برای این کار ندارد.
	 */
	private function apply_threshold( $image, int $threshold ): void {
		$w = imagesx( $image );
		$h = imagesy( $image );
		$black = imagecolorallocate( $image, 0, 0, 0 );
		$white = imagecolorallocate( $image, 255, 255, 255 );

		for ( $y = 0; $y < $h; $y++ ) {
			for ( $x = 0; $x < $w; $x++ ) {
				$rgb = imagecolorat( $image, $x, $y );
				$r   = ( $rgb >> 16 ) & 0xFF;
				$g   = ( $rgb >> 8 ) & 0xFF;
				$b   = $rgb & 0xFF;
				$luminance = ( 0.299 * $r ) + ( 0.587 * $g ) + ( 0.114 * $b );
				imagesetpixel( $image, $x, $y, $luminance >= $threshold ? $white : $black );
			}
		}
	}

	private function write( $image, string $mime, string $file_path, int $quality = 90 ): bool {
		switch ( $mime ) {
			case 'image/jpeg':
				return imagejpeg( $image, $file_path, $quality );
			case 'image/png':
				return imagepng( $image, $file_path );
			case 'image/gif':
				return imagegif( $image, $file_path );
			case 'image/bmp':
				return function_exists( 'imagebmp' ) ? imagebmp( $image, $file_path ) : false;
			case 'image/webp':
				return function_exists( 'imagewebp' ) ? imagewebp( $image, $file_path, $quality ) : false;
			default:
				return false;
		}
	}

	/**
	 * تشخیص mime واقعی فایل (نه فقط پسوند) طبق نکته‌ی امنیتی فاز ۱.
	 */
	private function detect_mime( string $file_path ): string {
		$info = @getimagesize( $file_path );
		return is_array( $info ) && isset( $info['mime'] ) ? $info['mime'] : '';
	}
}
