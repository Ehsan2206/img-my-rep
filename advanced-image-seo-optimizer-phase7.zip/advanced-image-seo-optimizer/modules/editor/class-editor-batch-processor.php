<?php
namespace AISEO\Modules\Editor;

use AISEO\Queue_Manager;
use AISEO\Settings;
use AISEO\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * پردازش دسته‌ای ویرایشگر: اعمال یک عملیات ساده و از‌پیش‌انتخاب‌شده (چرخش/فلیپ/گری‌اسکیل/
 * سیاه‌وسفید) روی کل کتابخانه‌ی رسانه یا زیرمجموعه‌ای از آن. دقیقاً همان الگوی
 * Watermark_Batch_Processor فاز ۵ (که خودش از Batch_Processor فاز ۳ گرفته شده) را دنبال
 * می‌کند: همان Queue_Manager مشترک، این‌بار با item_type='editor'.
 *
 * برخلاف ویرایش تعاملی تک‌تصویری (که هر عملیات را جداگانه و آزادانه می‌پذیرد)، پردازش
 * دسته‌ای عمداً محدود به یک عملیات ساده در هر اجرا است تا از اعمال ناخواسته‌ی ترکیب پیچیده‌ای
 * از تغییرات روی صدها تصویر جلوگیری شود. هر آیتم همچنان از طریق Editor_History پردازش
 * می‌شود، پس نتیجه‌ی پردازش دسته‌ای هم مثل ویرایش تعاملی غیرمخرب و قابل Undo است.
 */
class Editor_Batch_Processor {

	public const ITEM_TYPE = 'editor';

	/**
	 * نگاشت کلید عملیات دسته‌ای (تنظیمات) به جفت (op, args) قابل فهم برای Editor_Renderer.
	 */
	public const OPERATIONS = array(
		'rotate_cw'  => array( 'op' => 'rotate', 'args' => array( 'degrees' => 90 ) ),
		'rotate_ccw' => array( 'op' => 'rotate', 'args' => array( 'degrees' => -90 ) ),
		'rotate_180' => array( 'op' => 'rotate', 'args' => array( 'degrees' => 180 ) ),
		'flip_h'     => array( 'op' => 'flip', 'args' => array( 'axis' => 'horizontal' ) ),
		'flip_v'     => array( 'op' => 'flip', 'args' => array( 'axis' => 'vertical' ) ),
		'grayscale'  => array( 'op' => 'filter', 'args' => array( 'filter' => 'grayscale' ) ),
		'bw'         => array( 'op' => 'filter', 'args' => array( 'filter' => 'bw', 'amount' => 128 ) ),
	);

	private Queue_Manager $queue_manager;
	private Settings $settings;
	private Logger $logger;
	private Editor_History $history;

	public function __construct( Queue_Manager $queue_manager, Settings $settings, Logger $logger, Editor_History $history ) {
		$this->queue_manager = $queue_manager;
		$this->settings      = $settings;
		$this->logger        = $logger;
		$this->history        = $history;
	}

	public function enqueue_eligible( int $limit = 0 ): int {
		$args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'posts_per_page' => $limit > 0 ? $limit : -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		);

		$attachment_ids = get_posts( $args );
		$added          = 0;

		foreach ( $attachment_ids as $attachment_id ) {
			if ( 'image/svg+xml' === get_post_mime_type( $attachment_id ) ) {
				continue; // رندر روی canvas بیت‌مپی برای SVG معنا ندارد (هم‌راستا با Watermark_Rules).
			}
			if ( $this->queue_manager->enqueue( self::ITEM_TYPE, (int) $attachment_id ) ) {
				++$added;
			}
		}

		$this->logger->info( 'editor', "اسکن کتابخانه برای پردازش دسته‌ای ویرایشگر انجام شد؛ {$added} تصویر جدید به صف اضافه شد." );

		return $added;
	}

	/**
	 * @return array{processed:int, applied:int, skipped:int, failed:int, remaining:int, locked:bool}
	 */
	public function process_tick(): array {
		if ( ! $this->queue_manager->acquire_lock( self::ITEM_TYPE, 55 ) ) {
			return array(
				'processed' => 0,
				'applied'   => 0,
				'skipped'   => 0,
				'failed'    => 0,
				'remaining' => $this->get_stats()['pending'],
				'locked'    => true,
			);
		}

		$operation_key = $this->settings->get_editor_batch_operation();
		$operation     = self::OPERATIONS[ $operation_key ] ?? self::OPERATIONS['rotate_cw'];

		$chunk_size = $this->settings->get_batch_chunk_size();
		$items      = $this->queue_manager->claim_batch( self::ITEM_TYPE, $chunk_size );

		$applied = 0;
		$skipped = 0;
		$failed  = 0;

		foreach ( $items as $item ) {
			$attachment_id = (int) $item->object_id;

			try {
				if ( 'attachment' !== get_post_type( $attachment_id ) ) {
					$this->queue_manager->mark_done( (int) $item->id );
					++$skipped;
					continue;
				}

				$result = $this->history->apply_operation( $attachment_id, $operation['op'], $operation['args'] );

				if ( 'applied' === $result['status'] ) {
					$this->queue_manager->mark_done( (int) $item->id );
					++$applied;
				} else {
					$this->queue_manager->mark_failed( (int) $item->id, $result['message'] ?? 'خطای نامشخص' );
					++$failed;
				}
			} catch ( \Throwable $e ) {
				$this->queue_manager->mark_failed( (int) $item->id, $e->getMessage() );
				++$failed;
			}
		}

		$this->queue_manager->release_lock( self::ITEM_TYPE );

		return array(
			'processed' => count( $items ),
			'applied'   => $applied,
			'skipped'   => $skipped,
			'failed'    => $failed,
			'remaining' => $this->get_stats()['pending'],
			'locked'    => false,
		);
	}

	public function get_stats(): array {
		return $this->queue_manager->get_stats( self::ITEM_TYPE );
	}

	public function reset_completed(): void {
		$this->queue_manager->clear_completed( self::ITEM_TYPE );
	}

	public function retry_failed(): int {
		return $this->queue_manager->retry_failed( self::ITEM_TYPE );
	}
}
