<?php
/**
 * Plugin Name:       Advanced Image SEO & Optimization Suite
 * Plugin URI:        https://example.com/advanced-image-seo-optimizer
 * Description:       بهینه‌سازی، سئو، واترمارک، ویرایش و مدیریت هوشمند تصاویر - کاملاً آفلاین و بدون وابستگی به سرویس بیرونی.
 * Version:           0.7.0
 * Requires PHP:      8.0
 * Requires at least: 6.0
 * Author:            Advanced Image SEO Suite
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       advanced-image-seo-optimizer
 * Domain Path:       /languages
 *
 * فاز ۲: اسکلت واقعی افزونه.
 * این فایل فقط نقطه‌ی ورود است: تعریف ثابت‌ها، رجیستر خودکار کلاس‌ها (autoload)،
 * قلاب‌های فعال‌سازی/غیرفعال‌سازی و بوت‌استرپ هسته‌ی افزونه.
 * هیچ منطق تجاری در این فایل نوشته نمی‌شود.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // دسترسی مستقیم مجاز نیست.
}

// ---------------------------------------------------------------------------
// ثابت‌های اصلی افزونه
// ---------------------------------------------------------------------------
define( 'AISEO_VERSION', '0.7.0' );
define( 'AISEO_PLUGIN_FILE', __FILE__ );
define( 'AISEO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AISEO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AISEO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'AISEO_MIN_PHP', '8.0' );

// ---------------------------------------------------------------------------
// بررسی نسخه‌ی PHP قبل از هر کاری (fail-safe, بدون فراخوانی هیچ کلاسی)
// ---------------------------------------------------------------------------
if ( version_compare( PHP_VERSION, AISEO_MIN_PHP, '<' ) ) {
	add_action(
		'admin_notices',
		function () {
			echo '<div class="notice notice-error"><p>' .
				esc_html__( 'افزونه‌ی Advanced Image SEO & Optimization Suite به PHP نسخه‌ی 8.0 یا بالاتر نیاز دارد. لطفاً نسخه‌ی PHP هاست خود را ارتقا دهید.', 'advanced-image-seo-optimizer' ) .
				'</p></div>';
		}
	);
	return;
}

// ---------------------------------------------------------------------------
// Autoloader سبک، بدون کامپوزر: نگاشت namespace به مسیر فایل طبق استاندارد وردپرس
// (class-nam-e.php با حروف کوچک و خط تیره)
// ---------------------------------------------------------------------------
spl_autoload_register(
	function ( $class ) {
		$prefix_map = array(
			'AISEO\\Modules\\Optimization\\'   => AISEO_PLUGIN_DIR . 'modules/optimization/',
			'AISEO\\Modules\\Seo\\'            => AISEO_PLUGIN_DIR . 'modules/seo/',
			'AISEO\\Modules\\Watermark\\'      => AISEO_PLUGIN_DIR . 'modules/watermark/',
			'AISEO\\Modules\\Editor\\'         => AISEO_PLUGIN_DIR . 'modules/editor/',
			'AISEO\\Modules\\Media_Library\\'  => AISEO_PLUGIN_DIR . 'modules/media-library/',
			'AISEO\\Admin\\'                   => AISEO_PLUGIN_DIR . 'admin/',
			'AISEO\\Helpers\\'                 => AISEO_PLUGIN_DIR . 'includes/helpers/',
			'AISEO\\'                          => AISEO_PLUGIN_DIR . 'includes/', // fallback عمومی‌ترین، باید آخر بررسی شود
		);

		foreach ( $prefix_map as $prefix => $base_dir ) {
			if ( strncmp( $class, $prefix, strlen( $prefix ) ) !== 0 ) {
				continue;
			}

			$relative = substr( $class, strlen( $prefix ) );
			// پشتیبانی از زیرپوشه‌های احتمالی داخل namespace (مثلاً Helpers تو در تو)
			$relative = str_replace( '\\', '/', $relative );

			$file_slug = strtolower( str_replace( '_', '-', $relative ) );

			$candidates = array(
				$base_dir . 'class-' . $file_slug . '.php',
			);

			// نام کلاس‌های Interface/Abstract/Trait طبق استاندارد وردپرس در فایلی بدون
			// پسوند تکراری قرار می‌گیرند: Image_Converter_Interface => interface-image-converter.php
			if ( preg_match( '/^(.*)_interface$/i', $relative, $m ) ) {
				$candidates[] = $base_dir . 'interface-' . strtolower( str_replace( '_', '-', $m[1] ) ) . '.php';
			} elseif ( preg_match( '/^abstract_(.*)$/i', $relative, $m ) ) {
				$candidates[] = $base_dir . 'abstract-' . strtolower( str_replace( '_', '-', $m[1] ) ) . '.php';
			} elseif ( preg_match( '/^(.*)_trait$/i', $relative, $m ) ) {
				$candidates[] = $base_dir . 'trait-' . strtolower( str_replace( '_', '-', $m[1] ) ) . '.php';
			}

			// حالت‌های عمومی به‌عنوان fallback نهایی
			$candidates[] = $base_dir . 'interface-' . $file_slug . '.php';
			$candidates[] = $base_dir . 'abstract-' . $file_slug . '.php';
			$candidates[] = $base_dir . 'trait-' . $file_slug . '.php';

			foreach ( $candidates as $file ) {
				if ( file_exists( $file ) ) {
					require_once $file;
					return;
				}
			}
		}
	}
);

// ---------------------------------------------------------------------------
// قلاب‌های فعال‌سازی / غیرفعال‌سازی
// ---------------------------------------------------------------------------
register_activation_hook( __FILE__, array( '\AISEO\Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( '\AISEO\Deactivator', 'deactivate' ) );

// ---------------------------------------------------------------------------
// بوت‌استرپ هسته‌ی افزونه پس از بارگذاری همه‌ی افزونه‌ها
// ---------------------------------------------------------------------------
add_action(
	'plugins_loaded',
	function () {
		\AISEO\Plugin::get_instance()->run();
	}
);
